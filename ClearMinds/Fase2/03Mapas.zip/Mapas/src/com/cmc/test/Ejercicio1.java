package com.cmc.test;

import java.util.ArrayList;
import java.util.HashMap;

public class Ejercicio1 {

    public static void main(String[] args) {
        ArrayList<String> lista;
        HashMap<String, String> mapa;
        lista = new ArrayList<>();
        mapa = new HashMap<>();
        lista.add("abc");
        mapa.put("1020", "abc");
        String a = lista.get(0);
        String b = mapa.get("1020");
        System.out.println(a);
        System.out.println(a);
    }

}
