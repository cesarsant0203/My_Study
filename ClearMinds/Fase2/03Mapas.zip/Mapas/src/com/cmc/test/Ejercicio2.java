package com.cmc.test;

import com.cmc.entidades.Cliente;
import java.util.HashMap;

public class Ejercicio2 {

    public static void main(String[] args) {
        HashMap<String, Cliente> clientes;
        clientes = new HashMap<>();
        clientes.put("1723521017", new Cliente("1723521017","Cesar"));
        Cliente b = clientes.get("1723521017");
        System.out.println(b);
    }

}
