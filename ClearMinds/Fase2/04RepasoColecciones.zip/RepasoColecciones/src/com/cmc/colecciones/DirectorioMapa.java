package com.cmc.colecciones;

import com.cmc.entidades.Contacto;
import java.util.HashMap;

public class DirectorioMapa extends Directorio {

    //atributos
    private HashMap<String, Contacto> contactos = new HashMap<>();

    //metodos
    @Override
    public void agregarContacto(Contacto contacto) {
        if (contactos.containsKey(contacto.getCedula()) == false) {
            contactos.put(contacto.getCedula(), contacto);
        }
    }

    @Override
    public Contacto buscarContacto(String cedula) {
        if (contactos.containsKey(cedula)) {
            return contactos.get(cedula);
        }else{
            return null;
        }
    }

    @Override
    public Contacto eliminarContacto(String cedula) {
        Contacto encontrado;
            if (contactos.containsKey(cedula)) {
                encontrado = contactos.get(cedula);
                contactos.remove(cedula);
                return encontrado;
            }
        return null;
    }

    @Override
    public void imprimir() {
        System.out.println(contactos);
    }
}
