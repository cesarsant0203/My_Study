package com.cmc.colecciones;

import com.cmc.entidades.Contacto;
import java.util.Arrays;

public class DirectorioArreglo extends Directorio {

    //atributos
    private Contacto[] contactos = new Contacto[0];

    //metodos
    @Override
    public void agregarContacto(Contacto contacto) {
        boolean existe = false;
        int n = contactos.length;
        int i;
        Contacto nuevoA[] = new Contacto[n + 1];
        for (i = 0; i < n; i++) {
            if (contactos[i].getCedula().equals(contacto.getCedula())) {
                existe = true;
            }
        }
        if (existe == false) {
            for (i = 0; i < n; i++) {
                nuevoA[i] = contactos[i];
            }
            nuevoA[n] = contacto;
            contactos = nuevoA;
        }
    }

    @Override
    public Contacto buscarContacto(String cedula) {
        for (Contacto contacto : contactos) {
            if (contacto.getCedula().equals(cedula)) {
                return contacto;
            }
        }
        return null;
    }

    @Override
    public Contacto eliminarContacto(String cedula) {
        Contacto encontrado;
        int n = contactos.length;
        int j = 0;
        Contacto nuevoA[] = new Contacto[n - 1];
        for (int i = 0; i < n; i++) {
            if (contactos[i].getCedula().equals(cedula)) {
                encontrado = contactos[i];
                contactos[i] = null;
                for (i = 0; i < n; i++) {
                    if (contactos[i] != null) {
                        nuevoA[j] = contactos[i];
                        j++;
                    }
                }
                contactos = nuevoA;
                return encontrado;
            }
        }
        return null;
    }

    @Override
    public void imprimir() {
        System.out.println(Arrays.toString(contactos));
    }
}
