package com.cmc.colecciones;

import com.cmc.entidades.Contacto;
import java.util.ArrayList;

public class DirectorioLista extends Directorio {

    //atributos
    private ArrayList<Contacto> contactos = new ArrayList<>();

    //metodos
    @Override
    public void agregarContacto(Contacto contacto) {
        boolean existe = false;
        for (int i = 0; i < contactos.size(); i++) {
            if (contactos.get(i).getCedula().equals(contacto.getCedula())) {
                existe = true;
            }
        }
        if (existe == false) {
            contactos.add(contacto);
        }
    }
    
    @Override
    public Contacto buscarContacto(String cedula) {
        for (int i = 0; i < contactos.size(); i++) {
            if (contactos.get(i).getCedula().equals(cedula)) {
                return contactos.get(i);
            }
        }
        return null;
    }
    
    @Override
    public Contacto eliminarContacto(String cedula) {
        Contacto encontrado;
        for (int i = 0; i < contactos.size(); i++) {
            if (contactos.get(i).getCedula().equals(cedula)) {
                encontrado = contactos.get(i);
                contactos.remove(i);
                return encontrado;
            }
        }
        return null;
    }
    
    @Override
    public void imprimir() {
        System.out.println(contactos);
    }
}
