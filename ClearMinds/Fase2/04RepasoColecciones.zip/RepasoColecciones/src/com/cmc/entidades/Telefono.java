package com.cmc.entidades;

public class Telefono {

    //atributos
    private String operadora;
    private String numero;

    //contructores
    public Telefono(String operadora, String numero) {
        this.operadora = operadora;
        this.numero = numero;
    }

    //getter y setter
    public String getOperadora() {
        return operadora;
    }

    public void setOperadora(String operadora) {
        this.operadora = operadora;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    //toString
    @Override
    public String toString() {
        return "\n   Operadora: " + operadora + " Numero: " + numero;
    }

}
