package com.cmc.entidades;

import java.util.ArrayList;

public class Contacto {

    //atributos
    private String cedula;
    private String nombre;
    private String apellido;
    private ArrayList<Telefono> telefonos = new ArrayList<>();

    //constructores
    public Contacto(String cedula, String nombre, String apellido) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    //getter y setter
    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    //toString
    @Override
    public String toString() {
        return "\n****************************************\n"
                + "Contacto\n   Cedula: " + cedula
                + "\n   Nombre: " + nombre
                + "\n   Apellido:" + apellido
                + "\nTelefonos: " + telefonos + "\n"
                + "****************************************\n";
    }

    //metodos
    public void agregarTelefono(Telefono telefono) {
        this.telefonos.add(telefono);
    }
}
