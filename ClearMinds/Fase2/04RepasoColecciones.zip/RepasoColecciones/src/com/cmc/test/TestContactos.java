
package com.cmc.test;

import com.cmc.entidades.Contacto;
import com.cmc.entidades.Telefono;

public class TestContactos {

    public static void main(String[] args) {
        Contacto c1 = new Contacto("1723521017","Cesar","Santacruz");
        Contacto c2 = new Contacto("1719008078","Sammy","Uribe");
        Telefono cel1 = new Telefono("Movistar","0993681491");
        Telefono cel2 = new Telefono("Movistar","0996222330");
        Telefono telf = new Telefono("CNT","022497055");
        c1.agregarTelefono(cel1);
        c1.agregarTelefono(telf);
        c2.agregarTelefono(cel2);
        c2.agregarTelefono(telf);
        System.out.println(c1);
        System.out.println(c2);
    }
    
}
