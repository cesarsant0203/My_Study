
package com.cmc.test;

import com.cmc.colecciones.DirectorioMapa;
import com.cmc.entidades.Contacto;
import com.cmc.entidades.Telefono;

public class TestDirectorioMapa {

    public static void main(String[] args) {
        Contacto c1 = new Contacto("1723521017","Cesar","Santacruz");
        Contacto c2 = new Contacto("1719008078","Sammy","Uribe");
        Telefono cel1 = new Telefono("Movistar","0993681491");
        Telefono cel2 = new Telefono("Movistar","0996222330");
        Telefono telf = new Telefono("CNT","022497055");
        c1.agregarTelefono(cel1);
        c1.agregarTelefono(telf);
        c2.agregarTelefono(cel2);
        c2.agregarTelefono(telf);
        DirectorioMapa dirM = new DirectorioMapa();
        dirM.agregarContacto(c1);
        dirM.agregarContacto(c2);
        System.out.println("//Se intenta agregar un contacto 2 veces//");
        dirM.agregarContacto(c2);
        System.out.println("//Se muestra el directorio//");
        dirM.imprimir();
        System.out.println("//Se busca un contacto valido//");
        System.out.println(dirM.buscarContacto(c1.getCedula()));
        System.out.println("//Se busca un contacto invalido//");
        System.out.println(dirM.buscarContacto("1723521018"));
        System.out.println("//Se muestra el contacto eliminado//");
        System.out.println(dirM.eliminarContacto(c1.getCedula()));
        System.out.println("//Se muestra el directorio//");
        dirM.imprimir();
    }
    
}
