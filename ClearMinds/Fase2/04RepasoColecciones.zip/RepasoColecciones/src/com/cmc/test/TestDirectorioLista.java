
package com.cmc.test;

import com.cmc.colecciones.DirectorioLista;
import com.cmc.entidades.Contacto;
import com.cmc.entidades.Telefono;

public class TestDirectorioLista {

    public static void main(String[] args) {
        Contacto c1 = new Contacto("1723521017","Cesar","Santacruz");
        Contacto c2 = new Contacto("1719008078","Sammy","Uribe");
        Telefono cel1 = new Telefono("Movistar","0993681491");
        Telefono cel2 = new Telefono("Movistar","0996222330");
        Telefono telf = new Telefono("CNT","022497055");
        c1.agregarTelefono(cel1);
        c1.agregarTelefono(telf);
        c2.agregarTelefono(cel2);
        c2.agregarTelefono(telf);
        DirectorioLista dirL = new DirectorioLista();
        dirL.agregarContacto(c1);
        dirL.agregarContacto(c2);
        System.out.println("//Se intenta agregar un contacto 2 veces//");
        dirL.agregarContacto(c2);
        System.out.println("//Se muestra el directorio//");
        dirL.imprimir();
        System.out.println("//Se busca un contacto valido//");
        System.out.println(dirL.buscarContacto(c1.getCedula()));
        System.out.println("//Se busca un contacto invalido//");
        System.out.println(dirL.buscarContacto("1723521018"));
        System.out.println("//Se muestra el contacto eliminado//");
        System.out.println(dirL.eliminarContacto(c1.getCedula()));
        System.out.println("//Se muestra el directorio//");
        dirL.imprimir();
    }
    
}
