
package com.cmc.test;

import com.cmc.colecciones.DirectorioArreglo;
import com.cmc.entidades.Contacto;
import com.cmc.entidades.Telefono;

public class TestDirectorioArreglo {

    public static void main(String[] args) {
        Contacto c1 = new Contacto("1723521017","Cesar","Santacruz");
        Contacto c2 = new Contacto("1719008078","Sammy","Uribe");
        Telefono cel1 = new Telefono("Movistar","0993681491");
        Telefono cel2 = new Telefono("Movistar","0996222330");
        Telefono telf = new Telefono("CNT","022497055");
        c1.agregarTelefono(cel1);
        c1.agregarTelefono(telf);
        c2.agregarTelefono(cel2);
        c2.agregarTelefono(telf);
        DirectorioArreglo dirA = new DirectorioArreglo();
        dirA.agregarContacto(c1);
        dirA.agregarContacto(c2);
        System.out.println("//Se intenta agregar un contacto 2 veces//");
        dirA.agregarContacto(c2);
        System.out.println("//Se muestra el directorio//");
        dirA.imprimir();
        System.out.println("//Se busca un contacto valido//");
        System.out.println(dirA.buscarContacto(c1.getCedula()));
        System.out.println("//Se busca un contacto invalido//");
        System.out.println(dirA.buscarContacto("1723521018"));
        System.out.println("//Se muestra el contacto eliminado//");
        System.out.println(dirA.eliminarContacto(c1.getCedula()));
        System.out.println("//Se muestra el directorio//");
        dirA.imprimir();
    }
    
}
