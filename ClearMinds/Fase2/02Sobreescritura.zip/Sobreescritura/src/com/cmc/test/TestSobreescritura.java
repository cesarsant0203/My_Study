package com.cmc.test;

import com.cmc.herencia.Perro;

public class TestSobreescritura {


    public static void main(String[] args) {
        Perro p = new Perro();
        p.dormir();
        p.ladrar();
    }
    
}
