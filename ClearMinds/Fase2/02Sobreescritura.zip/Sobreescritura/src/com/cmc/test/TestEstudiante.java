package com.cmc.test;

import com.cmc.herencia.Estudiante;
import com.cmc.herencia.Persona;

public class TestEstudiante {

    public static void main(String[] args) {
        Estudiante es = new Estudiante("Cesar", "Santacruz");
        System.out.println("Estudiante: " + es);
        Persona p = new Persona("Cesar", "Santacruz");
        System.out.println("Estudiante: " + p.toString());
    }

}
