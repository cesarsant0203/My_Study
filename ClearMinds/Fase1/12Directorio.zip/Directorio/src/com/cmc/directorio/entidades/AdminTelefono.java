package com.cmc.directorio.entidades;

import java.util.ArrayList;

public class AdminTelefono {

    //metodos
    public void activarMensajeria(Telefono telf) {
        if (telf.getOperadora().equals("movi")) {
            telf.setTieneWhatsapp(true);
        }
    }

    public int contarMovi(Telefono telf1, Telefono telf2, Telefono telf3) {
        ArrayList<Telefono> telfs = new ArrayList<>();
        telfs.add(telf1);
        telfs.add(telf2);
        telfs.add(telf3);
        int res = 0;
        for (int i = 0; i < telfs.size(); i++) {
            if (telfs.get(i).getOperadora().equals("movi")) {
                res++;
            }

        }
        return res;
    }

    public int contarClaro(Telefono telf1, Telefono telf2, Telefono telf3, Telefono telf4) {
        ArrayList<Telefono> telfs = new ArrayList<>();
        telfs.add(telf1);
        telfs.add(telf2);
        telfs.add(telf3);
        telfs.add(telf4);
        int res = 0;
        for (int i = 0; i < telfs.size(); i++) {
            if (telfs.get(i).getOperadora().equals("claro")) {
                res++;
            }

        }
        return res;
    }
}
