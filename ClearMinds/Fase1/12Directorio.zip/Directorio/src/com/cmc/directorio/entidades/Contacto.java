package com.cmc.directorio.entidades;

public class Contacto {

    //atributos
    private String nombre;
    private String apellido;
    private boolean activo;
    private Telefono telefono;
    private double peso;

    //constructor
    public Contacto(String nombre, String apellido, Telefono telefono, double peso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.peso = peso;
    }

    //metodos
    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public boolean isActivo() {
        return activo;
    }

    public Telefono getTelefono() {
        return telefono;
    }

    public double getPeso() {
        return peso;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public void mostrarInfoContacto() {
        System.out.println("Contacto ----------------------");
        System.out.println("Nombre:\t\t" + this.nombre);
        System.out.println("Apellido:\t" + this.apellido);
        if (this.activo == false) {
            System.out.println("Activo:\t\t" + "No");
        } else {
            System.out.println("Activo:\t\t" + "Si");
        }
        System.out.println("Telefono:");
        System.out.println("   Operadora:\t" + this.telefono.getOperadora());
        System.out.println("   Numero:\t" + this.telefono.getNumero());
        System.out.println("Peso:\t\t" + this.peso);
        System.out.println("-------------------------------");
    }
}
