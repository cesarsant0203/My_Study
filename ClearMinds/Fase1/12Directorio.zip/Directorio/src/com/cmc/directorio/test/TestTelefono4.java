package com.cmc.directorio.test;

import com.cmc.directorio.entidades.AdminTelefono;
import com.cmc.directorio.entidades.Telefono;

public class TestTelefono4 {

    public static void main(String[] args) {
        Telefono telf1 = new Telefono(05, "claro", "0992342234");
        Telefono telf2 = new Telefono(10, "movi", "0993681491");
        Telefono telf3 = new Telefono(15, "claro", "0992443405");
        Telefono telf4 = new Telefono(20, "claro", "0991837155");
        AdminTelefono at = new AdminTelefono();
        int res = at.contarClaro(telf1, telf2, telf3, telf4);
        System.out.println("Los telefonos con la operadora claro son: " + res);
    }

}
