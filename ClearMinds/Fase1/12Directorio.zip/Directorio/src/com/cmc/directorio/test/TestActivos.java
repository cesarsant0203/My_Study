package com.cmc.directorio.test;

import com.cmc.directorio.entidades.AdminContactos;
import com.cmc.directorio.entidades.Contacto;
import com.cmc.directorio.entidades.Telefono;

public class TestActivos {

    public static void main(String[] args) {
        Telefono telf1 = new Telefono(10,"claro","0993681491");
        Contacto cont1 = new Contacto("Cesar","Santacruz",telf1,110.5);
        AdminContactos ac = new AdminContactos();
        //verificar que no tiene WhatsApp
        cont1.getTelefono().mostrarInfoTelefono();
        //se intenta activar el usuario pero no se puede
        //por que no tiene WhatsApp
        ac.activarUsuario(cont1);
        cont1.mostrarInfoContacto();
    }
    
}
