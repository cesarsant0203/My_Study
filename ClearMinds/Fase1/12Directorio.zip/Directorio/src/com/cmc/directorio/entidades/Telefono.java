package com.cmc.directorio.entidades;

public class Telefono {

    //atributos
    private String operadora;
    private String numero;
    private int codigo;
    private boolean tieneWhatsapp;

    //constructor
    public Telefono(int codigo, String operadora, String numero) {
        this.operadora = operadora;
        this.numero = numero;
        this.codigo = codigo;
        this.tieneWhatsapp = false;
    }

    //metodos
    public String getOperadora() {
        return operadora;
    }

    public String getNumero() {
        return numero;
    }

    public int getCodigo() {
        return codigo;
    }

    public boolean TieneWhatsapp() {
        return tieneWhatsapp;
    }

    public void setTieneWhatsapp(boolean tieneWhatsapp) {
        this.tieneWhatsapp = tieneWhatsapp;
    }

    public void mostrarInfoTelefono() {
        System.out.println("Telefono ----------------------");
        System.out.println("Operadora:\t" + this.operadora);
        System.out.println("Numero:\t\t" + this.numero);
        System.out.println("Codigo:\t\t"+this.codigo);
        if(this.tieneWhatsapp==false){
        System.out.println("Whatsapp:\t"+"No");
        }else{
        System.out.println("Whatsapp:\t"+"Si");    
        }
        System.out.println("-------------------------------");
    }
}
