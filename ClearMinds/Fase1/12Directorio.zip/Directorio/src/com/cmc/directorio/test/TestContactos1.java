package com.cmc.directorio.test;

import com.cmc.directorio.entidades.AdminContactos;
import com.cmc.directorio.entidades.Contacto;
import com.cmc.directorio.entidades.Telefono;

public class TestContactos1 {

    public static void main(String[] args) {
        Telefono telf1 = new Telefono(10,"movi","0993681491");
        Telefono telf2 = new Telefono(10,"claro","0917324788");
        Contacto cont1 = new Contacto("Cesar","Santacruz",telf1,150.5);
        Contacto cont2 = new Contacto("Sammy","Uribe",telf2,110.8);
        AdminContactos ac = new AdminContactos();
        System.out.println("El contacto mas pesado.");
        Contacto res1 = ac.buscarMasPesado(cont1, cont2);
        res1.mostrarInfoContacto();
        boolean res2 = ac.compararOperadoras(cont1, cont2);
        if(res2==true){
            System.out.println("Las operadoras de los contactos son las mismas");
        }else{
            System.out.println("Las operadoras de los contactos son diferentes");
        }
    }
    
}
