package com.cmc.directorio.test;

import com.cmc.directorio.entidades.Contacto;
import com.cmc.directorio.entidades.Telefono;

public class TestContacto1 {

    public static void main(String[] args) {
        Telefono telef = new Telefono(10, "movi", "0993681491");
        Contacto c = new Contacto("Cesar", "Santacruz", telef, 0.512);
        c.mostrarInfoContacto();
    }

}
