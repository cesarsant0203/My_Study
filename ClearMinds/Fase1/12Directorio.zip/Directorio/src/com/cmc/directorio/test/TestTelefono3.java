package com.cmc.directorio.test;

import com.cmc.directorio.entidades.AdminTelefono;
import com.cmc.directorio.entidades.Telefono;

public class TestTelefono3 {

    public static void main(String[] args) {
        Telefono telf1 = new Telefono(10, "movi", "0993681491");
        Telefono telf2 = new Telefono(15, "claro", "0992443405");
        Telefono telf3 = new Telefono(20, "movi", "0991837155");
        AdminTelefono at = new AdminTelefono();
        int res = at.contarMovi(telf1, telf2, telf3);
        System.out.println("Los telefonos con la operadora movi son: " + res);
    }

}
