package com.cmc.directorio.entidades;

public class AdminContactos {

    //metodos
    public Contacto buscarMasPesado(Contacto cont1, Contacto cont2) {
        if (cont1.getPeso() > cont2.getPeso()) {
            return cont1;
        } else if (cont1.getPeso() < cont2.getPeso()) {
            return cont2;
        } else {
            return null;
        }
    }

    public boolean compararOperadoras(Contacto cont1, Contacto cont2) {
        return cont1.getTelefono().getOperadora().equals(cont2.getTelefono().getOperadora());
    }

    public void activarUsuario(Contacto cont1) {
        if (cont1.getTelefono().TieneWhatsapp() == true) {
            cont1.setActivo(true);
        }
    }
}
