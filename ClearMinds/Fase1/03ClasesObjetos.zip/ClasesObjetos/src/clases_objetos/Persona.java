package clases_objetos;

public class Persona {

    public String nombre;
    public int edad;
    public double estatura;

}
