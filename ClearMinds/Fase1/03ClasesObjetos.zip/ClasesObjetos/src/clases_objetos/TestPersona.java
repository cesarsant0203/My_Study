package clases_objetos;

public class TestPersona {

    public static void main(String[] args) {
        System.out.println("prueba");
        int a;
        Persona p; //Declaro la variable p de tipo Persona
        p = new Persona();// Instancio un objeto Persona
        System.out.println("Nombre: " + p.nombre);
        System.out.println("Edad: " + p.edad);
        System.out.println("Estatura: " + p.estatura);
        p.nombre = "Juan";
        p.edad = 12;
        p.estatura = 1.35;
        System.out.println("Nombre: " + p.nombre);
        System.out.println("Edad: " + p.edad);
        System.out.println("Estatura: " + p.estatura);
        Persona p2 = new Persona();
        p2.nombre = "Santiago";
        p2.edad = 23;
        p2.estatura = 1.34;
        System.out.println("Nombre: " + p2.nombre);
        System.out.println("Edad: " + p2.edad);
        System.out.println("Estatura: " + p2.estatura);
    }

}
