package com.repaso.entidades.test;

import com.repaso.entidades.Persona;
import java.util.Scanner;

public class TestPersona {

    public static void main(String[] args) {
        welcome();
        Scanner input = new Scanner(System.in);
        Scanner inputSt = new Scanner(System.in);
        Scanner inputInt = new Scanner(System.in);
        Persona persona;
        System.out.println("Desea ingresar los datos de la persona?");
        System.out.println("si(constructor que recibe codigo, nombre y apellido)");
        System.out.println("no(constructor que no recibe nada)");
        String resCons = inputSt.nextLine();
        if (resCons.equals("si") || resCons.equals("s")|| resCons.equals("y") ) {
            System.out.println("Ingrese el codigo");
            int codigo = inputInt.nextInt();
            System.out.println("Ingrese el nombre");
            String nombre = inputSt.nextLine();
            System.out.println("Ingrese el apellido");
            String apellido = inputSt.nextLine();
            persona = new Persona(codigo, nombre, apellido);
        } else {
            persona = new Persona();
        }
        divider();
        int option = 0;
        try {
            do {
                options();
                option = input.nextInt();
                switch (option) {
                    case 0:
                        System.out.println("Muchas gracias por usar este programa");
                        System.exit(0);
                    case 1:
                        divider();
                        String nombreCompleto = persona.getNombreCompleto();
                        System.out.println(nombreCompleto);
                        divider();
                        break;
                    case 2:
                        divider();
                        System.out.println("Ingrese el incremento");
                        double incremento = inputInt.nextDouble();
                        persona.agregarEstatura(incremento);
                        divider();
                        break;
                    case 3:
                        divider();
                        persona.imprimir();
                        divider();
                        break;
                    case 4:
                        divider();
                        System.out.println("Ingrese el incremento");
                        double incremento2 = inputInt.nextDouble();
                        double resMod = persona.modificarEstatura(incremento2);
                        System.out.println("La nueva estatura es: " + resMod);
                        divider();
                        break;
                    case 5:
                        divider();
                        String resObt = persona.obtenerInformacion();
                        System.out.println(resObt);
                        divider();
                        break;
                    case 6:
                        divider();
                        System.out.println("Ingrese el nuevo codigo");
                        int nCodigo = inputInt.nextInt();
                        System.out.println("Ingrese la nueva estatura");
                        double nEstatura = inputInt.nextDouble();
                        double resCam= persona.cambiarValores(nCodigo, nEstatura);
                        System.out.println("Resultado: " + resCam);
                        divider();
                        break;
                    default:
                        divider();
                        divider();
                        System.out.println("Esa no es una opcion valida");
                        divider();
                        divider();
                        break;
                }

            } while (option != 0);
        } catch (Exception e) {
            System.out.println("Ese no es un valor numerico valido");
        }

    }

    public static void welcome() {
        divider();
        System.out.println("\t\t\tBIENVENID@");
        divider();
    }

    public static void options() {
        System.out.println("Seleccione el numero de opcion que desea realiz"
                + "ar");
        System.out.println("Por favor ingrese 1 si desea mostrar la concatenac"
                + "ion del nombre y el apellido (getNombreCompleto)");
        System.out.println("Por favor ingrese 2 si desea agregar estatura (agr"
                + "egarEstatura)");
        System.out.println("Por favor ingrese 3 si desea imprimir los valores "
                + "de los atributos (imprimir)");
        System.out.println("Por favor ingrese 4 si desea agregar estatura y v"
                + "isualizar la nueva estatura (modificarEstatura)");
        System.out.println("Por favor ingrese 5 si desea visualizar la concat"
                + "enacion de todos los valores (obtenerInformacion)");
        System.out.println("Por favor ingrese 6 si desea cambiar el valor del"
                + "codigo y de la estatura (cambiarValores)");
        System.out.println("Por favor ingrese 0 si desea salir en este mome"
                + "nto del programa");
    }

    public static void divider() {
        System.out.println("///////////////////////////////////////"
                + "////////////////////////");
    }
}
