package com.repaso.entidades;

public class Persona {

    //atributos
    private String nombre;
    private String apellido;
    private double estatura;
    private int codigo;

    //constructores
    public Persona() {
    }

    public Persona(int codigo, String nombre, String apellido) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    //getter y setter
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public double getEstatura() {
        return estatura;
    }

    public void setEstatura(double estatura) {
        this.estatura = estatura;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    //metodos
    public String getNombreCompleto() {
        return this.nombre + " " + this.apellido;
    }

    public void agregarEstatura(double incremento) {
        this.estatura += incremento;
    }

    public void imprimir() {
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Apellido: " + this.apellido);
        System.out.println("Estarura: " + this.estatura);
        System.out.println("Codigo: " + this.codigo);
    }

    public double modificarEstatura(double incremento) {
        this.estatura += incremento;
        return this.estatura;
    }

    public String obtenerInformacion() {
        return this.nombre + " - " + this.apellido
                + " - " + this.estatura + " - " + this.codigo;
    }

    public double cambiarValores(int nuevoCodigo, double incremento) {
        this.codigo = nuevoCodigo;
        this.estatura += incremento;
        return nuevoCodigo + incremento;
    }
}
