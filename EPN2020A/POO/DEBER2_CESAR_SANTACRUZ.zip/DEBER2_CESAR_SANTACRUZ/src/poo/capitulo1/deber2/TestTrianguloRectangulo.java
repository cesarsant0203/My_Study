/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.deber2;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestTrianguloRectangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Por favor ingrese el cateto 1");
        double cat1;
        Scanner input = new Scanner(System.in);
        cat1 = input.nextDouble();
        System.out.println("Por favor ingrese el cateto 2");
        int cat2;
        cat2 = input.nextInt();        
        /////////////////////////////////////////////////////////////
        TrianguloRectangulo primerTrianguloRectangulo = new TrianguloRectangulo(); // declaracion e inicializacion 
        primerTrianguloRectangulo.setCateto1(cat1);
        primerTrianguloRectangulo.setCateto2(cat2);
        System.out.println(" Primer Triangulo Rectangulo");
        primerTrianguloRectangulo.calcularHipotenusa();
        primerTrianguloRectangulo.calcularPerimetro();
        primerTrianguloRectangulo.calcularArea();
        System.out.println(primerTrianguloRectangulo.toString());
        ////////////////////////////////////////////////////////////
    }
    
}
