/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.deber2;

/**
 *
 * @author cesar
 */
public class TrianguloRectangulo {
    private double cateto1;
    private double cateto2;
    private  double hipotenusa;
    private double area;
    private double perimetro;
    
    public void setCateto1 (double cateto1){
        this.cateto1 = cateto1;
    }
    public void setCateto2 (double cateto2){
        this.cateto2 = cateto2;
    }
    public void calcularHipotenusa ( ){
        this.hipotenusa += Math.sqrt(Math.pow(this.cateto1, 2) + Math.pow(this.cateto2 , 2));
    }
    public void calcularPerimetro( ){
        this.perimetro += this.cateto1 + this.cateto2 + this.hipotenusa;
    }
    public void calcularArea ( ){
        this.area += (this.cateto1 * this.cateto2)/2;
    }
    /*
    public void desplegar( ) {
        
        System.out.println("cateto1\n" + "--" + this.cateto1);
        System.out.println("cateto2\n" + "--" + this.cateto2);
        System.out.println("hipotenusa:\n" + "--" + this.hipotenusa);
        System.out.println("perimetro:\n" + "--" + this.perimetro);
        System.out.println("area :\n" + "--" + this.area);
        
    }
    */
    
    @Override
    public String toString() {
        return "Ejercicio01{" + "cateto1= " + cateto1 + ", cateto2= " + cateto2 + ", hipotenusa= " + hipotenusa + ", area= " + area + ", perimetro= " + perimetro + '}';
    }
}
