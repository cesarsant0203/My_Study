/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap2.deber5;

import java.util.Objects;

/**
 *
 * @author cesar
 */
public class Raton {

    private int edad;
    private double peso;
    private double tasaCrecimientoPorcentual;
    private int dias;
    private String nombre;

    {
        System.out.println("bloque inicializacion");
    }
// constructores

    public Raton(int edad, double tasaCrecimientoPorcentual) {
        this.edad = edad;
        this.tasaCrecimientoPorcentual = tasaCrecimientoPorcentual;
        System.out.println("construccion con edad y tasa de crecimiento");
    }

    public Raton(String nombre, double tasaCrecimientoPorcentual, double peso) {
        this.nombre = nombre;
        this.peso = peso;
        this.tasaCrecimientoPorcentual = tasaCrecimientoPorcentual;
    }

    public Raton() {
        this.edad = 5;
        System.out.println("constructor vacio");
    }

    public Raton(double tasaCrecimientoPorcentual, int edad) {

    }

    public void setTasaCrecimientoPorcentual(double tasaCrecimientoPorcentual) {
        this.tasaCrecimientoPorcentual = tasaCrecimientoPorcentual;
    }

    public void setDias(int dias) {
        this.dias = dias;
    }
//    public void crecer() {
//        this.edad++;
//        this.peso += (this.peso * this.tasaCrecimientoPorcentual / 100);
//    }

    public void crecer() {//debe recibir la cantidad de dias
        this.edad += (this.edad + this.dias);
        this.peso += (this.dias * this.peso * this.tasaCrecimientoPorcentual / 100);
    }

    public void crecer(int dias) {//debe recibir la cantidad de dias
        this.edad += (this.edad + this.dias);
        this.peso += (this.dias * this.peso * this.tasaCrecimientoPorcentual / 100);
    }

    public void desplegar() {
        System.out.println("Edad: " + this.edad);
        System.out.printf("Peso: %.2f \n", this.peso);
    }

    public boolean esAdolecente() {

        return this.edad <= 100;
    }

      
    public int getEdad(){
        return this.edad;
    }
     
    public double getPeso() {
        return peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Raton{" + nombre + "edad=" + edad + ", peso=" + peso + ", tasaCrecimientoPorcentual=" + tasaCrecimientoPorcentual + '}';
    }

    public boolean equals(Raton otroRaton) {
        return this.edad == otroRaton.edad && this.peso == otroRaton.peso && this.nombre.equals(otroRaton.nombre);

        //objeto.equals otroObjeto
    }

    /*
    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Raton other = (Raton) obj;
        if (this.edad != other.edad) {
            return false;
        }
        if (Double.doubleToLongBits(this.peso) != Double.doubleToLongBits(other.peso)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }
     */

    
        
}
