/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber9;

/**
 *
 * @author Cesar J. Santacruz
 */
public class TestDeber9 {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here
		Figura figuras[] = new Figura[6];
		figuras[0] = new Circulo();
		figuras[1] = new Cuadrado();
		figuras[2] = new Triangulo();
		figuras[3] = new Esfera();
		figuras[4] = new Cubo();
		figuras[5] = new Tetraedro();

		for (Figura f1 : figuras) {
			System.out.println(f1.obtenerArea());
			if(f1 instanceof FiguraTridimensional){
			((FiguraTridimensional)f1).obtenerVolumen(); //casting y ejecutar el metodo
		}
		}
	}

}




