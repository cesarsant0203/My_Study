/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber9;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Esfera extends FiguraTridimensional {
	private double radio;

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}
	
	@Override
	public double obtenerArea() {
		return 4.0 * Math.PI * Math.pow(this.radio, 2);
	}

	@Override
	public double obtenerVolumen() {
		return 1.3333333 * Math.PI * Math.pow(this.radio, 3);
	}

	@Override
	public String toString() {
		return "Esfera:\n\tRadio\n"
			+"========================\n";
	}
	
}











