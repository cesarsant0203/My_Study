/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap2.prueba2;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Cuenta {

    private String nombreTitular;
    private String tipoCuenta;
    private double saldo;

    public Cuenta(String nombreTitular, String tipoCuenta, double saldo) {
        this.nombreTitular = nombreTitular.toLowerCase();
        this.tipoCuenta = tipoCuenta.toUpperCase();
        this.saldo = saldo;
    }

    public String info() {
        return "Informacion Persona:\n "
                + "Titular= " + this.nombreTitular + ","
                + "\nTipo de cuenta= " + this.tipoCuenta + ","
                + "\nSaldo= " + String.valueOf(this.saldo);
    }

    public void retirar(Double valor) {
        this.saldo = this.saldo - valor;
    }

    public void depositar(Double valor) {
        this.saldo = this.saldo + valor;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return  "" + saldo;
    }
    
    
}
