/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.deber1;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestEjercicio03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("3.	Escriba un programa que reciba cinco números\n"
                + " enteros, y que determine e imprima la cantidad de números\n"
                + " negativos, positivos, y la cantidad de ceros recibidos.");
        Scanner imput = new Scanner(System.in);

        System.out.println("\nPor favor introdusca los 5 numeros enteros \n");

        int positivos = 0;
        int negativos = 0;
        int ceros = 0;
        /* demasiado largo muchos casos
        if ((q > 0) & (w > 0) & (e > 0) & (r > 0) & (t > 0)) {
        System.out.println("Numeros");
        }
         */
        int[] numerosEnteros = new int[5];//ejemplo de sintaxis, esto da error por el compilador
        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese el  " + (i + 1) + " numero\n");
            numerosEnteros[i] = imput.nextInt();
        }

        for (int i = 0; i < 5; i++) {
            if (numerosEnteros[i] > 0) {
                positivos = positivos + 1;
            }

            if (numerosEnteros[i] < 0) {
                negativos = negativos + 1;
            }

            if (0 == numerosEnteros[i]) {
                ceros = ceros + 1;
            }
        }
        System.out.println("Los 5 numeros han sido ingresados, de estos ");
        System.out.printf("%d son positivos\n", positivos);
        System.out.printf("%d son negativos\n", negativos);
        System.out.printf("%d son ceros\n", ceros);

        /*
            prueba
        numerosEnteros[0] = imput.nextInt();
        numerosEnteros[1] = imput.nextInt();
        numerosEnteros[2] = imput.nextInt();
        numerosEnteros[3] = imput.nextInt();
        numerosEnteros[4] = imput.nextInt();
        System.out.print("|"+numerosEnteros[0]);
        System.out.print("|"+numerosEnteros[1]);
        System.out.print("|"+numerosEnteros[2]);
        System.out.print("|"+numerosEnteros[3]);
        System.out.print("|"+numerosEnteros[4]);
         */
    }

}
