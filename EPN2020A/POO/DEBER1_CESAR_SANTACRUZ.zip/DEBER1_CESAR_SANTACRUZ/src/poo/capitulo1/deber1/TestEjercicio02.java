/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.deber1;

/**
 *
 * @author cesar
 */
public class TestEjercicio02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    System.out.println("2.	Escriba una aplicación que calcule los cuadrados\n"
            + "y cubos de los números del 1 al 10.");
    int numero;
    numero=0;
    System.out.println("\t numero" + "\t" + "cuadrado "  + " cubo");
    while (numero <= 10) {
        System.out.println("\t " + numero + "\t" + numero*numero + "\t  " + numero*numero*numero);
        numero = numero+1;
    }
    }
    
}