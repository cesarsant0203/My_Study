/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.deber1;
import java.util.Scanner;
/**
 *
 * @author cesar
 */
public class TestEjercicio01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("1.	Escriba una aplicación que reciba del usuario \n"
                + "un número compuesto por cinco dígitos, que separe ese número \n"
                + "en sus dígitos individuales y los imprima, cada uno separado \n"
                + "de los demás por tres espacios.");
        
        Scanner imput = new Scanner(System.in);
        int numero;
        System.out.println("\nPor favor introdusca un numero que tenga exactamente\n"
                + "5 digitos ni mas ni menos para poder separarlo por 3 espacios");
        numero = imput.nextInt();
        String numeroIngresado = Integer.toString(numero);
        if (numeroIngresado.length() == 5 ){
            System.out.printf("%d   ",   numero/10000);
            System.out.printf("%d   ", (numero%10000)/1000);
            System.out.printf("%d   ", ((numero%10000)%1000)/100);
            System.out.printf("%d   ", (((numero%10000)%1000)%100)/10);
            System.out.printf("%d   \n", ((((numero%10000)%1000)%100)%10));
        }
        else {
        System.out.println("\n El numero no es de 5 caracteres lo siento no te \n"
                + "puedo ayudar separandolo");
        }
        
    }
    
}