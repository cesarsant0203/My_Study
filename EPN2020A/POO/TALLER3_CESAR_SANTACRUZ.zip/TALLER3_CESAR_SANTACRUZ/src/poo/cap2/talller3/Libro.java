/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap2.talller3;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Libro {

    private String titulo;
    private String edicion;
    private int numPaginas;
    private String isbn;

    public Libro(String titulo, String edicion, String numPaginas, String isbn) {
        this.titulo = titulo.toUpperCase();
        this.edicion = edicion.toUpperCase();
        this.numPaginas = Integer.parseInt(numPaginas);
        this.isbn = isbn;
    }

    @Override
    public String toString() {
        return "\n======================================================================\n"
                + "\tInformacion Libro:\n"
                + "\tTitulo= " + this.titulo
                + ",\n\tEdicion= " + this.edicion
                + ",\n\tNumero de paginas= " + this.numPaginas
                + ",\n\tISBN= " + this.isbn
                + "\n======================================================================\n";
    }    
    
}