/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprincesa;

import java.security.SecureRandom;
import javax.swing.JOptionPane;

/**
 *
 * @author Cesar J. Santacruz
 */
public class GestionPrincesa extends javax.swing.JFrame {
	String frases[] = {"Hola amor, como esta el amor de mi vida?", "te amo sabes, te amo muchisimo", "Me encantas","Me fascinas","Siempre Juntos","No te rindas","Tu puedes con todo", "eres la mejor novia","Mi princesa", "Mi tesoro", "Mi mundo","mi todo", "Por siempre mia","Por siempre tuyo", "Tu lo puedes todo mi amor", "Nuestro futuro es juntos","Nuestro amor es mas grande que todo", "de los momentos buenos a los malos prefiero los ratitos contigo", "tu has cambiado mi vida por completo", "Me acercaría hasta el más escondido confín para poder mirarte a los ojos y decirte que te amo.","Quiero que cuando seamos ancianos, un día me despierte contigo y te diga: ¿Ves? Te prometí que te amaría eternamente.","No hace falta que te recuerde que te amo, pero es que me gusta tanto decírtelo una y otra vez y verte sonreír..."};
	String letras[] = {"Amo lo que veo y lo que ocultas\n" +
"Amo lo que muestras o insinuas\n" +
"Amo lo que eres o imagino\n" +
"Te amo en lo ajeno y lo que es mío\n" +
"\n" +
"Amo lo que entregas, lo que escondes\n" +
"Amo tus preguntas, tus respuestas\n" +
"Yo amo tus dudas y certezas\n" +
"Te amo en lo simple y lo compleja\n" +
"\n" +
"Y amo lo que dices, lo que callas\n" +
"Amo tus recuerdos, tus olvidos\n" +
"Amo tus olores, tus fragancias\n" +
"Te amo en el beso y la distancia\n" +
"\n" +
"Y amo lo que amas, yo te amo\n" +
"Te amo por amor sin doble filo\n" +
"Te amo y si pudiera no amarte\n" +
"Sé que te amaría aún lo mismo\n" +
"\n" +
"Y amo lo que amas, yo te amo\n" +
"Te amo por amor al dar lo mío\n" +
"Te amo con orgullo de quererte\n" +
"Porque para amarte yo he nacido\n" +
"\n" +
"Amo lo que seas y lo que puedas\n" +
"Amo lo que afirmas, lo que niegas\n" +
"Amo lo que dices, lo que piensas\n" +
"Te amo en lo que mides y lo que pesas\n" +
"\n" +
"Y amo lo que atrapas, lo que dejas\n" +
"Amo tu alegría y tus tristezas\n" +
"Te amo en la carne y en el alma\n" +
"Te amo en tus crisis y en tus calmas\n" +
"\n" +
"Amo lo que pides y regalas\n" +
"Amo tus caricias, tus ofensas\n" +
"Amo tus instante y lo eterno\n" +
"Te amo en tu cielo y en tu infierno\n" +
"\n" +
"Y amo lo que amas, yo te amo\n" +
"Te amo por amor sin doble filo\n" +
"Te amo y si pudiera no amarte\n" +
"Sé que te amaría aún lo mismo\n" +
"\n" +
"Y amo lo que amas, yo te amo\n" +
"Te amo por amor al dar lo mío\n" +
"Te amo con orgullo de quererte\n" +
"Porque para amarte yo he nacido", "Que milagro tiene que pasar para que me ames\n" +
"Que estrella del cielo a de caer para poderte convencer\n" +
"Que no sienta mi alma sola\n" +
"Quiero escarparme de este eterno anochecer\n" +
"Dice mucha gente que los hombres nunca lloran\n" +
"Pero yo he tenido que volver a mi niñez una vez mas\n" +
"Me sigo preguntando\n" +
"Porque te sigo amando y dejaste sangrando mis heridas\n" +
"No puedo colmarte ni de joyas ni dinero\n" +
"Pero puedo darte un corazón que es verdadero\n" +
"Mis alas en el viento necesitan de tus besos\n" +
"Acompáñame en el viaje que volar solo no puedo\n" +
"Y sabes que eres la princesa de mis sueños encantados\n" +
"Cuantas guerras he librado por tenerte aquí a mi lado\n" +
"No me canso de buscarte, no me importara arriesgarte\n" +
"Si al final de esta aventura yo lograra conquistarte\n" +
"Y he pintado a mi princesa en un cuadro imaginario\n" +
"Le cantaba en el oído susurrando muy despacio\n" +
"Tanto tiempo he naufragado y yo se que no fue en vano\n" +
"No he dejado de intentarlo, porque creo en los milagros\n" +
"Sigo caminando en el desierto del deseo\n" +
"Tantas madrugadas me he perdido en el recuerdo\n" +
"Viviendo el desespero\n" +
"Muriendo en la tristeza por no haber cambiar ese destino\n" +
"No puedo colmarte ni de joyas ni dinero\n" +
"Pero puedo darte un corazón que es verdadero\n" +
"Mis alas en el viento necesitan de tus besos\n" +
"Acompáñame en el viaje que volar solo no puedo\n" +
"Y sabes que eres la princesa de mis sueños encantados\n" +
"Cuantas guerras he librado por tenerte aquí a mi lado\n" +
"No me canso de buscarte, no me importara arriesgarte\n" +
"Si al final de esta aventura yo lograra conquistarte\n" +
"Y he pintado a mi princesa en un cuadro imaginario\n" +
"Le cantaba en el oído susurrando muy despacio\n" +
"Tanto tiempo he naufragado y yo se que no fue en vano\n" +
"No he dejado de intentarlo, porque creo en los milagros", "Yo pensé que podía quedarme sin ti y no puedo\n" +
"Es difícil mi amor, mas difícil de lo que pensé\n" +
"He dejado mi puerta entreabierta\n" +
"Y entraste tu sin avisar\n" +
"No te apartes de mi oh no\n" +
"\n" +
"Yo pensé que con tanta experiencia\n" +
"Conocías todo\n" +
"Y contigo aprendí que al amor no le importa\n" +
"Quien sabe mas\n" +
"Y que el tiempo en nosotros no existe\n" +
"Por todo lo que veo en ti\n" +
"No te apartes de mi oh no oh no\n" +
"\n" +
"Todo amor que yo espere de la vida\n" +
"Lo he encontrado solo en ti\n" +
"Y resulta que tu no estas aquí\n" +
"Esos aires de quien no sabe nada\n" +
"Me han sabido hacer feliz\n" +
"No te apartes de mi oh no ho no\n" +
"\n" +
"No pensé que ese aire inocente\n" +
"Me enseñase el mundo\n" +
"En las cosas bonitas tan simples\n" +
"Que siempre me dices\n" +
"Por la falta que me haces aquí\n" +
"Y por todo lo que veo en ti\n" +
"No te apartes de mi oh no oh no\n" +
"\n" +
"Todo amor que yo espere de la vida\n" +
"Lo he encontrado solo en ti\n" +
"Y resulta que tu no estas aquí\n" +
"Esos aires de quien no sabe nada\n" +
"Me han sabido hacer feliz\n" +
"\n" +
"No te apartes de mi oh no ho no\n" +
"No te apartes de mi oh no ho no\n" +
"No te apartes de mi oh no ho no\n" +
"No te apartes de mi oh no ho no","When your legs don't work like they used to before\n" +
"And I can't sweep you off of your feet\n" +
"Will your mouth still remember the taste of my love?\n" +
"Will your eyes still smile from your cheeks?\n" +
"\n" +
"And, darling, I will be loving you 'til we're 70\n" +
"And, baby, my heart could still fall as hard at 23\n" +
"And I'm thinking 'bout how people fall in love in mysterious ways\n" +
"Maybe just the touch of a hand\n" +
"Well, me—I fall in love with you every single day\n" +
"And I just wanna tell you I am\n" +
"\n" +
"So, honey, now\n" +
"Take me into your loving arms\n" +
"Kiss me under the light of a thousand stars\n" +
"Place your head on my beating heart\n" +
"I'm thinking out loud\n" +
"Maybe we found love right where we are\n" +
"\n" +
"When my hair's all but gone and my memory fades\n" +
"And the crowds don't remember my name\n" +
"When my hands don't play the strings the same way (mmm...)\n" +
"I know you will still love me the same\n" +
"\n" +
"'Cause, honey, your soul could never grow old, it's evergreen\n" +
"And, baby, your smile's forever in my mind and memory\n" +
"I'm thinking 'bout how people fall in love in mysterious ways\n" +
"Maybe it's all part of a plan\n" +
"Well, I'll just keep on making the same mistakes\n" +
"Hoping that you'll understand\n" +
"\n" +
"That, baby, now\n" +
"Take me into your loving arms\n" +
"Kiss me under the light of a thousand stars\n" +
"Place your head on my beating heart\n" +
"Thinking out loud\n" +
"Maybe we found love right where we are (oh, oh)\n" +
"\n" +
"La, la, la, la, la, la, la, la, lo-ud\n" +
"\n" +
"So, baby, now\n" +
"Take me into your loving arms\n" +
"Kiss me under the light of a thousand stars\n" +
"Oh, darling, place your head on my beating heart\n" +
"I'm thinking out loud\n" +
"But maybe we found love right where we are\n" +
"Oh, baby, we found love right where we are\n" +
"And we found love right where we are","Aunque muy fuerte sea el aguacero\n" +
"Si tú estás conmigo, ya no me da miedo\n" +
"Tú eres mi refugio y eres mi techo, yeah\n" +
"Aunque se caiga en pedazos el cielo\n" +
"O a veces el partido se sienta perdido\n" +
"Y mis castillos de arena se vengan al suelo\n" +
"Tú\n" +
"Cuando se me ilumina la vida\n" +
"Eres tú\n" +
"Haciéndome saltar la pared\n" +
"Amor\n" +
"Te siento cerca cuando estamos lejos\n" +
"Porque te llevo aquí en mi corazón\n" +
"No sé perderme de tu amor\n" +
"Quizá mañana cuando estemos viejos\n" +
"Y se nos arrugue un poco el corazón\n" +
"Sabré querer mejor (Eh)\n" +
"Dicen que este amor pasa una vez en la vida\n" +
"Y, a veces, puedo jurar que tus besos son poesía\n" +
"Sincronicidad, solo tú me das\n" +
"Tú haces mi sueño realidad\n" +
"No soy yo, si no estás conmigo\n" +
"Quiero verme al final contigo\n" +
"Amor\n" +
"Te siento cerca cuando estamos lejos\n" +
"Porque te llevo aquí en mi corazón\n" +
"No sé perderme de tu amor\n" +
"Quizá mañana cuando estemos viejos\n" +
"Y se nos arrugue un poco el corazón\n" +
"Sabré querer mejor\n" +
"Cuando te veo, mi noche se hace de día\n" +
"Porque viniste tú a curar lo que dolía\n" +
"Como dos espejos viendo su reflejo\n" +
"Tu sonrisa me da vida\n" +
"Amor\n" +
"Te siento cerca cuando estamos lejos\n" +
"Porque te llevo aquí en mi corazón\n" +
"No sé perderme de tu amor\n" +
"Quizá mañana cuando estemos viejos\n" +
"Y se nos arrugue un poco el corazón\n" +
"Sabré querer mejor (Mejor)\n" +
"Sabré querer mejor\n" +
"Sabré querer mejor", "Aunque muy fuerte sea el aguacero\n" +
"Si tú estás conmigo, ya no me da miedo\n" +
"Tú eres mi refugio y eres mi techo, yeah\n" +
"Aunque se caiga en pedazos el cielo\n" +
"O a veces el partido se sienta perdido\n" +
"Y mis castillos de arena se vengan al suelo\n" +
"Tú\n" +
"Cuando se me ilumina la vida\n" +
"Eres tú\n" +
"Haciéndome saltar la pared\n" +
"Amor\n" +
"Te siento cerca cuando estamos lejos\n" +
"Porque te llevo aquí en mi corazón\n" +
"No sé perderme de tu amor\n" +
"Quizá mañana cuando estemos viejos\n" +
"Y se nos arrugue un poco el corazón\n" +
"Sabré querer mejor (Eh)\n" +
"Dicen que este amor pasa una vez en la vida\n" +
"Y, a veces, puedo jurar que tus besos son poesía\n" +
"Sincronicidad, solo tú me das\n" +
"Tú haces mi sueño realidad\n" +
"No soy yo, si no estás conmigo\n" +
"Quiero verme al final contigo\n" +
"Amor\n" +
"Te siento cerca cuando estamos lejos\n" +
"Porque te llevo aquí en mi corazón\n" +
"No sé perderme de tu amor\n" +
"Quizá mañana cuando estemos viejos\n" +
"Y se nos arrugue un poco el corazón\n" +
"Sabré querer mejor\n" +
"Cuando te veo, mi noche se hace de día\n" +
"Porque viniste tú a curar lo que dolía\n" +
"Como dos espejos viendo su reflejo\n" +
"Tu sonrisa me da vida\n" +
"Amor\n" +
"Te siento cerca cuando estamos lejos\n" +
"Porque te llevo aquí en mi corazón\n" +
"No sé perderme de tu amor\n" +
"Quizá mañana cuando estemos viejos\n" +
"Y se nos arrugue un poco el corazón\n" +
"Sabré querer mejor (Mejor)\n" +
"Sabré querer mejor\n" +
"Sabré querer mejor"};
	SecureRandom sr = new SecureRandom();
	/**
	 * Creates new form NewJFrame
	 */
	public GestionPrincesa() {
		initComponents();
	}

	/**
	 * This method is called from within the constructor to initialize the
	 * form. WARNING: Do NOT modify this code. The content of this method is
	 * always regenerated by the Form Editor.
	 */
	@SuppressWarnings("unchecked")
        // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
        private void initComponents() {

                jScrollPane1 = new javax.swing.JScrollPane();
                TextAreaLinks = new javax.swing.JTextArea();
                jLabel1 = new javax.swing.JLabel();
                txtDia = new javax.swing.JTextField();
                txtMes = new javax.swing.JTextField();
                txtAnio = new javax.swing.JTextField();
                btnProbar = new javax.swing.JButton();
                jLabel2 = new javax.swing.JLabel();
                jLabel3 = new javax.swing.JLabel();
                jLabel4 = new javax.swing.JLabel();
                btnSorpresa = new javax.swing.JButton();
                btnLetras = new javax.swing.JButton();

                setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

                TextAreaLinks.setBackground(new java.awt.Color(255, 255, 204));
                TextAreaLinks.setColumns(20);
                TextAreaLinks.setRows(5);
                jScrollPane1.setViewportView(TextAreaLinks);

                jLabel1.setText("INGRESE UNA FECHA IMPORTANTE");

                btnProbar.setBackground(new java.awt.Color(255, 204, 204));
                btnProbar.setText("Probar");
                btnProbar.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnProbarActionPerformed(evt);
                        }
                });

                jLabel2.setText("Dia");

                jLabel3.setText("Mes");

                jLabel4.setText("Año");

                btnSorpresa.setBackground(new java.awt.Color(204, 255, 204));
                btnSorpresa.setText("Sorpresa");
                btnSorpresa.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnSorpresaActionPerformed(evt);
                        }
                });

                btnLetras.setText("Adivina");
                btnLetras.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                btnLetrasActionPerformed(evt);
                        }
                });

                javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
                getContentPane().setLayout(layout);
                layout.setHorizontalGroup(
                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane1)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(117, 117, 117)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(btnProbar)
                                                                .addGap(58, 58, 58)
                                                                .addComponent(btnSorpresa))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addComponent(jLabel1)
                                                                .addGap(39, 39, 39)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(txtDia, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(jLabel2))
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(txtMes, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(jLabel3))))
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                        .addComponent(jLabel4)
                                                                        .addComponent(txtAnio, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(48, 48, 48)
                                                                .addComponent(btnLetras)))
                                                .addGap(0, 158, Short.MAX_VALUE)))
                                .addContainerGap())
                );
                layout.setVerticalGroup(
                        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(33, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel1)
                                        .addComponent(txtDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtAnio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel4))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnProbar)
                                        .addComponent(btnSorpresa)
                                        .addComponent(btnLetras))
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
                );

                pack();
        }// </editor-fold>//GEN-END:initComponents

        private void btnProbarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProbarActionPerformed
		// TODO add your handling code here:
		Fecha fechaPublicacion = agregarFecha();
		if (fechaPublicacion != null) {
			if ((Integer.parseInt(txtDia.getText()) == 28) && (Integer.parseInt(txtMes.getText()) == 2) && (Integer.parseInt(txtAnio.getText()) == 2020)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" + "https://www.youtube.com/watch?v=JxxUmYLWnig");
			} else if ((Integer.parseInt(txtDia.getText()) == 14) && (Integer.parseInt(txtMes.getText()) == 6) && (Integer.parseInt(txtAnio.getText()) == 2020)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" + "https://www.youtube.com/watch?v=tJOu5ukveiQ");
			} else if ((Integer.parseInt(txtDia.getText()) == 14) && (Integer.parseInt(txtMes.getText()) == 7) && (Integer.parseInt(txtAnio.getText()) == 2020)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" +"https://www.youtube.com/watch?v=oofSnsGkops");
			} else if ((Integer.parseInt(txtDia.getText()) == 2) && (Integer.parseInt(txtMes.getText()) == 9) && (Integer.parseInt(txtAnio.getText()) == 2000)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" +"https://www.youtube.com/watch?v=KoosHqQQgBc");
			} else if ((Integer.parseInt(txtDia.getText()) == 2) && (Integer.parseInt(txtMes.getText()) == 4) && (Integer.parseInt(txtAnio.getText()) == 2019)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" +"https://www.youtube.com/watch?v=OukQDrJ7QRQ");
			} else if ((Integer.parseInt(txtDia.getText()) == 29) && (Integer.parseInt(txtMes.getText()) == 2) && (Integer.parseInt(txtAnio.getText()) == 2020)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" +"https://www.youtube.com/watch?v=3SC0Ze4ta9o");
			}else if ((Integer.parseInt(txtDia.getText()) == 29) && (Integer.parseInt(txtMes.getText()) == 2) && (Integer.parseInt(txtAnio.getText()) == 2020)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" +"https://www.youtube.com/watch?v=TdN5GyTl8K0");
			}else if ((Integer.parseInt(txtDia.getText()) == 29) && (Integer.parseInt(txtMes.getText()) == 2) && (Integer.parseInt(txtAnio.getText()) == 2020)){
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" +"https://www.youtube.com/watch?v=2Vv-BfVoq4g");
			}else {
			TextAreaLinks.setText("Copia y sigue el link espero te guste este detalle\n" +"Porque cualquier fecha a tu lado es importante mi amor, igual prueba de nuevo \n https://www.youtube.com/watch?v=Mcj75l2gJcY");
			}
		}

        }//GEN-LAST:event_btnProbarActionPerformed

        private void btnSorpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSorpresaActionPerformed
                // TODO add your handling code here:
		sr.nextBytes(new byte[1]);
		int i = sr.nextInt(frases.length);
		String frase = frases[i];
		TextAreaLinks.setText("Mi pequeña, no te imaginas cuanto te amo, no quiero que lo olvides nunca\nsi alguna vez te sientes triste dale a sorpresa\n veras algo de lo que pienso por ti\n///////////////////////////////////////////////\n"+frase.toUpperCase());
        }//GEN-LAST:event_btnSorpresaActionPerformed

        private void btnLetrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLetrasActionPerformed
                // TODO add your handling code here:
		sr.nextBytes(new byte[1]);
		int i = sr.nextInt(letras.length);
		String letra = letras[i];
		TextAreaLinks.setText("CANCIONES QUE SIEMPRE ME HACEN PENSAR EN TI\n///////////////////////////////////////////////\n"+letra.toUpperCase());
        }//GEN-LAST:event_btnLetrasActionPerformed
	public Fecha agregarFecha() {
		String mensajeError;

		try {
			int dia = Integer.parseInt(txtDia.getText());
			int mes = Integer.parseInt(txtMes.getText());
			int anio = Integer.parseInt(txtAnio.getText());
			boolean fechaValida = false;

			if (mes > 0 && mes < 13 && anio < 2021 && dia > 0) {
				boolean mes31Dias = mes == 1 || mes == 3 || mes == 5 || mes == 7
					|| mes == 8 || mes == 10 || mes == 12;
				boolean mes30Dias = mes == 4 || mes == 6 || mes == 9 || mes == 11;
				boolean mesFebrero = mes == 2;

				if (mes31Dias) {
					fechaValida = dia < 32;
				} else if (mes30Dias) {
					fechaValida = dia < 31;
				} else if (mesFebrero) {
					fechaValida = dia < 29;
				}
			}

			if (fechaValida) {
				return new Fecha(dia, mes, anio);
			} else {
				mensajeError = "Formato de fecha debe ser dd/mm/aa\nEjemplo: 29/08/2000";
				JOptionPane.showMessageDialog(rootPane, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);
			}
		} catch (Exception e) {
			System.err.println("una excepcion " + e.toString());
			mensajeError = "Formato de fecha debe ser dd/mm/aa\nEjemplo: 29/08/2000";
			JOptionPane.showMessageDialog(rootPane, mensajeError, "Error", JOptionPane.ERROR_MESSAGE);

		}
		return null;
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
		/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(GestionPrincesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(GestionPrincesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(GestionPrincesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(GestionPrincesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		//</editor-fold>
		//</editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new GestionPrincesa().setVisible(true);
			}
		});
	}

        // Variables declaration - do not modify//GEN-BEGIN:variables
        private javax.swing.JTextArea TextAreaLinks;
        private javax.swing.JButton btnLetras;
        private javax.swing.JButton btnProbar;
        private javax.swing.JButton btnSorpresa;
        private javax.swing.JLabel jLabel1;
        private javax.swing.JLabel jLabel2;
        private javax.swing.JLabel jLabel3;
        private javax.swing.JLabel jLabel4;
        private javax.swing.JScrollPane jScrollPane1;
        private javax.swing.JTextField txtAnio;
        private javax.swing.JTextField txtDia;
        private javax.swing.JTextField txtMes;
        // End of variables declaration//GEN-END:variables
}
