/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber10;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Asistente extends Persona implements Payable{
	private String jornada;
	private int nivel;

	public String getJornada() {
		return jornada;
	}

	public void setJornada(String jornada) {
		this.jornada = jornada;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	@Override
	public double pay() {
		double pago;
		if (this.jornada.equals("Matutina") && nivel == 1){
			pago = 450;
			return pago;
		}else if (this.jornada.equals("Matutina") && nivel == 2){
			pago = 495;
			return pago;
		}else if (this.jornada.equals("Vespertina") && nivel == 1){
			pago = 560;
			return pago;
		}else if (this.jornada.equals("Vespertina") && nivel == 2){
			pago = 616;
			return pago;
		}else{
			return 0;
		}
	}

	@Override
	public String toString() {
		return "Asistente de enfermeria\n" + "nombre: "+this.nombre
			+"\napellido: "+this.apellido+ "\njornada: " 
			+ jornada + "\nnivel: " + nivel;
	}
	
}










