/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber10;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Proveedor implements Payable {
	private String razon;
	private long ruc;
	private String tipo;

	public String getRazon() {
		return razon;
	}

	public void setRazon(String razon) {
		this.razon = razon;
	}

	public long getRuc() {
		return ruc;
	}

	public void setRuc(long ruc) {
		this.ruc = ruc;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String proveedor) {
		this.tipo = proveedor;
	}

	
	@Override
	public double pay() {
		double pago;
		switch (tipo) {
			case "A":
				pago = 5000;
				return pago;
			case "B":
				pago = 2200;
				return pago;
			default:
				return 0;
		}
	}

	@Override
	public String toString() {
		return "Proveedor\n" + "razon social: " + razon 
			+ "\nRUC: " + ruc + "\ntipo de proveedor: " + tipo ;
	}
	
}










