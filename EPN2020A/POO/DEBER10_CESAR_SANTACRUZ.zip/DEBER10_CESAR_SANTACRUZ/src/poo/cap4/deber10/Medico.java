/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber10;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Medico extends Persona implements Payable {
	private String codigo;
	private double tarifa;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public double getTarifa() {
		return tarifa;
	}

	public void setTarifa(double tarifa) {
		this.tarifa = tarifa;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	@Override
	public double pay() {
		double pago = (40*tarifa) + (120*(tarifa*1.05));
		return pago;
	}

	@Override
	public String toString() {
		return "Medico\n" + "nombre: " + this.nombre + "\napellido: "
			+ this.apellido + "\ncodigo: " + this.codigo 
			+ "tarifa: " + this.tarifa;
	}

}









