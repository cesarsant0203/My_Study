/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap1.ej2;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestRaton {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //entrada.nextline(),
        Scanner input = new Scanner(System.in);
        System.out.println("Por favor ingrese el peso");

        try {
            double peso;
            peso = input.nextDouble();
            System.out.println("Por favor ingrese la tasa de crecimiento");
            double tasa;
            tasa = input.nextDouble();
            System.out.println("Por favor ingrese los la cantidad de dias iniciales");
            int edad;
            edad = input.nextInt();
            System.out.println("Por favor ingrese los la cantidad de dias de crecimiento");
            int duracion;
            duracion = input.nextInt();

            //////////////////////////////////////////////////////////////
            Raton gus;//vairable de la clase raton, se toma de la clase
            gus = new Raton(peso, edad);//se crea una instancia con una memoria asignada para el peso, edad
            gus.setTasaCrecimientoPorcentual(tasa);
            gus.crecer(duracion);
            System.out.println();
            if (gus.esAdolescente() == true) {
                System.out.println("Jaq es un adolecente");
            }
            if (!gus.esAdolescente()) {
                System.out.print("Jaq no es un adolecente");
            }
            System.out.println(gus.toString());
            System.out.println("////////// Raton Gus //////////");
        } catch (InputMismatchException e) {
            System.err.println("una excepcion " + e.toString());
            System.err.println("La proxima ingresar un input que corresponda al t"
                    + "ipo de input que se pide ");
        }
        catch (Exception e) {
            System.err.println("una excepcion " + e.toString());
        }
        /*catch (InputMismatchException e) {
            System.err.println("una excepcion " + e.toString());
        }*/
        /////////////////////////////////////////////////////////////
        /*Raton alse = new Raton(); // declaracion e inicializacion 
        alse.setTasaCrecimientoPorcentual(20);
        alse.setDias(duracion);
        System.out.println("////////// Raton Alce //////////");
        alse.desplegar();
        alse.crecer();
        alse.desplegar();
        ////////////////////////////////////////////////////////////
        Raton jaq = new Raton(); // declaracion e inicializacion 
        jaq.setTasaCrecimientoPorcentual(30);
        jaq.setDias(4);
        System.out.println("////////// Raton jaq //////////");
        jaq.desplegar();
        jaq.crecer();
        jaq.desplegar();
         */
        ////////////////////////Clase 09/06/2020////////////////////////////////////
        //System.out.println("Edad de jaq: " + jaq.getEdad() + jaq.toString());//

        ////////////////////////////////////////////////////////////
        /*Raton lola = new Raton(4.0, 6);
        System.out.println(lola.toString());*/
        /////////////////////////////////////////////////////////
        /*
        Raton jaq = new Raton (6.0,4,"jaq");
        Raton lola = new Raton (6.0,4,"lola");
        if (lola.equals(jaq))
            System.out.println("Son iguales");
        else
            System.out.println("no son iguales");
        lola.setTasaCrecimientoPorcentual(50);
        lola.crecer();
        
        System.out.println(lola.toString());
        
        Veterinario vet = new Veterinario();
        
        String ml = vet.diagnosticar(lola);
        
        System.out.println(ml);
         */
    }

}
