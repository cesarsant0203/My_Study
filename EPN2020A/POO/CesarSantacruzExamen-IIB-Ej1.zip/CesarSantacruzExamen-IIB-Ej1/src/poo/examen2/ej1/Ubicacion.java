/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen2.ej1;

import java.util.Comparator;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Ubicacion implements Comparator<Ubicacion>, Comparable<Ubicacion> {

	private double coordenadaX;
	private double coordenadaY;

	public Ubicacion(double coordenadaX, double coordenadaY) {
		this.coordenadaX = coordenadaX;
		this.coordenadaY = coordenadaY;
	}

	@Override
	public String toString() {
		return "Ubicacion{" + "latitud=" + coordenadaX + ", longitud=" + coordenadaY + '}';
	}

	public double getCoordenadaX() {
		return coordenadaX;
	}

	public void setCoordenadaX(double coordenadaX) {
		this.coordenadaX = coordenadaX;
	}

	public double getCoordenadaY() {
		return coordenadaY;
	}

	public void setCoordenadaY(double coordenadaY) {
		this.coordenadaY = coordenadaY;
	}

	@Override
	public int compareTo(Ubicacion otraUbicacion) {
		if (this.coordenadaX < otraUbicacion.getCoordenadaX()) {
			return -1;
		}
		if (this.coordenadaX == otraUbicacion.getCoordenadaX()) {
			return 0;
		}
		return 1;
	}

	@Override
	public int compare(Ubicacion u1, Ubicacion u2) {
		if (u1.getCoordenadaY() < u2.getCoordenadaY()) {
			return -1;
		}
		if (u1.getCoordenadaY() == u2.getCoordenadaY()) {
			return 0;
		}
		return 1;
	}
}

