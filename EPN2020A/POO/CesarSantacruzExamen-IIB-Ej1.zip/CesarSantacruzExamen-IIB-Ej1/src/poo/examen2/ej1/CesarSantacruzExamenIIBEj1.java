/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen2.ej1;

import java.util.Collections;
import java.util.LinkedList;

/**
 *
 * @author Cesar J. Santacruz
 */
public class CesarSantacruzExamenIIBEj1 {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here
		LinkedList<Ubicacion> ubicaciones = new LinkedList<Ubicacion>();
		ubicaciones.add(new Ubicacion(2.1,3.5));
		ubicaciones.add(new Ubicacion(1.1,2.4));
		ubicaciones.add(new Ubicacion(3.4,1.2));
		ubicaciones.add(new Ubicacion(2.1,1.1));
		ubicaciones.add(new Ubicacion(1.2,3.4));
		
		Collections.sort(ubicaciones);
        System.out.println("Ordene ubicaciones con el orden natural: coordenada X asc.\n");
        System.out.println(ubicaciones);
        
        System.out.println("\nMuestre en pantalla la ubicación con el mayor valor en la coordenada Y\n");
        System.out.println(Collections.max(ubicaciones, new MayorY()));
	}
	
}






















