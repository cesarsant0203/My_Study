/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber8;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Empleado {

	protected String nombre;
	protected String apellido;
	protected int numeroSeguro;
	protected double ganancia;

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public void setNumeroSeguro(int numeroSeguro) {
		this.numeroSeguro = numeroSeguro;
	}

	public void calcularGanancia(double ganancia) {
		this.ganancia = ganancia;
	}
}


