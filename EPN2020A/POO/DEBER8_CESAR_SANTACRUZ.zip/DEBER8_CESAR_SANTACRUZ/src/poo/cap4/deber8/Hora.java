/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber8;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Hora extends Empleado{
	private final double base = 4.5;

	public void setGanancia(double ganancia) {
		this.ganancia = ganancia;
	}

	/**
	 *
	 * @param horas valor de horas sobre el cual se genera la ganancia
	 */
	@Override
	public void calcularGanancia(double horas){
		this.ganancia = base*horas;
	}

	@Override
	public String toString() {
		return  "/////////////////////////////////////////////////////\n"
			+"Empleado\n"
			+ "Nombre: " + nombre
			+ "\nApellido: " + apellido
			+ "\nNumero de seguro: " + numeroSeguro
			+ "\nGanancia del empleado " + nombre.toUpperCase().charAt(0) + "." + apellido.toUpperCase().charAt(0) + " : $" + ganancia + "\n"
			+"/////////////////////////////////////////////////////\n";
	}
	
}




















