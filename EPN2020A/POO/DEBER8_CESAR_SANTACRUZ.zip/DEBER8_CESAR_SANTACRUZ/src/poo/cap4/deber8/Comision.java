/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.deber8;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Comision extends Empleado {
	private final double base = 150;
	

	public void setGanancia(double ganancia) {
		this.ganancia = ganancia;
	}

	/**
	 *
	 * @param ventas valor de ventas sobre el cual se genera la ganancia
	 */
	@Override
	public void calcularGanancia(double ventas) {
		this.ganancia = base + ventas * 0.15;
	}

	@Override
	public String toString() {
		return "/////////////////////////////////////////////////////\n"
			+ "Empleado\n"
			+ "Nombre: " + nombre
			+ "\nApellido: " + apellido
			+ "\nNumero de seguro: " + numeroSeguro
			+ "\nGanancia del empleado " + nombre.toUpperCase().charAt(0) + "." + apellido.toUpperCase().charAt(0) + " : $" + ganancia + "\n"
			+ "/////////////////////////////////////////////////////\n";
	}
}







