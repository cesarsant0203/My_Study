/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdm.sem3.tests;

import java.util.ArrayList;
import java.util.Scanner;
import sdm.sem3.services.Account;
import sdm.sem3.services.Atm;

/**
 *
 * @author Cesar J. Santacruz
 */
public class TestWirhdrawal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Account> accounts = new ArrayList<>();
        accountCreation(accounts);
        System.out.println("B");
        divider();
        divider();
        System.out.println("\t\t    WELCOME TO A SANTACRUZ ATM");
        divider();
        divider();
        int accountEntered = enterAccount();
        int accountIndex = findAccountIndex(accounts, accountEntered);
        if (accountIndex != -1) {
            Scanner optionsInput = new Scanner(System.in);
            int selectedOption = -1;
            boolean isSelectedOptionNumber = false;
            do {
                while (isSelectedOptionNumber == false) {
                    divider();
                    divider();
                    System.out.println("Please select an option number");
                    System.out.println("Please select 1 if you want to withdraw"
                            + " money from your account");
                    System.out.println("Please select 0 if you want to cancel t"
                            + "he operation and exit");
                    if (optionsInput.hasNextInt()) {
                        selectedOption = optionsInput.nextInt();
                        isSelectedOptionNumber = true;
                    } else {
                        System.out.println("That is not a number,"
                                + " please try again");
                    }
                    optionsInput.nextLine();
                }
                switch (selectedOption) {
                    case 0:
                        System.out.println("Thanks for using Santacruz ATMs");
                        System.exit(0);
                    case 1:
                        divider();
                        divider();
                        double withdrawalAmount = amountCheck();
                        Atm atm = new Atm();
                        atm.setAccount(accounts.get(accountIndex));
                        atm.extractAmount(withdrawalAmount);
                        divider();
                        divider();
                        selectMoreOperations();
                        break;

                    default:
                        divider();
                        divider();
                        System.out.println("That is not a valid option");
                        divider();
                        divider();
                        break;
                }

            } while (selectedOption != 0);
        } else {
            System.out.println("Sorry we have not find your account.");
        }
    }

    public static void divider() {
        System.out.println("//////////////////////////////////"
                + "////////////////////////////////////");
    }

    public static int findAccountIndex(ArrayList<Account> accounts, double accountEntered) {
        int accountTempIndex = -1;
        for (int i = 0; i < accounts.size(); i++) {
            if (accounts.get(i).getAccountNumber() == accountEntered) {
                accountTempIndex = i;
            } else {
            }
        }
        return accountTempIndex;
    }

    public static void selectMoreOperations() {
        int anotherOperation;
        Scanner anotherImput = new Scanner(System.in);
        boolean isNumber = false;
        while (isNumber == false) {
            System.out.println("Do you want to make another withdraw?");
            System.out.println("'Yes' answer 1");
            System.out.println("'No'  answer with other number");
            if (anotherImput.hasNextInt()) {
                anotherOperation = anotherImput.nextInt();
                isNumber = true;
                if (anotherOperation != 1) {
                    System.out.println("Thanks for using Santacruz ATMs");
                    System.exit(0);
                } else {
                    System.out.println("OK");
                }
                divider();
                divider();
            } else {
                System.out.println("That is not a number, please try again");
            }
            anotherImput.nextLine();
        }
    }

    public static void accountCreation(ArrayList<Account> accounts) {
        Account account1 = new Account(1111111, 4502);
        Account account2 = new Account(2222222, 0);
        Account account3 = new Account(3333333, 1000000);
        Account account4 = new Account(4444444, 45);
        Account account5 = new Account(5555555, 2);
        Account account6 = new Account(6666666, 524542);
        Account account7 = new Account(7777777, 425);
        Account account8 = new Account(8888888, 23);
        accounts.add(account1);
        accounts.add(account2);
        accounts.add(account3);
        accounts.add(account4);
        accounts.add(account5);
        accounts.add(account6);
        accounts.add(account7);
        accounts.add(account8);
    }

    public static int enterAccount() {
        int accountEntered = 0;
        Scanner accountKeyboardInput = new Scanner(System.in);
        boolean isAccountNumber = false;
        while (isAccountNumber == false) {
            System.out.println("Please enter the account number");
            if (accountKeyboardInput.hasNextInt()) {
                accountEntered = accountKeyboardInput.nextInt();
                isAccountNumber = true;
            } else {
                System.out.println("That is not a number, please try again");
            }
            accountKeyboardInput.nextLine();
        }
        return accountEntered;
    }

    public static double amountCheck() {
        double withdrawalAmount = 0;
        Scanner withdrawalAmountInput = new Scanner(System.in);
        boolean isWithdrawalAmountNumber = false;
        while (isWithdrawalAmountNumber == false) {
            System.out.println("Enter the amount you want to withdr"
                    + "aw");
            if (withdrawalAmountInput.hasNextDouble()) {
                withdrawalAmount = withdrawalAmountInput.nextDouble();
                isWithdrawalAmountNumber = true;
            } else {
                System.out.println("That is not a number, please try again");
            }
            withdrawalAmountInput.nextLine();
        }
        return withdrawalAmount;
    }
}
