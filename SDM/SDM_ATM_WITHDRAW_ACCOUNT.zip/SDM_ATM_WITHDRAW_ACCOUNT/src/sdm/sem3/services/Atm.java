/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdm.sem3.services;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Atm {

    private Account account;
    private String location;
    private double amount;

    public Atm() {
    }

    public void extractAmount(double amountToBeWithdrawn) {
        this.amount = amountToBeWithdrawn;
        account.withdrawAmount(this.amount);
    }

    public void setAccount(Account account) {
        this.account = account;
    }

}
