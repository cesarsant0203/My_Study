/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdm.sem3.services;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Account {

    private int accountNumber;
    private double balance;

    public Account(int accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public void withdrawAmount(double amount) {
        if (this.balance >= amount) {
            this.balance = this.balance - amount;
            System.out.println(amount + " dollars have been withdrawn from the #"
                    + "####" + (accountNumber % 100) + " account.");
            System.out.println("The current balance of the #####"
                    + (accountNumber % 100) + " account is " + this.balance
                    + " dollars.");
        } else {
            System.out.println("Insufficient balance in #####"
                    + (accountNumber % 100) + " account");
        }
    }

    public int getAccountNumber() {
        return accountNumber;
    }

}
