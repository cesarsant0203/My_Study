package com.cmc.capacitacion.excepciones;

public class Ejercicio3 {

    public static void main(String[] args) {
        System.out.println("INICIA");
        String a = null;
        try {
            a = "abc";
            a.toLowerCase();
            System.out.println("Despues del null pointer");
        } catch (Exception e) {
            System.out.println("entra al catch");
        }finally{
            System.out.println("entra al final");
        }
        System.out.println("Finaliza");
    }

}
