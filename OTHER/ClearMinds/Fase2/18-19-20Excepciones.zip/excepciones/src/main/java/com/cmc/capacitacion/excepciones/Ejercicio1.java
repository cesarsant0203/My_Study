package com.cmc.capacitacion.excepciones;

public class Ejercicio1 {

    public static void main(String[] args) {
        System.out.println("Inicia");
        String a = null;
        String b= a.toLowerCase();//unchecked
        System.out.println(b);
        System.out.println("Finaliza");
    }
    
}
