package com.cmc.estaticos;

public class Util {

    public void test() {
        System.out.println("test");
    }

    public static void test1() {
        System.out.println("test1");
    }
}
