package com.cmc.estaticos;

public class Contador {

    private int contador;
    private static int contadorEstatico;

    public void incrementar() {
        contador++;
        contadorEstatico++;
    }

    public void imprimir() {
        System.out.println("contador: " + contador);
        System.out.println("contador estatico: " + contadorEstatico);
    }
}
