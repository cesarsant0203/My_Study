package com.cmc.estaticos;

public class Constantes {

    private final int NUM_PAGINAS = 0;
    public static final int NUM_REGISTROS = 5;

    public void test() {
        System.out.println(NUM_PAGINAS);
        System.out.println(NUM_REGISTROS);
    }
}
