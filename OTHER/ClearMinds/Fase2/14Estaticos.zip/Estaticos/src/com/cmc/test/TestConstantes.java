package com.cmc.test;

import com.cmc.estaticos.Constantes;

public class TestConstantes {

    public static void main(String[] args) {
        /*Constantes cons = new Constantes();
        int val = cons.numRegistros;*/

        int val = Constantes.NUM_REGISTROS;
        System.out.println(val);
        double pi = Math.PI;
        System.out.println(pi);
    }

}
