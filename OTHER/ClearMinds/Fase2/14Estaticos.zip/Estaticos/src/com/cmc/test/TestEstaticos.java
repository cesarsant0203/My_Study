package com.cmc.test;

import com.cmc.estaticos.Util;

public class TestEstaticos {

    public static void main(String[] args) {
        Util u = new Util();
        u.test();

        Util u1 = new Util();
        u1.test();

        Util.test1();

        double res = Math.random();
        System.out.println(res);

        int valor = Integer.parseInt("23");
        System.out.println(valor);
    }

}
