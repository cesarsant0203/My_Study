package com.cmc.herencia;

public class Animal {
    public void dormir(){
        System.out.println("Animal durmiendo");
    }
}
