package com.cmc.test;

import com.cmc.herencia.Animal;
import com.cmc.herencia.Perro;


public class TestAnimal {

    public static void main(String[] args) {
        Perro p = new Perro();
        p.dormir();
        p.ladrar();
        Animal a = new Animal();
        a.dormir();
    }
    
}
