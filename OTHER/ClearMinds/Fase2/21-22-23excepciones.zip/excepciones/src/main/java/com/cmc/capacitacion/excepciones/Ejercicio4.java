package com.cmc.capacitacion.excepciones;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Ejercicio4 {

    public void metodo1() {
        File f = new File("archivo1.txt");
        try {
            f.createNewFile();
        } catch (IOException e) {

        }
    }

    public void metodo2() throws Exception {
        File f = new File("archivo1.txt");
        f.createNewFile();
    }
    
    public void metodo3() {
        try {
            metodo2();
        } catch (Exception ex) {
            Logger.getLogger(Ejercicio4.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
