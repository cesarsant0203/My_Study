package com.cmc.capacitacion.excepciones;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Ejercicio6 {

    private static final Logger logger = LogManager.getLogger(Ejercicio6.class);

    public static void main(String[] args) {
        String a = null;

        try {
            String b = a.toLowerCase(); //Exception
            System.out.println(b);
            logger.debug("La variable b: "+b);
        } catch (Exception e) {
            logger.error("error al convertir",e);
            System.out.println("Sistema no disponible, consulte con el administrador");
        }

    }

}
