package com.cmc.capacitacion.excepciones;

public class TestAdminCliente {

    public static void main(String[] args) {
        AdminCliente ac = new AdminCliente();
        int x = 0;
        try {
            x = ac.calcular(10, 20);
            System.out.println(x);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
    }

}
