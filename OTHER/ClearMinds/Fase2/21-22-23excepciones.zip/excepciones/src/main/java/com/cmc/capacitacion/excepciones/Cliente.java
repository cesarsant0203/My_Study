package com.cmc.capacitacion.excepciones;

public class Cliente {
    
}
