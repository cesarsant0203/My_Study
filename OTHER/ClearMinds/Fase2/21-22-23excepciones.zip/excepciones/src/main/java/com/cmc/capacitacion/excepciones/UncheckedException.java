package com.cmc.capacitacion.excepciones;

public class UncheckedException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UncheckedException(String mensaje) {
            super.getMessage();
    }

}
