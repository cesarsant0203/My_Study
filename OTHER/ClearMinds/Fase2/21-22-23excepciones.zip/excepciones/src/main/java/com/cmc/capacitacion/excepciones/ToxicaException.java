
package com.cmc.capacitacion.excepciones;

public class ToxicaException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ToxicaException(String mensaje){
        
    }
}
