package com.cmc.capacitacion.excepciones;

import java.io.File;
import java.io.IOException;

public class Ejercicio2 {

    public static void main(String[] args) {
        File f = new File("archivo1.txt");
        try {
            f.createNewFile();//checked
        } catch (IOException e) {

        }
    }

}
