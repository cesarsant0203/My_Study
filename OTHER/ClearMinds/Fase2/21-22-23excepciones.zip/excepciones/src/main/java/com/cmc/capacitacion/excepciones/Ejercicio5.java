
package com.cmc.capacitacion.excepciones;

public class Ejercicio5 {

    public void metodo1(){
        
    }
    
    public void metodo2(){
        
    }
    
    public void metodo3(){
        
    }
    
}
