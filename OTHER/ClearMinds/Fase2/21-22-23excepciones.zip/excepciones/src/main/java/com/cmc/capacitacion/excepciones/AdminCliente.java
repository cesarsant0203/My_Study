package com.cmc.capacitacion.excepciones;

public class AdminCliente {
    //Si encuentra el cliente en la base de datos
    //retorna el cliente con sus datos
    //si no existe retorna null
    public Cliente buscar(String cedula) throws Exception{
        //se conecta a la bdd -- se cae o no logra conectarse
        //consulta el cliente
        //retorna cliente o null
        return null;
        //se conecta a la bdd -- se cae o no logra conectarse
        //consulta el cliente
        //retorna cliente o null
    }
    public int calcular(int x, int y) throws Exception{
        if(x<0){
            throw new Exception("No se permiten valores negativos");
        }
        return x+y;
    }
    
    public int calcular2(int x, int y){
        if(x<0){
            throw new RuntimeException("No se permiten valores negativos");
        }
        return x+y;
    }
}
