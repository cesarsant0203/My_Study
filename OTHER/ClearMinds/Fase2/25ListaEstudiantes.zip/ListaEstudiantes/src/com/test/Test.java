package com.test;

import java.util.ArrayList;

public class Test {

    public static void main(String[] args) {
        ArrayList<Estudiante> estudiantes = new ArrayList<>();
        estudiantes.add(new Estudiante("A", "B", "1"));
        estudiantes.add(new Estudiante("C", "V", "2"));
        estudiantes.add(new Estudiante("F", "B", "3"));
        Estudiante est = null;
        System.out.println("Convencional for");
        for (int i = 0; i < estudiantes.size(); i++) {
            est = estudiantes.get(i);
            System.out.println(est.getCedula());
            System.out.println(est.getNombre());
            System.out.println(est.getApellido());
            System.out.println("");
        }

        System.out.println("Enhanced for");
        for (Estudiante est2 : estudiantes) {
            System.out.println(est2.getCedula());
            System.out.println(est2.getNombre());
            System.out.println(est2.getApellido());
            System.out.println("");
        }

        System.out.println("Funcional operations");
        estudiantes.stream().map(est2 -> {
            System.out.println(est2.getCedula());
            return est2;
        }).map(est2 -> {
            System.out.println(est2.getNombre());
            return est2;
        }).map(est2 -> {
            System.out.println(est2.getApellido());
            return est2;
        }).forEachOrdered(_item -> {
            System.out.println("");
        });

    }
}
