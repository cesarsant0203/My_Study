package constructores;


/**
 *
 * @author Cesar J. Santacruz
 */
public class TestPersona {

    public static void main(String[] args) {
        System.out.println("prueba");
        int a;
        Persona p; //Declaro la variable p de tipo Persona
        p = new Persona();// Instancio un objeto Persona
        System.out.println("Nombre: " + p.getNombre());
        System.out.println("Edad: " + p.getEdad());
        System.out.println("Estatura: " + p.getEstatura());
        p.setNombre("Juan");
        p.setEdad(12);
        p.setEstatura(1.35);
        System.out.println("Nombre: " + p.getNombre());
        System.out.println("Edad: " + p.getEdad());
        System.out.println("Estatura: " + p.getEstatura());
        Persona p2 = new Persona();
        p2.setNombre("Santiago");
        p2.setEdad(23);
        p2.setEstatura(1.34);
        System.out.println("Nombre: " + p2.getNombre());
        System.out.println("Edad: " + p2.getEdad());
        System.out.println("Estatura: " + p2.getEstatura());
        Persona p3 = new Persona("Mario", 25, 2.01);
        System.out.println("Nombre: " + p3.getNombre());
        System.out.println("Edad: " + p3.getEdad());
        System.out.println("Estatura: " + p3.getEstatura());
    }

}
