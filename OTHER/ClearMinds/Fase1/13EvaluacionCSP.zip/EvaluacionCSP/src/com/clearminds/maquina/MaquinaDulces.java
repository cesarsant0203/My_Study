package com.clearminds.maquina;

import com.clearminds.componentes.Celda;
import com.clearminds.componentes.Producto;
import java.util.ArrayList;

public class MaquinaDulces {

    //atributos
    private Celda celda1;
    private Celda celda2;
    private Celda celda3;
    private Celda celda4;
    private double saldo;

    //Metodos
    public void configurarMaquina(String codigo1, String codigo2, String codigo3, String codigo4) {
        this.celda1 = new Celda(codigo1);
        this.celda2 = new Celda(codigo2);
        this.celda3 = new Celda(codigo3);
        this.celda4 = new Celda(codigo4);
    }

    public void mostrarConfiguracion() {
        System.out.println("CELDA 1:" + this.celda1.getCodigo());
        System.out.println("CELDA 2:" + this.celda2.getCodigo());
        System.out.println("CELDA 3:" + this.celda3.getCodigo());
        System.out.println("CELDA 4:" + this.celda4.getCodigo());
    }

    public Celda buscarCelda(String codigo) {
        ArrayList<Celda> celdas = new ArrayList<>();
        celdas.add(this.celda1);
        celdas.add(this.celda2);
        celdas.add(this.celda3);
        celdas.add(this.celda4);
        for (int i = 0; i < celdas.size(); i++) {
            if (celdas.get(i).getCodigo().equals(codigo)) {
                return celdas.get(i);
            }
        }
        return null;
    }

    public void cargarProducto(Producto producto, String codigo, int cantidad) {
        Celda celdaRecuperada = buscarCelda(codigo);
        celdaRecuperada.ingresarProducto(producto, cantidad);
    }

    public void mostrarProductos() {
        ArrayList<Celda> celdas = new ArrayList<>();
        celdas.add(this.celda1);
        celdas.add(this.celda2);
        celdas.add(this.celda3);
        celdas.add(this.celda4);
        for (int i = 0; i < celdas.size(); i++) {
            System.out.println("***********CELDA " + celdas.get(i).getCodigo());
            System.out.println(" Stock:" + celdas.get(i).getStock());
            if (celdas.get(i).getProducto() != null) {
                System.out.println(" Nombre producto:" + celdas.get(i).getProducto().getNombre());
                System.out.println(" Precio producto:" + celdas.get(i).getProducto().getPrecio());
                System.out.println(" Codigo producto:" + celdas.get(i).getProducto().getCodigo());
            } else {
                System.out.println(" La celda no tiene producto!!!");
            }
        }
        System.out.println("Saldo: " + this.saldo);
    }

    public Producto buscarProductoEnCelda(String codigo) {
        Celda res1 = buscarCelda(codigo);
        if (res1 != null) {
            Producto res2 = res1.getProducto();
            if (res2 != null) {
                return res2;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public double consultarPrecio(String codigo) {
        Producto res1 = buscarProductoEnCelda(codigo);
        if (res1 != null) {
            double res2 = res1.getPrecio();
            return res2;
        } else {
            return -1;
        }
    }

    public Celda buscarCeldaProducto(String codigo) {
        ArrayList<Celda> celdas = new ArrayList<>();
        celdas.add(this.celda1);
        celdas.add(this.celda2);
        celdas.add(this.celda3);
        celdas.add(this.celda4);
        for (int i = 0; i < celdas.size(); i++) {
            if (celdas.get(i).getProducto() != null) {
                if (celdas.get(i).getProducto().getCodigo().equals(codigo)) {
                    return celdas.get(i);
                }
            }
        }
        return null;
    }

    public void incrementarProductos(String codigo, int cantidad) {
        Celda celdaEncontrada = buscarCeldaProducto(codigo);
        celdaEncontrada.setStock(celdaEncontrada.getStock() + cantidad);
    }

    public void vender(String codigo) {
        Celda celdaEncontrada = buscarCelda(codigo);
        celdaEncontrada.setStock(celdaEncontrada.getStock() - 1);
        double precioEncontrado = celdaEncontrada.getProducto().getPrecio();
        this.saldo += precioEncontrado;
        mostrarProductos();
    }

    public double venderConCambio(String codigo, double valorIngresado) {
        Celda celdaEncontrada = buscarCelda(codigo);
        celdaEncontrada.setStock(celdaEncontrada.getStock() - 1);
        double precioEncontrado = celdaEncontrada.getProducto().getPrecio();
        this.saldo += precioEncontrado;
        return valorIngresado - precioEncontrado;
    }
}
