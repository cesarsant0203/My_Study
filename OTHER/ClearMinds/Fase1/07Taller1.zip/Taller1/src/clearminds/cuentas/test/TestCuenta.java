package clearminds.cuentas.test;

import clearminds.cuentas.Cuenta;

public class TestCuenta {

    public static void main(String[] args) {
        //Creo el objeto Cuenta y lo referencio con cuenta1
        Cuenta cuenta1 = new Cuenta("03476");
        //Coloco un valor de saldo en la cuenta1 
        cuenta1.setSaldo(675);
        //Creo el objeto Cuenta y lo referencio con cuenta2
        Cuenta cuenta2 = new Cuenta("03476", "C", 98);
        //Creo el objeto Cuenta y lo referencio con cuenta3 
        Cuenta cuenta3 = new Cuenta("03476");
        //Modifico el tipo de cuenta
        cuenta3.setTipo("C");
        //Imprimo cuenta1, cuenta2 y cuenta3
        System.out.println("--------Valores Iniciales---------");
        cuenta1.imprimir();
        cuenta2.imprimir();
        cuenta3.imprimir();
        System.out.println("--------Valores modificados---------");
        //modifico el saldo de la cuenta 1
        cuenta1.setSaldo(444);
        //modifico el saldo de la cuenta 3
        cuenta3.setSaldo(567);
        //modifico el tipo de la cuenta 2
        cuenta2.setTipo("D");
        //imprimo los nuevos valores de cuenta1, cuenta2 y cuenta3
        cuenta1.imprimir();
        cuenta2.imprimir();
        cuenta3.imprimir();
        /*Creo una cuenta4 y la referencio con cuenta4,
        la creo con el constructur que solo recibe el Id*/
        Cuenta cuenta4 = new Cuenta("0987");
        //modifico el saldo de la cuenta4
        cuenta4.setSaldo(10);
        // Creo una cuenta5 y la referencio con cuenta5
        Cuenta cuenta5 = new Cuenta("0557", "C", 10);
        // Creo una cuenta6 y la referencio con cuenta6
        Cuenta cuenta6 = new Cuenta("0666");
        //imprimo los valores de cuenta4, cuenta5 y cuenta6
        cuenta4.imprimirConMiEstilo();
        cuenta5.imprimirConMiEstilo();
        cuenta6.imprimirConMiEstilo();
    }

}
