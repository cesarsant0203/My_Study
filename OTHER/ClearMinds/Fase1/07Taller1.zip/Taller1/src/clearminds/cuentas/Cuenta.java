package clearminds.cuentas;

public class Cuenta {

    //atributos
    private String id;
    private String tipo;
    private double saldo;

    //constructores
    public Cuenta(String id) {
        this.id = id;
        this.tipo = "A";
    }

    public Cuenta(String id, String tipo, double saldo) {
        this.id = id;
        this.tipo = tipo;
        this.saldo = saldo;
    }

    //metodos
    //getter y setter
    public String getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    //otros metodos
    public void imprimir() {
        System.out.println("********************\n");
        System.out.println("CUENTA\n");
        System.out.println("********************\n");
        System.out.println("Número de Cuenta: " + this.id + "\n");
        System.out.println("Tipo: " + this.tipo + "\n");
        System.out.println("Saldo: USD " + this.saldo + "\n");
        System.out.println("********************");
    }

    public void imprimirConMiEstilo() {
        String linea = "///////////////////////////////////////"
                + "////////////////////////";
        System.out.println(linea);
        System.out.println("\t\t\tBIENVENID@");
        System.out.println(linea + "\n");
        System.out.println("\t\t\t  CUENTA\n");
        System.out.println(linea + "\n");
        System.out.println("Número de Cuenta:");
        System.out.println(this.id + "\n");
        System.out.println("Tipo:");
        System.out.println(this.tipo + "\n");
        System.out.println("Saldo:");
        System.out.println("USD " + this.saldo + "\n");
        System.out.println(linea + "\n");
    }
}
