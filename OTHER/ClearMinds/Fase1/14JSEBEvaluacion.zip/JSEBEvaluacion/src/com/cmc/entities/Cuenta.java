package com.cmc.entities;

public class Cuenta {

    //atributos
    private String codigo;
    private TipoCuenta tipo;
    private double saldo;

    //constructores
    public Cuenta(String codigo, TipoCuenta tipo) {
        this.codigo = codigo;
        this.tipo = tipo;
    }

    public Cuenta(String codigo, double saldo, TipoCuenta tipo) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.saldo = saldo;
    }

    public Cuenta() {

    }

    //metodos
    public boolean validarSaldo(double saldo) {
        return saldo >= 0;
    }

    //getter y setter
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public TipoCuenta getTipo() {
        return tipo;
    }

    public void setTipo(TipoCuenta tipo) {
        this.tipo = tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
