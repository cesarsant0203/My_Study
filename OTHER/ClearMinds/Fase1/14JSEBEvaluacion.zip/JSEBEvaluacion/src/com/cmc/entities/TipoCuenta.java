package com.cmc.entities;

public class TipoCuenta {

    //atributos
    private int codigo;
    private String nombre;

    //constructores
    public TipoCuenta(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    //metodos
    public int obtenerValorRecargo() {
        if (this.codigo <= 10) {
            return 20;
        } else if (this.codigo > 10 && this.codigo < 20) {
            return 30;
        } else if (this.codigo >= 20) {
            return 40;
        } else {
            return 0;
        }
    }

    //getter y setter
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
    
}
