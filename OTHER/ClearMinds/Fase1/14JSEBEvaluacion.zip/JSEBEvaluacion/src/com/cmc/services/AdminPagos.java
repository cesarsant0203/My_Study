package com.cmc.services;

import com.cmc.entities.Cliente;
import com.cmc.entities.Cuenta;
import com.cmc.entities.TipoCuenta;
import com.clearminds.entidades.Prestamo;

public class AdminPagos {

    //metodos
    public void asignarCuenta(Cliente cliente, Cuenta cuenta) {
        cliente.setCuenta(cuenta);
    }

    public void depositar(double saldo, Cliente cliente) {
        boolean res = cliente.getCuenta().validarSaldo(saldo);
        if (res == true) {
            int res2 = cliente.getCuenta().getTipo().obtenerValorRecargo();
            cliente.getCuenta().setSaldo(saldo * res2);

        } else {
            System.out.println("No se puede depositar");
        }
    }

    public void retirar(double saldo, Cliente cliente) {
        boolean res = cliente.getCuenta().validarSaldo(saldo);
        if (res == true) {
            double res2 = cliente.getCuenta().getSaldo();
            cliente.getCuenta().setSaldo(res2 - saldo);

        } else {
            System.out.println("No se puede retirar");
        }
    }

    public TipoCuenta obtenerTipoCuenta(Cliente cliente) {
        return cliente.getCuenta().getTipo();
    }
    
    public String mostrarPrestamo(Cliente cliente){
        Prestamo prestamo = new Prestamo();
        double res = prestamo.obtenerPrestamo(cliente.getCuenta().getSaldo());
        if(res<500){
            return "Prestamo A";
        }else if(res>= 500 && res<=1000){
            return "Prestamo B";
        }else if(res>1000){
            return "Prestamo C";
        }else{
            return "No se puede obtener prestamo";
        }
    }
}
