package com.cmc.entities;

public class Cliente {

    //atributos
    private String cedula;
    private String nombres;
    private Cuenta cuenta;

    //constructores
    public Cliente(String cedula, String nombres) {
        this.cedula = cedula;
        this.nombres = nombres;
    }

    public Cliente(String cedula, String nombres, Cuenta cuenta) {
        this.cedula = cedula;
        this.nombres = nombres;
    }

    //metodos
    public void imprimir() {
        System.out.println("**************CLIENTE ************************");
        System.out.println("Nombre: " + this.nombres);
        System.out.println("Cedula: " + this.cedula);
        if (this.cuenta != null) {
            System.out.println("---------------CUENTA ------------------------");
            System.out.println("Codigo:  " + this.cuenta.getCodigo());
            System.out.println("Tipo: " + this.cuenta.getTipo());
            System.out.println("Saldo Actual: " + this.cuenta.getSaldo());
            System.out.println("**********************************************\n");
        } else {
            System.out.println("---------------CUENTA ------------------------");
            System.out.println("El cliente aun no tiene una cuenta asociada");
            System.out.println("**********************************************\n");
        }
    }

    //getter y setter
    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

}
