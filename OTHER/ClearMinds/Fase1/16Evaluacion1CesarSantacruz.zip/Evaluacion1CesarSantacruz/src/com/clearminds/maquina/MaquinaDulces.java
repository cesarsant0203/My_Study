package com.clearminds.maquina;

import com.clearminds.componentes.Celda;
import com.clearminds.componentes.Producto;
import java.util.ArrayList;

public class MaquinaDulces {

    //atributos
    private ArrayList<Celda> celdas = new ArrayList<>();
    private double saldo;

    //Metodos
    public void agregarCelda(String codigo) {
        Celda celda = new Celda(codigo);
        celdas.add(celda);
    }

    public void mostrarConfiguracion() {
        for (int i = 0; i < celdas.size(); i++) {
            System.out.println("CELDA:" + celdas.get(i).getCodigo());
        }
    }

    public Celda buscarCelda(String codigo) {
        for (int i = 0; i < celdas.size(); i++) {
            if (celdas.get(i).getCodigo().equals(codigo)) {
                return celdas.get(i);
            }
        }
        return null;
    }

    public void cargarProducto(Producto producto, String codigo, int cantidad) {
        Celda celdaRecuperada = buscarCelda(codigo);
        celdaRecuperada.ingresarProducto(producto, cantidad);
    }

    public void mostrarProductos() {
        for (int i = 0; i < celdas.size(); i++) {
            System.out.print("CELDA:" + celdas.get(i).getCodigo());
            System.out.print(" Stock:" + celdas.get(i).getStock());
            if (celdas.get(i).getProducto() != null) {
                System.out.print(" Producto:" + celdas.get(i).getProducto().getNombre());
                System.out.print(" Precio:" + celdas.get(i).getProducto().getPrecio() + "\n");
            } else {
                System.out.print(" Sin Producto asignado\n");
            }
        }
    }

    public Producto buscarProductoEnCelda(String codigo) {
        Celda res1 = buscarCelda(codigo);
        if (res1 != null) {
            Producto res2 = res1.getProducto();
            if (res2 != null) {
                return res2;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public double consultarPrecio(String codigo) {
        Producto res1 = buscarProductoEnCelda(codigo);
        if (res1 != null) {
            double res2 = res1.getPrecio();
            return res2;
        } else {
            return -1;
        }
    }

    public Celda buscarCeldaProducto(String codigo) {
        for (int i = 0; i < celdas.size(); i++) {
            if (celdas.get(i).getProducto() != null) {
                if (celdas.get(i).getProducto().getCodigo().equals(codigo)) {
                    return celdas.get(i);
                }
            }
        }
        return null;
    }

    public void incrementarProductos(String codigo, int cantidad) {
        Celda celdaEncontrada = buscarCeldaProducto(codigo);
        celdaEncontrada.setStock(celdaEncontrada.getStock() + cantidad);
    }

    public void vender(String codigo) {
        Celda celdaEncontrada = buscarCelda(codigo);
        celdaEncontrada.setStock(celdaEncontrada.getStock() - 1);
        double precioEncontrado = celdaEncontrada.getProducto().getPrecio();
        this.saldo += precioEncontrado;
        mostrarProductos();
    }

    public double venderConCambio(String codigo, double valorIngresado) {
        Celda celdaEncontrada = buscarCelda(codigo);
        celdaEncontrada.setStock(celdaEncontrada.getStock() - 1);
        double precioEncontrado = celdaEncontrada.getProducto().getPrecio();
        this.saldo += precioEncontrado;
        return valorIngresado - precioEncontrado;
    }

    public ArrayList<Producto> buscarMenores(double limite) {
        ArrayList<Producto> menores = new ArrayList<>();
        for (int i = 0; i < celdas.size(); i++) {
            Producto prod = celdas.get(i).getProducto();
            if (prod != null) {
                if (prod.getPrecio() <= limite) {
                    menores.add(prod);
                }
            }
        }
        return menores;
    }
}
