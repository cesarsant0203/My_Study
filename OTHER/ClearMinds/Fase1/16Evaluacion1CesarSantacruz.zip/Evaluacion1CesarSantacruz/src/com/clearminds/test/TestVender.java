package com.clearminds.test;

import com.clearminds.componentes.Producto;
import com.clearminds.maquina.MaquinaDulces;

public class TestVender {

	public static void main(String[] args) {
		MaquinaDulces maquiDulces=new MaquinaDulces();
		maquiDulces.agregarCelda("C1");
                maquiDulces.agregarCelda("D1");
                maquiDulces.agregarCelda("E1");
                maquiDulces.agregarCelda("F1");
		
		Producto p1=new Producto("CE5A","Gomitas",2.99);
                Producto p2=new Producto("SAM1","Chocolates",1.40);
                Producto p3=new Producto("S2C3","Chupetes",0.17);
		maquiDulces.cargarProducto(p1, "C1", 100);
		maquiDulces.cargarProducto(p2, "D1", 27);
		maquiDulces.cargarProducto(p3, "E1", 28);
		
		maquiDulces.vender("C1");
		maquiDulces.vender("E1");
                maquiDulces.vender("C1");
                maquiDulces.vender("D1");
		
		maquiDulces.mostrarProductos();

	}

}
