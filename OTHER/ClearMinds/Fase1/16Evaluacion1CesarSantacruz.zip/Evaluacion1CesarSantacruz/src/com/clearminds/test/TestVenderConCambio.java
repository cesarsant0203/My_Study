package com.clearminds.test;

import com.clearminds.componentes.Producto;
import com.clearminds.maquina.MaquinaDulces;

public class TestVenderConCambio {

	public static void main(String[] args) {
		MaquinaDulces maquiDulces=new MaquinaDulces();
		maquiDulces.agregarCelda("G1");
                maquiDulces.agregarCelda("H1");
                maquiDulces.agregarCelda("I1");
		
		Producto p1=new Producto("S3RE","Oreos",0.99);
                Producto p2=new Producto("JO55","Mani",3.75);
                Producto p3=new Producto("KA3R","Chicle",0.25);
		maquiDulces.cargarProducto(p1, "G1", 5);
		maquiDulces.cargarProducto(p2, "H1", 2);
		maquiDulces.cargarProducto(p3, "I1", 3);
		
		maquiDulces.vender("G1");
		double cambio = maquiDulces.venderConCambio("H1",10);
		double cambio2 = maquiDulces.venderConCambio("I1",0.50);
		maquiDulces.mostrarProductos();	
		System.out.println("SU CAMBIO ES:"+(cambio+cambio2));
		
	}

}
