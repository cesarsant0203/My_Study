package com.clearminds.test;

import com.clearminds.componentes.Producto;
import com.clearminds.maquina.MaquinaDulces;
import java.util.ArrayList;

public class TestBuscarMenores {
    
    public static void main(String[] args) {
        MaquinaDulces maquiDulces = new MaquinaDulces();
        maquiDulces.agregarCelda("C1");
        maquiDulces.agregarCelda("D1");
        maquiDulces.agregarCelda("E1");
        maquiDulces.agregarCelda("F1");
        maquiDulces.agregarCelda("G1");
        maquiDulces.agregarCelda("H1");
        Producto p1 = new Producto("CE5A", "Gomitas", 2.99);
        Producto p2 = new Producto("SAM1", "Choco", 1.40);
        Producto p3 = new Producto("S2C3", "Chupetes", 0.17);
        Producto p4 = new Producto("S3RE", "Oreos", 0.99);
        Producto p5 = new Producto("JO55", "Mani", 3.75);
        Producto p6 = new Producto("KA3R", "Chicle", 0.25);
        maquiDulces.cargarProducto(p1, "C1", 10);
        maquiDulces.cargarProducto(p2, "D1", 7);
        maquiDulces.cargarProducto(p3, "E1", 8);
        maquiDulces.cargarProducto(p4, "F1", 5);
        maquiDulces.cargarProducto(p5, "G1", 2);
        maquiDulces.cargarProducto(p6, "H1", 3);
        ArrayList<Producto> menores = maquiDulces.buscarMenores(5);
        for (int i = 0; i < menores.size(); i++) {
            System.out.println(menores.get(i));
        }
    }
    
}
