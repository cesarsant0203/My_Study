package metodos;

/**
 *
 * @author Cesar J. Santacruz
 */
public class TestCalculadora {

    public static void main(String[] args) {
        //variables
        int resultadoSuma = 0;
        double resultadoResta = 0;
        double resultadoMultiplicacion = 0;
        Calculadora calcu = new Calculadora();
        Rectangulo r1 = new Rectangulo();
        Rectangulo r2 = new Rectangulo();

        //Test clase calculadora
        resultadoSuma = calcu.sumar(10, 5);
        System.out.println("Resultado suma: " + resultadoSuma);
        resultadoResta = calcu.restar(10, 5);
        System.out.println("Resultado resta: " + resultadoResta);
        resultadoMultiplicacion = calcu.multiplicar(10, 5);
        System.out.println("Resultado multiplicacion: " + resultadoMultiplicacion);

        //Test clase Rectangulo
        System.out.println("r1 base: " + r1.base);
        System.out.println("r1 base: " + r1.altura);
        int resultadoPerimetroR1 = r1.calcularPerimetro();
        System.out.println("resultado perimetro r1: " + resultadoPerimetroR1);
        r1.base = 10;
        r1.altura = 5;
        resultadoPerimetroR1 = r1.calcularPerimetro();
        System.out.println("resultado perimetro r1: " + resultadoPerimetroR1);
        r2.base = 19;
        r2.altura = 25;
        int resultadoAreaR1 = r1.calcularArea();
        System.out.println("resultado area r1: " + resultadoAreaR1);
        int resultadoAreaR2 = r2.calcularArea();
        System.out.println("resultado area r2: " + resultadoAreaR2);

    }

}
