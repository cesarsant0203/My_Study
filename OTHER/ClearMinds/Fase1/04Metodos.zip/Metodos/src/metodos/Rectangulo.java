package metodos;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Rectangulo {

    public int base;
    public int altura;

    public int calcularPerimetro() {
        int res = (2 * base) + (2 * altura);
        return res;
    }
    public int calcularArea(){
        int res = (base*altura)/2;
        return res;
    }
}
