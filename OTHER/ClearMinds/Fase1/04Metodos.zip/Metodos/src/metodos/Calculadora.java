package metodos;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Calculadora {

    public int sumar(int a, int b) {
        return a + b;
    }

    //restar y multiplicar
    public double restar(double a, double b) {
        return a - b;
    }

    public double multiplicar(double a, double b) {
        return a * b;
    }
}
