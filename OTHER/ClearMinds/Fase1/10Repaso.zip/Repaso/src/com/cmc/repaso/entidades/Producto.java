/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cmc.repaso.entidades;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Producto {

    //atributos
    private String nombre;
    private double precio;

    //constructores
    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    //metodos
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0) {
            this.precio = precio * (-1);
        } else {
            this.precio = precio;
        }
    }

    public double calcularPrecioPromo(int descuento) {
        return this.precio - (this.precio * descuento / 100);
    }

    @Override
    public String toString() {
        return "Producto{" + "nombre=" + nombre + ", precio=" + precio + '}';
    }

}
