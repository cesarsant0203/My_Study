package com.cmc.repaso.entidades;

public class Estudiante {

    //atributos
    private String nombre;
    private double nota;
    private String resultado;

    //constructor
    public Estudiante(String nombre) {
        this.nombre = nombre;
    }

    //metodos
    public void calificar(double nota) {
        this.nota = nota;
        if (this.nota < 8) {
            this.resultado = "F";
        } else {
            this.resultado = "A";
        }
    }

    public String getNombre() {
        return nombre;
    }

    public double getNota() {
        return nota;
    }

    public String getResultado() {
        return resultado;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "nombre=" + nombre + ", nota=" + nota + ", resultado=" + resultado + '}';
    }

}
