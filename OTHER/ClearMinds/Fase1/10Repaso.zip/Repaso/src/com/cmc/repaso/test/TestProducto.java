package com.cmc.repaso.test;

import com.cmc.repaso.entidades.Producto;

public class TestProducto {

    public static void main(String[] args) {
        Producto producto = new Producto("Computador", 799.99);
        producto.setPrecio(-899.99);
        double precioDesc = producto.calcularPrecioPromo(15);
        System.out.println("El precio con descuento es: " + precioDesc);
        System.out.println(producto.toString());
    }

}
