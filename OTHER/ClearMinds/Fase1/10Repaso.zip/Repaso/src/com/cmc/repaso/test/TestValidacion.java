package com.cmc.repaso.test;

import com.cmc.repaso.entidades.Validacion;

public class TestValidacion {

    public static void main(String[] args) {
        Validacion valid = new Validacion();
        boolean isValid = valid.validarMonto(200);
        System.out.println(isValid);
    }
    
}
