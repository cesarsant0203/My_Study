/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdm.sem3.services;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Atm {

    private final Account account;
    private String location;
    private final double amount;

    public Atm(Account account, double amount) {
        this.account = account;
        this.amount = amount;
    }

    public void extractAmount() {
        if (this.account.getBalance() >= this.amount) {
            double newBalance = this.account.getBalance() - this.amount;
            this.account.setBalance(newBalance);
            System.out.println(this.amount + " dollars have been withdrawn from the #"
                    + "####" + (this.account.getAccountNumber() % 100) + " account.");
            System.out.println("The current balance of the #####"
                    + (this.account.getAccountNumber() % 100) + " account is " + this.account.getBalance()
                    + " dollars.");
        } else {
            System.out.println("Insufficient balance in #####"
                    + (this.account.getAccountNumber() % 100) + " account");
        }
    }

}
