/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.grafo.no.dirigido;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class GrafoNoDirigidoTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        Scanner input2 = new Scanner(System.in);
        Scanner inputS = new Scanner(System.in);
        System.out.println("Ingrese el numero de vertices");
        int verticesNum = input.nextInt();
        MatrizAdyacencia matrix = new MatrizAdyacencia(verticesNum);
        /*for (int i = 0; i < verticesNum; i++) {
            for (int j = 0; j < verticesNum; j++) {
                System.out.println("Is vertice " + i
                        + " connected to vertice " + j);
                String answer = inputS.nextLine();
                if (answer.equals("yes") || answer.equals("si")
                        || answer.equals("y")) {
                    matrix.insertarArista(i, j);
                } else {

                }
            }
            System.out.println();
        }*/
        
        for (int i = 0; i < verticesNum; i++) {
            int j = 0;
            while (j <= i) {
                System.out.println("Is vertice " + i+ " connected to vertice " + j);
                String answer = inputS.nextLine();
                if (answer.equals("yes") || answer.equals("si")
                        || answer.equals("y")) {
                    matrix.insertarArista(i, j);
                } else {

                }
                j++;
            }

        }
        matrix.printGraph(matrix.getMatrix());
        System.out.println("Write the nodes of the edge you want to delete");
        int u = input2.nextInt();
        int v = input2.nextInt();
        if (matrix.getMatrix()[u][v]!=0){
        matrix.deleteEdge(1, 1);
        matrix.printGraph(matrix.getMatrix());
        }else{
            System.out.println("There is no connection between those nodes");
            matrix.printGraph(matrix.getMatrix());
        }
    }

}

