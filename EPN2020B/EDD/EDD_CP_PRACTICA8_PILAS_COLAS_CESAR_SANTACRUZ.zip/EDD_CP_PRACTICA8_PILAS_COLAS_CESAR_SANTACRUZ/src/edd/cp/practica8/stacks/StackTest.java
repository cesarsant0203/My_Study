/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica8.stacks;

/**
 *
 * @author Cesar J. Santacruz
 */
public class StackTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MyStack myStack = new MyStack();
        // insert into stack
        myStack.push(02);
        myStack.push(27);
        myStack.push(14);
        myStack.push(28);
        myStack.push(03);
        // print Stack elements
        System.out.println("-Elements of the stack");
        myStack.display();
        // Delete top element of Stack
        System.out.println("-Elements of the stack"
                + "after deleting one:");
        myStack.pop();
        myStack.display();
        System.out.println("-Is the stack empty?");
        if (myStack.isEmpty()) {
            System.out.println("Stack is empty");
        } else {
            System.out.println("Stack is not empty");
        }

        // print Top element of Stack
        System.out.println("-Top element is: "
                + myStack.peek());
        System.out.println("-Stack is going to be clean");
        myStack.cleanStack();
        System.out.println("Elements of the stack");
        myStack.display();
    }
}
