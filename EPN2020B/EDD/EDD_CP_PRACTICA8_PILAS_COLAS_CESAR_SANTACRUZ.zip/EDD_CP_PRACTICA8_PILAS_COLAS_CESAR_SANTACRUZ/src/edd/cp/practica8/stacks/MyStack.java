/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica8.stacks;

/**
 *
 * @author Cesar J. Santacruz
 */
public class MyStack {

    MyNode top;

    // Constructor
    MyStack() {
        this.top = null;
    }

    // i)Method to add an element in the stack
    public void push(int element) {
        // create a temp node
        MyNode temp = new MyNode();
        temp.data = element;
        temp.link = top;
        top = temp;
    }

    // ii)Method to check if the stack is empty or not
    public boolean isEmpty() {
        return top == null;
    }

    // iii)Method to pop top element from the queue
    public void pop() {
        // check if stack is empty
        if (isEmpty()) {
            System.out.println("Stack is empty");
            return;
        }
        // top pointer points to the next node
        
        top = (top).link;
        
    }

    // iv)Method to clean the stack
    public void cleanStack() {
        while (!isEmpty()) {
            pop();
        }
    }

    // v)Method to peek the top element
    public int peek() {
        // check for empty stack
        if (!isEmpty()) {
            return top.data;
        } else {
            System.out.println("Stack is empty");
            return -1;
        }
    }

    // vi)Method to display the stack
    public void display() {
        // check for stack underflow
        if (isEmpty()) {
            System.out.println("Stack is empty");
        } else {
            MyStack tempStack = new MyStack();
            MyNode temp = top;
            while (temp != null) {
                tempStack.push(temp.data);
                // print node data
                System.out.println(temp.data);
                // assign temp link to temp
                this.pop();
                temp = top;
            }
            temp = tempStack.top;
            while (temp != null) {
                this.push(temp.data);
                tempStack.pop();
                temp = tempStack.top;
            }
        }
    }
}
