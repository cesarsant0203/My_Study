/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica8.queue;

import java.util.ArrayList;

/**
 *
 * @author Cesar J. Santacruz
 */
public class CircularQueue {

    private final int size;
    private int front;
    private int rear;

    // Declaring array. 
    private final ArrayList<Integer> queue = new ArrayList<>();

    // Constructor 
    CircularQueue(int size) {
        this.size = size;
        this.front = -1;
        this.rear = -1;
    }

    // i)Method to add an element in the stack
    public void push(int data) {
        //if queue is full. 
        if ((front == 0 && rear == size - 1)
                || (rear == (front - 1) % (size - 1))) {
            System.out.println("Queue overflow");
        } else if (isEmpty()) {
            front = 0;
            rear = 0;
            queue.add(rear, data);
        } else if (rear == size - 1 && front != 0) {
            rear = 0;
            queue.set(rear, data);
        } else {
            rear = (rear + 1);
            if (front <= rear) {
                queue.add(rear, data);
            } else {
                queue.set(rear, data);
            }
        }
    }

    // ii)Method to pop front element from the queue
    public int pop() {
        int temp;
        if (isEmpty()) {
            System.out.print("Queue is Empty");
            return -1;
        }
        temp = queue.get(front);

        // Condition for only one element 
        if (front == rear) {
            front = -1;
            rear = -1;
        } else if (front == size - 1) {
            front = 0;
        } else {
            front = front + 1;
        }
        return temp;
    }

    // iii)Method to check if the queue is empty or not
    public boolean isEmpty() {
        return front == -1;
    }

    // iv)Method to display the queue
    public void display() {
        int temp;
        if (isEmpty()) {
            System.out.print("Queue is Empty");
            return;
        }
        CircularQueue tempQueue = new CircularQueue(size);
        if (rear >= front) {
            for (int i = front; i <= rear; i++) {
                temp = this.pop();
                tempQueue.push(temp);
                System.out.println(temp);
            }
            while (!tempQueue.isEmpty()) {
                temp = tempQueue.pop();
                this.push(temp);
            }
        } else {
            // Loop for printing elements from 
            // front to max size or last index 
            for (int i = front; i < size; i++) {
                temp = this.pop();
                tempQueue.push(temp);
                System.out.println(temp);
            }
            while (!tempQueue.isEmpty()) {
                temp = tempQueue.pop();
                this.push(temp);
            }
            // Loop for printing elements from 
            // 0th index till rear position 
            for (int i = 0; i <= rear; i++) {
                temp = this.pop();
                tempQueue.push(temp);
                System.out.println(temp);
            }
            while (!tempQueue.isEmpty()) {
                temp = tempQueue.pop();
                this.push(temp);
            }
        }
    }

    //v)Method to peek the top element
    public int peek() {
        // check for empty stack
        if (!isEmpty()) {
            return queue.get(front);
        } else {
            System.out.println("QUeue is empty");
            return -1;
        }
    }

    // vi)Method to check if the queue is full or not
    public boolean isFull() {
        return (front == 0 && rear == size - 1)
                || (rear == (front - 1) % (size - 1));
    }
}
