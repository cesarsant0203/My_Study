/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica8.queue;

/**
 *
 * @author Cesar J. Santacruz
 */
public class QueueTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CircularQueue q = new CircularQueue(5);
        System.out.println("-Is the queue empty?");
        if (q.isEmpty()) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Queue is not empty");
        }
        System.out.println("-Queue size = 5");
        System.out.println("-Elements of the queue: ");
        q.push(02);
        q.push(27);
        q.push(14);
        q.push(28);
        q.push(03);
        q.display();
        if (q.isFull()) {
            System.out.println("Queue is full");
        } else {
        }
        System.out.println("-Insert one more element");
        q.push(06);
        System.out.println("-Delete one element");
        // Checking for empty queue. 
        if (!q.isEmpty()) {
            System.out.print("Deleted element = ");
            System.out.println(q.pop());
        }

        System.out.println("-Delete one element");
        // Checking for empty queue. 
        if (!q.isEmpty()) {
            System.out.print("Deleted element = ");
            System.out.println(q.pop());
        }
        System.out.println("-Elements of the queue: ");
        q.display();
        System.out.println("-Element in the front"
                + " of the queue: " + q.peek());
    }
}
