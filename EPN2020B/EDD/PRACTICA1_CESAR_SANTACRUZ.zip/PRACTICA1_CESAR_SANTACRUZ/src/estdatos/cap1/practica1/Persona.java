/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estdatos.cap1.practica1;

import java.util.Objects;

/**
 *
 * @author cesar
 */
public class Persona {

    private String nombre;
    private String apellido;
    private String ci;
    private String provincia;
    private String telefono;
    private String direccion;

    public Persona(String nombre, String apellido, String ci, String telefono,
            String direccion) {
        this.nombre = nombre.toLowerCase();
        this.apellido = apellido.toLowerCase();
        this.ci = ci;
        this.telefono = telefono;
        this.direccion = direccion;

    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }



    public String getDireccion() {
        return direccion;
    }

    
    
    public void cedulaValida(String cedula) {
        Long x;
        x = 2499999999L;

        if (cedula.length() != 10 || Long.parseLong(cedula) > x) {
            this.ci = "0000000000";
        } else {
            //this.ci = cedula;

            long numeroCi = Long.parseLong(cedula);
            long verificador = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long noveno = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long octavo = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long septimo = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long sexto = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long quinto = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long cuarto = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long tercero = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long segundo = numeroCi % 10;
            numeroCi = numeroCi / 10;
            long primero = numeroCi % 10;

            if (noveno * 2 > 9) {
                noveno = (noveno * 2) - 9;
            } else {
                noveno = (noveno * 2);
            }
            if (septimo * 2 > 9) {
                septimo = (septimo * 2) - 9;
            } else {
                septimo = (septimo * 2);
            }
            if (quinto * 2 > 9) {
                quinto = (quinto * 2) - 9;
            } else {
                quinto = (quinto * 2);
            }
            if (tercero * 2 > 9) {
                tercero = (tercero * 2) - 9;
            } else {
                tercero = (tercero * 2);
            }
            if (primero * 2 > 9) {
                primero = (primero * 2) - 9;
            } else {
                primero = (primero * 2);
            }

            long sumImpar = primero + tercero + quinto + septimo + noveno;
            long sumPar = segundo + cuarto + sexto + octavo;
            long sumTotal = sumImpar + sumPar;
            long decenaSup = sumTotal - (sumTotal % 10) + 10;
            long restaSup = decenaSup - sumTotal;
            if (Objects.equals(restaSup, verificador)) {
                this.ci = cedula;
            } else {
                this.ci = "0000000000";
            }
        }
    }


    public void provinciaNatal() {
        switch (this.ci.charAt(0)) {
            case '0' -> {
                switch (this.ci.charAt(1)) {
                    case '1' -> this.provincia = "Azuay";
                    case '2' -> this.provincia = "Bolivar";
                    case '3' -> this.provincia = "Cañar";
                    case '5' -> this.provincia = "Cotopaxi";
                    case '6' -> this.provincia = "Chimborazo";
                    case '7' -> this.provincia = "El Oro";
                    case '8' -> this.provincia = "Esmeraldas";
                    case '4' -> this.provincia = "Carchi";
                    case '9' -> this.provincia = "Guayas";
                    case '0' -> this.provincia = "Pendiente";
                }
            }
            case '1' -> {
                switch (this.ci.charAt(1)) {
                    case '0' -> this.provincia = "Imbabura";
                    case '1' -> this.provincia = "Loja";
                    case '2' -> this.provincia = "Los Rios";
                    case '3' -> this.provincia = "Manabi";
                    case '4' -> this.provincia = "Morona Santiago";
                    case '5' -> this.provincia = "Napo";
                    case '6' -> this.provincia = "Pastaza";
                    case '7' -> this.provincia = "Pichincha";
                    case '8' -> this.provincia = "Tungurahua";
                    case '9' -> this.provincia = "Zamora Chinchipe";
                }
            }
            case '2' -> {
                switch (this.ci.charAt(1)) {
                    case '0' -> this.provincia = "Galapagos";
                    case '1' -> this.provincia = "Sucumbios";
                    case '2' -> this.provincia = "Orellana";
                    case '3' -> this.provincia = "Santo Domingo de los Tsachilas";
                    case '4' -> this.provincia = "Santa Elena";
                }
            }
            default -> this.provincia = "Pendiente";
        }
    }

    @Override
    public String toString() {
        return "\n======================================================================\n"
                + "\tInformacion Persona:\n"
                + "\tNombre= " + this.nombre
                + ",\n\tApellido= " + this.apellido
                + ",\n\tC.I= " + this.ci
                + ",\n\tProvincia natal= " + this.provincia
                + ",\n\tTelefono= " + this.telefono
                + ",\n\tDireccion= " + this.direccion
                + "\n======================================================================\n";
    }
}

