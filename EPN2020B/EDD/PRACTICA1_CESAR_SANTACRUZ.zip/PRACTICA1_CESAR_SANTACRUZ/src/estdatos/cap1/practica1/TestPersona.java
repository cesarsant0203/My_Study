/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estdatos.cap1.practica1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestPersona {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("/////BIENVENID@S/////");
        Scanner input = new Scanner(System.in);
        int opcion = 0;
        ArrayList<Persona> personas = new ArrayList<>();
        do {
            System.out.println("Seleccione el numero de opcion que desea realiz"
                    + "ar");
            System.out.println("Por favor ingrese 1 si desea ingresar una nueva"
                    + " persona");
            System.out.println("Por favor ingrese 2 si desea verificar si una"
                    + " persona tiene el mismo nombre y apellido que otra");
            System.out.println("Por favor ingrese 3 si desea revisar todos los"
                    + " datos de la ultima persona");
            System.out.println("Por favor ingrese 4 si desea verificar si dos"
                    + " personas tienen la misma direccion");
            System.out.println("Por favor ingrese 0 si desea salir en este mome"
                    + "nto del programa");
            opcion = input.nextInt();

            switch (opcion) {
                case 0:
                    System.out.println("Muchas gracias por usar este programa");
                    System.exit(0);
                case 1:
                    System.out.println("///////////////////////////////////////"
                            + "///////////////////////////////");
                    System.out.println("/////////////////////// ingresar u"
                            + "na persona//////////////////////////");
                    String nombre;
                    Scanner select = new Scanner(System.in);
                    System.out.println("Ingrese el nombre");
                    nombre = select.nextLine();
                    String apellido;
                    System.out.println("Ingrese el apellido");
                    apellido = select.nextLine();
                    String ci;
                    System.out.println("Ingrese la cedula de identidad");
                    ci = select.nextLine();
                    String telefono;
                    System.out.println("Ingrese el telefono");
                    telefono = select.nextLine();
                    String direccion;
                    System.out.println("Ingrese la direccion");
                    direccion = select.nextLine();
                    Persona PersonaUno = new Persona(nombre, apellido, ci, telefono, direccion);
                    PersonaUno.cedulaValida(ci);
                    PersonaUno.provinciaNatal();
                    System.out.println(PersonaUno.toString());
                    ;
                    personas.add(PersonaUno);
                    break;
                case 2:
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("///////////// Ver si existen personas "
                            + "con el mismo nombre y apellido //////////////////");
                    for (int i = 0; i < personas.size(); i++) {
                        for (int j = i + 1; j < personas.size(); j++) {
                            // compare list.get(i) and list.get(j)
                            if (personas.get(i).getNombre().equals(personas.get(j).getNombre())) {
                                if (personas.get(i).getApellido().equals(personas.get(j).getApellido())) {
                                    System.out.println("Estos dos tienen el mismo nombre y apellido");
                                    System.out.println(personas.get(j));
                                    System.out.println(personas.get(i));

                                }
                            }
                        }
                    }
                    break;
                case 3:
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("///////////// Mostrar todas las"
                            + " personas ingresadas //////////////////");
                    for (int i = 0; i < personas.size(); i++) {
                        System.out.println(personas.get(i));
                    }
                    System.out.println("////////////////////////// Opcion "
                            + "2 //////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    break;
                case 4:
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("///////////// Ver si existen personas "
                            + "con la misma direccion //////////////////");                    
                    for (int i = 0; i < personas.size(); i++) {
                        for (int j = i + 1; j < personas.size(); j++) {
                            // compare list.get(i) and list.get(j)

                            if (personas.get(i).getDireccion().equals(personas.get(j).getDireccion())) {
                                System.out.println("Estos dos tienen la misma direccion");
                                System.out.println(personas.get(j));
                                System.out.println(personas.get(i));

                            }

                        }
                    }
                    break;
                default:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("Esa no es una opcion valida");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
            }

        } while (opcion != 0);
    }

}
