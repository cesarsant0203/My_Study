/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estdatos.cap1.practica1;

/**
 *
 * @author cesar
 */
public class Rectangulo {

    private double base;
    private double altura;

    //constructores///////////////////////////////////////
    public Rectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;

    }

    //metodos de instancia/////////////////////////////////////////////
    private double area;
    public void calcularArea() {
        this.area = this.base * this.altura;
    }
    
    private double perimetro;
    public void calcularPerimetro() {
        this.perimetro = (this.base * 2) + (this.altura * 2);
    }

    public String acceso() {
        return "base: " + this.base + ", altura: " + this.altura + "\n"
                + "area: " + this.area + ", perimetro: " + this.perimetro;
    }

}
