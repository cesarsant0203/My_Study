/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estdatos.cap1.practica1;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestRectangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("/////BIENVENID@S/////");
        Scanner input = new Scanner(System.in);

                    System.out.println("Por favor ingrese la base");
                    double base = input.nextDouble();
                    while (base < 0) {
                        System.out.println("Por favor ingrese la  base");
                        base = input.nextDouble();
                    }
                    System.out.println("Por favor ingrese la altura");
                    Double altura = input.nextDouble();
                    while (altura < 0) {
                        System.out.println("Por favor ingrese la anchura");
                        altura = input.nextDouble();
                    }
                    Rectangulo rectangulo = new Rectangulo(base, altura);
                    rectangulo.calcularArea();
                    rectangulo.calcularPerimetro();
                    System.out.println(rectangulo.acceso());

    }
    
}
