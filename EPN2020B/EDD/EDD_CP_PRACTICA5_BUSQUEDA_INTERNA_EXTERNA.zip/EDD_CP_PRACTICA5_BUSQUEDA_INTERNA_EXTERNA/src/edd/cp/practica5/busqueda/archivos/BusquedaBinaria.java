/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica5.busqueda.archivos;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class BusquedaBinaria {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        int[] a = {9, 1, 26, 34, 73, 4, 37, 45, 12, 18, 11, 24, 47};
        int size = a.length;
        try{
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el elemento que desea buscar dentro del vector");
        int claveBusqueda = input.nextInt();
        System.out.println("\n\n\t/////////////////////");
        System.out.println("El vector en desorden: " + imprimirLista(a));
        ordenarLista(a, 0, size - 1);
        System.out.println("El vector en orden: " + imprimirLista(a));
        System.out.println("La clave es: "+claveBusqueda);
        int returnValue = busquedaBinaria(a, 0, size - 1, claveBusqueda);
        if (returnValue != -1) {
            System.out.println("El indice donde se encuentra la clave es: " + returnValue);
        } else {
            System.out.println("ERROR: Elemento no encontrado");
        }
        }catch(Exception e){
            System.out.println("Ese valor de entrada no esta permitido");
        }
    }

    public static String imprimirLista(int array[]) {
        String arrayP = "";
        for (int i = 0; i < array.length; i++) {
            arrayP = arrayP + " " + array[i];
        }
        return arrayP;
    }

    public static void ordenarLista(int[] array, int menor, int mayor) {
        int posicionCentro = menor + (mayor - menor) / 2;
        int pivote = array[posicionCentro];
        int i = menor, j = mayor;
        while (i <= j) {
            while (array[i] < pivote) {
                i++;
            }
            while (array[j] > pivote) {
                j--;
            }
            if (i <= j) {
                interchange(array, i, j);
                i++;
                j--;
            }
        }
        if (menor < j) {
            ordenarLista(array, menor, j);
        }
        if (mayor > i) {
            ordenarLista(array, i, mayor);
        }
    }

    public static int busquedaBinaria(int[] a, int bajo, int alto, int searchValue) {
        if (alto >= bajo) {
            int midIndex = bajo + (alto - bajo) / 2;
            if (a[midIndex] == searchValue) {
                return midIndex;
            } else if (a[midIndex] > searchValue) {
                return busquedaBinaria(a, bajo, midIndex - 1, searchValue);
            } else {
                return busquedaBinaria(a, midIndex + 1, alto, searchValue);
            }
        }
        return -1;
    }

    public static void interchange(int vector[], int i, int j) {
        int aux;
        aux = vector[i];
        vector[i] = vector[j];
        vector[j] = aux;
    }
}
