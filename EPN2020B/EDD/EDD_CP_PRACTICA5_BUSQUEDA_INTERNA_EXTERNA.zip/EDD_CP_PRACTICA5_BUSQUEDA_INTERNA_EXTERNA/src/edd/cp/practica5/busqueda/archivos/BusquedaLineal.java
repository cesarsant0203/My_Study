/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica5.busqueda.archivos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class BusquedaLineal {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el elemento que desea buscar dentro del arreglo");
        int valorBuscado = input.nextInt();
        int indiceBusqueda = busquedaLineal(codigoToArray(), valorBuscado);
        System.out.println("\n\n\t/////////////////////");
        imprimirRegistros("codigoProducto.txt");
        if (indiceBusqueda != -1) {
            System.out.println("Producto encontrado");
            System.out.println("La clave es: " + valorBuscado);
            System.out.println("El indice donde se encuentra la clave es: " + indiceBusqueda);
            System.out.println("El registro del archivo es: ");
            imprimirRegistroEncontrado(registroToArray(), indiceBusqueda);
        } else {
            System.out.println("ERROR: Elemento no encontrado");
        }

    }

    public static void imprimirRegistros(String nombreArchivo) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
        String lineaActual;
        while ((lineaActual = br.readLine()) != null) {
            System.out.println(lineaActual);
        }
    }

    public static int busquedaLineal(int[] a, int clave) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] == clave) {
                return i; //posicion del elemento clave
            }
        }
        return -1;
    }

    public static void imprimirRegistroEncontrado(String[] a, int regEncontrado) {

        System.out.println(a[regEncontrado]);
    }

    public static int[] codigoToArray() {
        ArrayList<String> arrayArchivo = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("codigoProducto.txt"))) {
            String lineaActual;
            while ((lineaActual = br.readLine()) != null) {
                arrayArchivo.add(lineaActual.substring(0, 3));

            }
        } catch (IOException e) {
        }
        int[] ret = new int[arrayArchivo.size()];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = Integer.parseInt(arrayArchivo.get(i));
        }
        return ret;
    }

    public static String[] registroToArray() {
        ArrayList<String> arrayArchivo = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("codigoProducto.txt"))) {
            String lineaActual;
            while ((lineaActual = br.readLine()) != null) {
                arrayArchivo.add(lineaActual.substring(4));

            }
        } catch (IOException e) {
        }
        String[] ret = new String[arrayArchivo.size()];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = (arrayArchivo.get(i));
        }
        return ret;
    }

}
