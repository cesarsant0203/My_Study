/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

import java.util.Random;

/**
 *
 * @author Cesar J. Santacruz
 */
public class DoubleCircularList {

    DCNode front = null;

    // Insert into double circular list 
    public void insertFirst(int dd) {
        if (front == null) {//if it is empty
            DCNode newNode = new DCNode(dd);
            newNode.next = newNode.prev = newNode;
            front = newNode;
        } else {
            DCNode last = front.prev;
            DCNode newNode = new DCNode(dd);
            newNode.next = front;
            newNode.prev = last;
            front = newNode;
            last.next = front;
        }
    }
    // ----------------------------------------------

    // delete specific element from list 
    public void deleteNode(int element) {
        if (front == null) {
            System.out.println("Can not delete double"
                    + " circular list is empty");
            return;
        }
        DCNode current = front;
        DCNode previous = front.prev;
        while (current.dData != element) {
            if (current.next == front) {
                System.out.println("Element not found"
                        + " in the double circular"
                        + " list");
                break;
            }
            previous = current;
            current = current.next;
        }
        if (current == front && current.next == front) {
            front = null;
        }else if (current == front) {
            front = current.next;
            previous.next = front;
            front.prev = previous;
        } else if (current.next == front) {
            previous.next = front;
        } else {
            previous.next = current.next;
            current.next.prev = previous;
        }
    }
    // ----------------------------------------------
 
    // display double circular list
    public void displayList() {
        DCNode current = front;//start at the front of list
        if (front == null) {
            System.out.println("Double circular list"
                    + " is empty");
        } else {
            System.out.println("Elements in the double"
                    + " circular list are: ");
            int count = 0;//count how many times is printing
            do {
                current.displayLink();// print dData
                count++;
                if (count % 15 == 0) {//adds new line every 15
                    System.out.print("\n");
                }
                current = current.next;
            } while (current != front);
        }
    }

    // fill the list with random integers numbers
    public static DoubleCircularList fillList() {
        Random rnd;
        rnd = new Random(System.currentTimeMillis());
        int size = (int) (Math.random() * (100 - 1 + 1) + 1);
        DoubleCircularList theList = new DoubleCircularList();
        for (int i = 0; i < size; i++) {
            theList.insertFirst(rnd.nextInt(100));
        }
        return theList;
    }
    // ----------------------------------------------
}
