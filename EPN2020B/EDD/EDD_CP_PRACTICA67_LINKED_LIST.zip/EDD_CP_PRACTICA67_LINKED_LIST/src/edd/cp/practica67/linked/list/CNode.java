/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

/**
 *
 * @author Cesar J. Santacruz
 */
public class CNode {

    public int dData;// data item
    CNode next;
    public CNode(int d) {
        dData = d;
    }
    public void displayLink() // display ourself
    {
        String dLink = String.format("%-3s", dData + " ");
        System.out.print(dLink);
    }
}
