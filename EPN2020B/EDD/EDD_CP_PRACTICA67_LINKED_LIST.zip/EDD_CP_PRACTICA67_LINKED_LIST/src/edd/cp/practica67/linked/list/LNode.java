package edd.cp.practica67.linked.list;

public class LNode {

    public int dData; // data item
    public LNode next; // next node in list
    // -------------------------------------------------------------

    public LNode(int dd) // constructor
    {
        dData = dd; // (next is automatically
    } // set to null)
    // -------------------------------------------------------------

    public void displayLink() // display ourself
    {
        String dLink = String.format("%-3s", dData + " ");
        System.out.print(dLink);
    }
} // end class Link

