/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Test2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkList theList = new LinkList();
        Scanner input = new Scanner(System.in);
        System.out.print("How many elements do"
                + " you want to enter in the"
                + " list? ");
        int election = input.nextInt();
        for (int i = 1; i <= election; i++) {
            System.out.print("Enter element "
                    + i + ": ");
            theList.insertFirst(input.nextInt());
            //System.out.print("\n");
        }
        theList.displayList();
        System.out.print("Enter the item to"
                + " search: ");
        int searchItem = input.nextInt();
        theList.searchInList(searchItem);
    }
}
