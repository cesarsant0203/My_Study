/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

import java.util.Random;

/**
 *
 * @author Cesar J. Santacruz
 */
public class LinkList {

    private LNode first; // ref. to first link on list
    // ----------------------------------------------

    public LinkList() // constructor
    {
        first = null; // no items on list yet
    }
    // ----------------------------------------------

    public boolean isEmpty() // true if list is empty
    {
        return (first == null);
    }
    // ----------------------------------------------
    
    // fill the list with random integers numbers
    public static LinkList fillList() {
        Random rnd = new Random(System.currentTimeMillis());
        int size = (int) (Math.random() * (100 - 1 + 1) + 1);
        LinkList theList = new LinkList();
        for (int i = 0; i < size; i++) {
            theList.insertFirst(rnd.nextInt(100));
        }
        return theList;
    }
    // ----------------------------------------------
    
    // insert at start of list
    public void insertFirst(int dd) { // make new LNode
        LNode newNode = new LNode(dd);
        newNode.next = first; // newNode --> old first
        first = newNode; // first --> newNode
    }
    // ----------------------------------------------

    // delete at start of list
    public LNode deleteFirst() { // delete first item
        LNode temp = first; // save reference to link
        first = first.next; // first-->old next
        return temp; // return deleted link
    }
    // ----------------------------------------------

    // insert at end of list
    public void insertLast(int dd) { // make new LNode
        LNode newLink = new LNode(dd);
        if (first == null) {
            first = newLink;
        } else {
            LNode last = first;
            while (last.next != null) {
                last = last.next;
            }
            last.next = newLink;
        }
    }
    // ----------------------------------------------

    // delete at start of list
    public LNode deleteLast() {
        LNode temp = null; // save reference to link
        if (first.next == null) {// List has 1 LNode
            temp = first;//the only element to temp
            first = null;//delete only element
        } else {
            LNode temp1 = first; //one before temp2
            LNode temp2 = first.next;
            while (temp2.next != null) {
                temp1 = temp2;
                temp2 = temp2.next;
            }
            temp = temp2;
            temp1.next = null;
        }
        return temp; // return deleted link
    }
    // ----------------------------------------------
    
    //display the list
    public void displayList() {
        System.out.println("the items in the list are: ");
        LNode current = first; //start at beginning of list
        int count = 0;//count how many times is printing
        while (current != null) {// until end of list
            current.displayLink(); // print data
            count++;
            if (count % 15 == 0) {//adds new line every 15
                System.out.print("\n");
            }
            current = current.next; // move to next link
        }
        System.out.println("");
    }
    // ----------------------------------------------

    //display even elements of a list
    public void displayEvenList() {
        System.out.println("the even items in the list are: ");
        LNode current = first; // start at beginning of list
        int count = 0;//count how many times is printing
        while (current != null) {// until end of list,
            if (current.dData % 2 == 0) {//even elements
                current.displayLink();
                count++;
                if (count % 15 == 0) {//adds new line every 15
                    System.out.print("\n");
                }
            }
            current = current.next; // move to next link
        }
        System.out.println("");
    }
    // ----------------------------------------------
    public void searchInList(int searchItem){
        LNode current = first;
        int count = 0;
        while (current != null){
            if(current.dData == searchItem){
                count ++;
            }
            current = current.next;
        }
        if(count == 0){
            System.out.println("Element not found.");
        }else{
            System.out.println("Element found "+count
            +" times.");
        }
    }
} // end class LinkList

