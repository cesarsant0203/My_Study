/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Test1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //declare, fill the list
        LinkList theList =  LinkList.fillList();
        //display the list
        theList.displayList();
        //display the even values in the list
        theList.displayEvenList();
    }
}
