/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Test4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        // declare the circular list 
        CircularList theList = new CircularList();
        // initialize the front and rear
        // display the list
        theList.displayList();
        // insert elements in the circular list
        theList.insertFirst(10);
        theList.insertFirst(90);
        theList.insertFirst(20);
        theList.insertFirst(80);
        theList.insertFirst(30);
        theList.insertFirst(70);
        theList.insertFirst(40);
        theList.insertFirst(60);
        theList.insertFirst(50);
        // display the list
        theList.displayList();
        divider();
        int option;
        try {
            do {
                options();
                option = input.nextInt();
                Scanner input2 = new Scanner(System.in);
                int valor;
                switch (option) {
                    case 0:
                        System.out.println("Good Bye");
                        System.exit(0);
                    case 1:
                        divider();
                        System.out.println("Insert the"
                                + " element: ");
                        valor = input2.nextInt();
                        theList.insertFirst(valor);
                        theList.displayList();
                        divider();
                        break;
                    case 2:
                        divider();
                        System.out.println("Delete the"
                                + " element: ");
                        valor = input2.nextInt();
                        theList.deleteNode(valor);
                        theList.displayList();
                        divider();
                        break;
                    case 3:
                        divider();
                        theList.displayList();
                        divider();
                        break;
                    default:
                        divider();
                        divider();
                        System.out.println("That is not"
                                + " a valid option");
                        divider();
                        divider();
                        break;
                }

            } while (option != 0);
        } catch (Exception e) {
            System.out.println("That is not a numeric"
                    + " value");
        }
    }

    public static void options() {
        System.out.println("Choose an option");
        System.out.println("1 to insert in circular list");
        System.out.println("2 to delete an element");
        System.out.println("3 to display the list");
        System.out.println("0 to close the program");
    }
    //console text color
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static void divider() {
        System.out.println(ANSI_GREEN + "////////////"
                + "//////////////////////////////////"
                + "//////////////////////////////////"
                + ANSI_RESET);
    }
}
