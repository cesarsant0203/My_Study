/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

/**
 *
 * @author Cesar J. Santacruz
 */
public class CircularList {

    CNode front = null, rear = null;

    // Insert into circular list 
    public void insertFirst(int dd) {
        CNode newNode = new CNode(dd);
        newNode.next = front;
        if (front == null) {
            newNode.next = newNode;
        } else {
            CNode temp = front;
            while (temp.next != front) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
        front = newNode;

    }
    // ----------------------------------------------

    // delete a specific element
    public void deleteNode(int element) {
        if (front == null) {
            System.out.println("Can not delete"
                    + " circular list is empty");
            return;
        }
        CNode current = front;
        CNode previous = null;
        while (current.dData != element) {
            if (current.next == front) {
                System.out.println("Element not found"
                        + " in the double circular"
                        + " list");
                break;
            }
            previous = current;
            current = current.next;
        }
        if (current == front
                && current.next == front) {
            front = null;
        } else if (current == front) {
            previous = front;
            while (previous.next != front) {
                previous = previous.next;
            }
            front = current.next;
            previous.next = front;
        } else if (current.next == front) {
            previous.next = front;
        } else {
            previous.next = current.next;
        }
    }

    // display list
    public void displayList() {
        CNode current = front;//front of list
        if (front == null) {
            System.out.println("Circular list is"
                    + " empty");
        } else {
            System.out.println("Elements in circular"
                    + " list are: ");
            int count = 0;//count times it is printing
            do {
                current.displayLink();// print dData
                count++;
                if (count % 15 == 0) {//adds new line
                    System.out.print("\n");
                }
                current = current.next;
            } while (current != front);
        }
    }
}
