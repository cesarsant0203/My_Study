/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica67.linked.list;

import java.util.Random;

/**
 *
 * @author Cesar J. Santacruz
 */
public class DoubleLinkList {

    private DLNode first; // ref. to first link on list
    private static int size;
    // ----------------------------------------------

    public DoubleLinkList() // constructor
    {
        first = null; // no items on list yet
    }
    // ----------------------------------------------

    // insert at start of list
    public void insertFirst(int dd) {
        DLNode newNode = new DLNode(dd);//alocate node
        newNode.next = first;//next as first
        newNode.prev = null;//prev as null
        if (first != null) {//prev of first to newNode
            first.prev = newNode;
        }
        first = newNode;//first to point to newNode
    }
    // ----------------------------------------------
    
    // insert at end of list
    public void insertLast(int dd) {
        DLNode newNode = new DLNode(dd);//alocate node
        DLNode last = first;
        newNode.next = null;//as last, next is null
        if (first == null) {//if empty last is first
            newNode.prev = null;
            first = newNode;
            return;
        }
        while (last.next != null) {//make last the last
            last = last.next;
        }
        last.next = newNode;//add the new node 
        newNode.prev = last;
    }
    // ----------------------------------------------
    
    // display the list
    public void displayList() {
        System.out.println("the items in the list are: ");
        DLNode current = first; //start at beginning of list
        int count = 0;//count how many times is printing
        while (current != null) {// until end of list
            current.displayLink(); // print dData
            count++;
            if (count % 15 == 0) {//adds new line every 15
                System.out.print("\n");
            }
            current = current.next; // move to next node
        }
        System.out.println("");
    }
    // ----------------------------------------------
    
    // fill the list with random integers numbers
    public static DoubleLinkList fillList() {
        Random rnd;
        rnd = new Random(System.currentTimeMillis());
        size = (int) (Math.random() * (100 - 1 + 1) + 1);
        DoubleLinkList theList = new DoubleLinkList();
        for (int i = 0; i < size; i++) {
            theList.insertFirst(rnd.nextInt(100));
        }
        return theList;
    }
    // ----------------------------------------------
    
    // delete specific node
    public void deleteSpecific(int node) {
        DLNode current = first;
        DLNode previous = null;
        DLNode after = current.next;
        int i = 1;
        if (node == 1) {//if first
            first = after;//first->after
        } else if (node == size) {//if last
            DLNode last = first;
            while (last.next != null) {
                last = last.next;
            }//move till the last
            last = last.prev;//last->prev
            last.next = null;//next->null
        } else {
            while (i != node) {
                previous = current;
                current = current.next;
                after = current.next;
                i++;
            }
            previous.next = after;
            after.prev = previous;
        }
    }
}
