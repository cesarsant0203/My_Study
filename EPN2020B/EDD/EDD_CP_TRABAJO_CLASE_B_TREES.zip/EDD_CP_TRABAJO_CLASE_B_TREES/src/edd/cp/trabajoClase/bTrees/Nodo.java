/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.trabajoClase.bTrees;

/**
 *
 * @author Mayrita
 */
public class Nodo {
    
    // declaracion de varibles de instancia
    // se declara un arreglo de enteros donde
    // estaran los valores.
    public int []valores;
    // se declara un arreglo de nodos donde
    // estaran los nodos
    public Nodo []nodo;

    public static int numValores;
    public boolean tengoHijos = false;
    public int ocupados = 0;
    public Nodo padre;
    
    //Constructor de la clase que define
    //el tamanio del arreglo de nodos y
    //de valores.
    public Nodo(){
    nodo = new Nodo [Raiz.grado * 2 + 3];
       valores = new int [Raiz.grado * 2 + 1];
    }
}
