/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.trabajoClase.bTrees;

import java.util.*;

/**
 *
 * @author Mayrita
 */
public class Lista {

    // declaracion de varibles de instancia
    // variable estatica de tipo ArrayList de integers.
    public static ArrayList<Integer> ingresados;

    //constructor
    public Lista() {
        //inicializacion de la variable declarada
        ingresados = new ArrayList<>();
    }

    //Metodo de busqueda el cual recibe un valor entero
    //y devuelve un boolean de si se encontro o no ese valor
    //en el arbol
    public boolean buscar(int valor) {
        //se declara una variable del metodo
        //y se inicializa como falsa.
        boolean esta = false;
        //Bucle que recorre la lista desde el indice 0 hasta
        //el indice del ultimo elemento y compara si el valor
        //en cada posicion es igual al valor que se recibio
        //como entrada, si es igual la variable declara se
        //cambia a true, caso contrario se devuelve un false.
        for (int i = 0; i < ingresados.size() && !esta; i++) {
            if (ingresados.get(i) == valor) {
                esta = true;

            }
        }
        return esta;

    }
}
