/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cd.cap1.trab2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class Matrices {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Primera matriz aleatoria
        int matriz1[][] = new int[4][4];
        long startTimeA = System.nanoTime();
        Random rndA = new Random(System.nanoTime());
        System.out.println("Esta es la matriz aleatoria uno");
        for (int i = 0; i < matriz1[0].length; i++) {
            for (int j = 0; j < matriz1[1].length; j++) {
                matriz1[i][j] = (int) (rndA.nextDouble() * 20 + 5);
                System.out.print("\t" + matriz1[i][j]);
            }
            System.out.print("\n");

        }
        long totalTimeA = System.nanoTime() - startTimeA;
        System.out.println("\nTiempo total de la matriz aleatoria: " + totalTimeA * 0.000000001 + " S");
        //Segunda matriz aleatoria
        int matriz4[][] = new int[4][4];
        long startTimeD = System.nanoTime();
        Random rndD = new Random(System.nanoTime());
        System.out.println("Esta es la matriz aleatoria dos");
        for (int i = 0; i < matriz4[0].length; i++) {
            for (int j = 0; j < matriz4[1].length; j++) {
                matriz4[i][j] = (int) (rndD.nextDouble() * 20 + 5);
                System.out.print("\t" + matriz4[i][j]);
            }
            System.out.print("\n");
        }
        long totalTimeD = System.nanoTime() - startTimeD;
        System.out.println("\nTiempo total de la matriz aleatoria: " + totalTimeD * 0.000000001 + " S");        
        //Matriz ingresada por teclado
        int matriz2[][] = new int[4][4];
        long startTimeB = System.nanoTime();
        Scanner input = new Scanner(System.in);

        System.out.print("\nEsta es la matriz ingresada por teclado\n");
        System.out.println("Ingrese " + matriz2[0].length * matriz2[1].length + " valores para la matriz");
        try{
        for (int i = 0; i < matriz2[0].length; i++) {
            for (int j = 0; j < matriz2[1].length; j++) {
                matriz2[i][j] = input.nextInt();
            }
        }
        }catch(Exception e){
            System.err.println("una excepcion " + e.toString());
        }
        long totalTimeB = System.nanoTime() - startTimeB;
        for (int i = 0; i < matriz2[0].length; i++) {
            for (int j = 0; j < matriz2[1].length; j++) {
                System.out.print("\t" + matriz2[i][j]);
            }
            System.out.print("\n");
        }
        System.out.println("\nTiempo total de la matriz por teclado: " + totalTimeB * 0.000000001 + " S");
        int matriz3[][] = new int[4][4];
        for (int i = 0; i < matriz3[0].length; i++) {
            for (int j = 0; j < matriz3[1].length; j++) {
                matriz3[i][j] = 0;
            }
        }
        
        
        System.out.print("\nEsta es la 4ra matriz despues de sumar la aleatoria y la de teclado a ella\n");
        for (int i = 0; i < matriz1[0].length; i++) {
            for (int j = 0; j < matriz1[1].length; j++) {
                matriz3[i][j] += matriz1[i][j] + matriz2[i][j];
                System.out.print("\t" + matriz3[i][j]);
            }
            System.out.print("\n");

        }

    }

}
