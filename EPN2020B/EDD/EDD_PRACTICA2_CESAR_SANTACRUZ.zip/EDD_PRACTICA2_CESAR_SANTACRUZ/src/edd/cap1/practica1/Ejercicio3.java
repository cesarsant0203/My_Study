/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cap1.practica1;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        welcome();
        Scanner input = new Scanner(System.in);
        String proveedores[] = {"Santacruz", "Santamaria", "Jovi", "Levin", "Torres", "Summer"};
        String ciudad[] = {"Quito", "Pujili", "California", "Washington", "Madrid", "Madrid"};
        int numArticulos[] = {27, 02, 23, 64, 12, 34};

        int option = 0;
        try {
            do {
                options();
                option = input.nextInt();
                Scanner input2 = new Scanner(System.in);
                Scanner input3 = new Scanner(System.in);
                String nombre;
                switch (option) {
                    case 0:
                        System.out.println("Muchas gracias por usar este programa");
                        System.exit(0);
                    case 1:
                        divider();
                        System.out.println("\t\tobtener informacion");
                        System.out.println("Ingrese nombre");
                        nombre = input2.nextLine();
                        for (int i = 0; i < proveedores.length; i++) {
                            if (nombre.equals(proveedores[i])) {
                                System.out.println("Ciudad de residencia: " + ciudad[i]
                                        + "\nNumero de articulos: " + numArticulos[i]);
                                break;
                            } else {
                            }
                        }
                        divider();
                        break;
                    case 2:
                        divider();
                        System.out.println("\t\tCambiar domicilio");
                        System.out.println("Ingrese nombre");
                        nombre = input2.nextLine();
                        String nuevaC;
                        System.out.println("Ingrese el nombre de la ciudad a la que"
                                + " se mudo");
                        nuevaC = input2.nextLine();
                        for (int i = 0; i < proveedores.length; i++) {
                            if (nombre.equals(proveedores[i])) {
                                ciudad[i] = nuevaC;
                                System.out.println("Ciudad de residencia: " + ciudad[i]);
                                break;
                            } else {
                            }
                        }
                        divider();
                        break;
                    case 3:
                        divider();
                        System.out.println("\t\tCambiar numero de articulos");
                        System.out.println("Ingrese nombre");
                        nombre = input2.nextLine();
                        int nuevoNum;
                        try {
                            System.out.println("Ingrese el numero de articulos "
                                    + "que aumenta o disminuye (5,-5)");
                            nuevoNum = input3.nextInt();
                            for (int i = 0; i < proveedores.length; i++) {
                                if (nombre.equals(proveedores[i])) {
                                    numArticulos[i] += nuevoNum;
                                    System.out.println("Numero de articulos: " + numArticulos[i]);
                                    break;
                                } else {
                                }
                            }
                        } catch (Exception e) {
                            System.out.println("El numero de articulos solo puede s"
                                    + "er un numero entero");
                        }
                        divider();
                        break;
                    case 4:
                        divider();
                        System.out.println("\t\tCompañía da de baja a un proveedor");
                        System.out.println("Ingrese nombre");
                        nombre = input2.nextLine();
                        for (int i = 0; i < proveedores.length; i++) {
                            if (nombre.equals(proveedores[i])) {
                                ciudad[i] = "";
                                numArticulos[i] = 0;
                                proveedores[i] = null;
                            } else {
                            }
                        }
                        // se transfiere la informacion anterior a un nuevo arreglo
                        String nuevoProveedores2[] = new String[proveedores.length - 1];
                        String nuevaCiudad2[] = new String[proveedores.length - 1];
                        int nuevoNumArticulos2[] = new int[proveedores.length - 1];
                        int deletedIndex = 0;
                        try {
                            for (int i = 0; i < proveedores.length; i++) {
                                if (ciudad[i].equals("")) {
                                    deletedIndex = i;
                                    break;
                                } else {
                                    nuevoProveedores2[i] = proveedores[i];
                                    nuevaCiudad2[i] = ciudad[i];
                                    nuevoNumArticulos2[i] = numArticulos[i];
                                }
                            }
                            for (int j = deletedIndex; j < nuevoProveedores2.length; j++) {
                                nuevoProveedores2[j] = proveedores[j + 1];
                                nuevaCiudad2[j] = ciudad[j + 1];
                                nuevoNumArticulos2[j] = numArticulos[j + 1];
                            }
                            // se recrea el arreglo con un espacio menos
                            proveedores = new String[nuevoProveedores2.length];
                            ciudad = new String[nuevaCiudad2.length];
                            numArticulos = new int[nuevoNumArticulos2.length];
                            for (int i = 0; i < nuevoProveedores2.length; i++) {
                                proveedores[i] = nuevoProveedores2[i];
                                ciudad[i] = nuevaCiudad2[i];
                                numArticulos[i] = nuevoNumArticulos2[i];
                            }
                            System.out.println("Proveedor dado de baja con exito");
                        } catch (Exception e) {
                            System.out.println("No se puede continuar");
                        }
                        System.out.println("Proveedores: " + Arrays.toString(proveedores));
                        System.out.println("Ciudades: " + Arrays.toString(ciudad));
                        System.out.println("Num. articulos: " + Arrays.toString(numArticulos));
                        divider();
                        break;

                    case 5:
                        divider();
                        System.out.println("\t\tIncorporar a un nuevo proveedor");
                        // se introduce el nuevo proveedor
                        System.out.println("Ingrese nombre");
                        nombre = input2.nextLine();
                        System.out.println("Ingrese ciudad");
                        nuevaC = input2.nextLine();
                        System.out.println("Ingrese el numero de articulos");
                        nuevoNum = input3.nextInt();
                        // se transfiere la informacion anterior a un nuevo arreglo
                        String nuevoProveedores[] = new String[proveedores.length + 1];
                        String nuevaCiudad[] = new String[proveedores.length + 1];
                        int nuevoNumArticulos[] = new int[proveedores.length + 1];
                        try {
                            for (int i = 0; i < proveedores.length; i++) {
                                nuevoProveedores[i] = proveedores[i];
                                nuevaCiudad[i] = ciudad[i];
                                nuevoNumArticulos[i] = numArticulos[i];
                            }
                            // se recrea el arreglo con un espacio mas
                            proveedores = new String[nuevoProveedores.length];
                            ciudad = new String[nuevaCiudad.length];
                            numArticulos = new int[nuevoNumArticulos.length];
                            for (int i = 0; i < nuevoProveedores.length; i++) {
                                proveedores[i] = nuevoProveedores[i];
                                ciudad[i] = nuevaCiudad[i];
                                numArticulos[i] = nuevoNumArticulos[i];
                            }
                            proveedores[nuevoProveedores.length - 1] = nombre;
                            ciudad[nuevoProveedores.length - 1] = nuevaC;
                            numArticulos[nuevoProveedores.length - 1] = nuevoNum;
                            System.out.println("Nuevo proveedor ingresado con exito");
                        } catch (Exception e) {
                            System.out.println("No existe ese nombre de proveedor");
                            System.out.println("No se puede continuar");
                        }
                        System.out.println("Proveedores: " + Arrays.toString(proveedores));
                        System.out.println("Ciudades: " + Arrays.toString(ciudad));
                        System.out.println("Num. articulos: " + Arrays.toString(numArticulos));
                        divider();
                        break;
                    default:
                        divider();
                        divider();
                        System.out.println("Esa no es una opcion valida");
                        divider();
                        divider();
                        break;
                }

            } while (option != 0);
        } catch (Exception e) {
            System.out.println("Ese no es un valor numerico valido");
        }
    }

    public static void welcome() {
        System.out.println("///////////////////////////////////////"
                + "/////////////////////////////////////////");
        System.out.println("\t\t\tBIENVENID@");
        System.out.println("///////////////////////////////////////"
                + "/////////////////////////////////////////");
    }

    public static void options() {
        System.out.println("Seleccione el numero de opcion que desea realiz"
                + "ar");
        System.out.println("Por favor ingrese 1 si desea informar el nombre"
                + " de la ciudad de residencia y el\nnúmero de artículos");
        System.out.println("Por favor ingrese 2 si desea actualizar el nomb"
                + "re de la ciudad, si un proveedor\ncambia de domicilio");
        System.out.println("Por favor ingrese 3 si desea actualizar el núme"
                + "ro de artículos");
        System.out.println("Por favor ingrese 4 si la compañía da de baja a"
                + " un proveedor");
        System.out.println("Por favor ingrese 5 si la compañía incorpora a "
                + "un nuevo proveedor");
        System.out.println("Por favor ingrese 0 si desea salir en este mome"
                + "nto del programa");
    }

    public static void divider() {
        System.out.println("///////////////////////////////////////"
                + "/////////////////////////////////////////");
    }
}
