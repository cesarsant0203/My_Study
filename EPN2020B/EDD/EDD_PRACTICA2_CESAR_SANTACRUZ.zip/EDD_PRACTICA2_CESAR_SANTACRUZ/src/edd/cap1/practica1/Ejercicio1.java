/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cap1.practica1;

import java.util.Arrays;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] array1 = {1,2,3,4,5};
        int[] array2 = new int[5];
        int j=0;
        for (int i=array1.length-1; i>=0; i--){
            array2[j]=array1[i];
            j++;
        }
        System.out.println("Este es el arreglo 1");
        System.out.println(Arrays.toString(array1));
        System.out.println("Este es el arreglo 2");
        System.out.println(Arrays.toString(array2));
    }   
}
