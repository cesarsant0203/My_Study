/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cap1.practica1;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double mesT[] = new double[12];
        Scanner input = new Scanner(System.in);
        System.out.println("Igrese los valores correspondientes de cada mes");
        for (int i = 0; i < mesT.length; i++) {
            System.out.printf("%d mes: ", i + 1);
            mesT[i] = input.nextDouble();
        }
        System.out.println("El promedio anual de toneladas cosechadas");
        System.out.println(Double.toString(calcularPromedio(mesT)));
        System.out.println("¿Cuántos meses tuvieron cosecha superior al promedio anual?");
        System.out.println(Double.toString(calcularSPromedio(mesT)));
        System.out.println("¿Cuántos meses tuvieron cosecha inferior al promedio anual?");
        System.out.println(Double.toString(calcularIPromedio(mesT)));
    }

    public static double calcularPromedio(double arreglo[]) {
        double promedio = 0;
        for (int i = 0; i < arreglo.length; i++) {
            promedio += arreglo[i];
        }
        promedio = promedio / arreglo.length;
        return promedio;

    }

    public static double calcularSPromedio(double arreglo[]) {
        int mayorP = 0;
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] > calcularPromedio(arreglo)) {
                mayorP++;
            }
        }
        return mayorP;
    }
    public static double calcularIPromedio(double arreglo[]) {
        int menorP = 0;
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] < calcularPromedio(arreglo)) {
                menorP++;
            }
        }
        return menorP;
    }
}
