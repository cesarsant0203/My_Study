package edd.cd.practica10.stack;

import java.util.Arrays;

class StackApp {

    public static void main(String[] args) {
        Stack theStack = new Stack(10); // make new stack
        double[] array = {10.1, 20.2, 30.3, 40.4, 50.5, 60.6, 70.7, 80.8, 90.9, 100.1};
        System.out.println("Array de elementos reales que ingresaran a la pila:\n"
                +Arrays.toString(array));
        for (int i = 0; i < array.length; i++) {
            theStack.push(array[i]);
            System.out.println("Se ingreso a la pila el valor: "+theStack.peek());
        }// push items onto stack
        while (!theStack.isEmpty()) // until it�s empty,
        { // delete item from stack
            double value = theStack.pop();
            System.out.println("Se elimino de la pila el valor: "+value
                    +"\nPila restante:"); // display it
            theStack.PrintStack(theStack);
            System.out.println("\n");
        } // end while
    } // end main()
    
} // end class StackApp
