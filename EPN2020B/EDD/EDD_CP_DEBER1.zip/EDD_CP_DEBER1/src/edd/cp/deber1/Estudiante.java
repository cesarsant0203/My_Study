/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.deber1;

/**
 *
 * @author cesar
 */
public class Estudiante {
    private final String id;
    private final String nombre;
    private final String apellido;
    private final String direccion;
    private final String telefono;
    
    public Estudiante (String id,String nombre,String apellido,String direccion,String telefono){
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.telefono =  telefono;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "id= " + id + ", nombre= " + nombre + ", apellido= " + apellido + ", direccion= " + direccion + ", telefono= " + telefono + '}';
    }

}
