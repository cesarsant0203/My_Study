/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.deber1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author cesar
 */
public class OperacionesArchivo {

    public void insertarRegistros(ArrayList<Estudiante> estudiante) throws IOException {
        try {
            File estudiantesFile = new File("Estudiantes.txt");
            if (estudiantesFile.createNewFile()) {
                System.out.println("El archivo no existia y se creo: "
                        + estudiantesFile.getName());
            } else {
                System.out.println("El archivo ya existia.");
            }
            try (FileWriter escrituraArchivo = new FileWriter("Estudiantes.txt")) {
                for (Estudiante str : estudiante) {
                    escrituraArchivo.write(str + System.lineSeparator());
                }
            }
            System.out.println("Se escribio todos los estudiantes en el archivo con exito.");
        } catch (IOException e) {
            System.out.println("Ocurrio un error.");
        }
    }

    public void imprimirRegistros(String nombreArchivo) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
        String lineaActual;
        while ((lineaActual = br.readLine()) != null) {
            System.out.println(lineaActual);
        }
    }

    public void modificarRegistro(String idBuscado, String newAdress, String nombreArchivo) throws FileNotFoundException {
        ArrayList<String> arrayArchivo = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String lineaActual;
            while ((lineaActual = br.readLine()) != null) {
                if (lineaActual.contains(idBuscado)) {
                    String lineaCambiada = lineaActual.replaceFirst(", direccion= .*,", ", direccion= " + newAdress + ",");
                    arrayArchivo.add(lineaCambiada);
                } else {
                    arrayArchivo.add(lineaActual);
                }
            }
            try (FileWriter escrituraArchivo = new FileWriter(nombreArchivo)) {
                for (String str : arrayArchivo) {
                    escrituraArchivo.write(str + System.lineSeparator());
                }
            }
            System.out.println("Se modifico correctamente la direccion del estu"
                    + "diante con id: " + idBuscado);
        } catch (IOException e) {
        }
    }

    public void eliminarRegistro(String idBuscado,String nombreArchivo) throws FileNotFoundException {
        ArrayList<String> arrayArchivo = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String lineaActual;
            while ((lineaActual = br.readLine()) != null) {
                if (lineaActual.contains(idBuscado)) {

                } else {
                    arrayArchivo.add(lineaActual);
                }
            }
            try (FileWriter escrituraArchivo = new FileWriter(nombreArchivo)) {
                for (String str : arrayArchivo) {
                    escrituraArchivo.write(str + System.lineSeparator());
                }
            }
            System.out.println("Se elimino correctamente el registro del estudi"
                    + "ante con id: " + idBuscado);
        } catch (IOException e) {
        }
    }
}
