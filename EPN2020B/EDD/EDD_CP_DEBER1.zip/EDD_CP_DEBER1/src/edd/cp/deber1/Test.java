/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.deber1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class Test {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {

        // TODO code application logic here
        separador();
        System.out.println("\t\t\tBIENVENID@");
        separador();
        Scanner input = new Scanner(System.in);
        int opcion;
        ArrayList<Estudiante> estudiantes;
        estudiantes = new ArrayList<>();
        Estudiante estudiante1 = new Estudiante("est001", "Pepito", "Sanchez", "Cotocollao", "0992334595");
        Estudiante estudiante2 = new Estudiante("est002", "Juanito", "Paredes", "Condado", "0997356496");
        Estudiante estudiante3 = new Estudiante("est003", "Andrea", "Paredes", "Condado", "0997236496");
        Estudiante estudiante4 = new Estudiante("est004", "Liz", "Santamaria", "Pujili", "0993424324");
        Estudiante estudiante5 = new Estudiante("est005", "Cesar", "Santacruz", "Condado", "0993681491");
        estudiantes.add(estudiante1);
        estudiantes.add(estudiante2);
        estudiantes.add(estudiante3);
        estudiantes.add(estudiante4);
        estudiantes.add(estudiante5);
        OperacionesArchivo operaciones = new OperacionesArchivo();
        operaciones.insertarRegistros(estudiantes);
        String nombreArchivo = "Estudiantes.txt";
        do {
            listaOpciones();
            opcion = input.nextInt();

            switch (opcion) {
                case 0:
                    System.out.println("Muchas gracias por usar este programa");
                    System.exit(0);
                case 1:
                    separador();
                    System.out.println("\t\t\tOPCION 1");
                    separador();
                    operaciones.imprimirRegistros(nombreArchivo);
                    separador();
                    System.out.println("\t\t\tOPCION 1");
                    separador();
                    break;
                case 2:
                    separador();
                    System.out.println("\t\t\tOPCION 2");
                    separador();
                    String id;
                    Scanner select = new Scanner(System.in);
                    System.out.println("Ingrese el id");
                    id = select.nextLine();
                    String address;
                    System.out.println("Ingrese la nueva direccion");
                    address = select.nextLine();
                    operaciones.modificarRegistro(id, address,nombreArchivo);
                    separador();
                    System.out.println("\t\t\tOPCION 2");
                    separador();
                    break;
                case 3:
                    separador();
                    System.out.println("\t\t\tOPCION 3");
                    separador();
                    String deletedId;
                    Scanner delete = new Scanner(System.in);
                    System.out.println("Ingrese el id");
                    deletedId = delete.nextLine();
                    operaciones.eliminarRegistro(deletedId,nombreArchivo);
                    separador();
                    System.out.println("\t\t\tOPCION 3");
                    separador();
                    break;
                default:
                    separador();
                    System.out.println("\t\tOPCION NO VALIDA");
                    separador();

                    break;
            }

        } while (opcion != 0);

    }

    public static void separador() {
        System.out.println("//////////////////////////////////"
                + "////////////////////////////////////");
    }

    public static void listaOpciones() {
        System.out.println("Seleccione el numero de opcion que desea realiz"
                + "ar");
        System.out.println("Por favor ingrese 1 si desea revisar la lista d"
                + "e estudiantes ingresados");
        System.out.println("Por favor ingrese 2 si desea editar la direccio"
                + "n de un estudiante mediante su id");
        System.out.println("Por favor ingrese 3 si desea eliminar un regist"
                + "ro de los estudiantes mediante su id");

        System.out.println("Por favor ingrese 0 si desea salir en este mome"
                + "nto del programa");
    }
}
