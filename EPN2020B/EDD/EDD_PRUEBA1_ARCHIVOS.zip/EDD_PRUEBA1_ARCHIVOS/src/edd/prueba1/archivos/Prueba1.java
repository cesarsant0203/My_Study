/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.prueba1.archivos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Prueba1 {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el elemento que desea buscar dentro del arreglo");
        int valorBuscado = input.nextInt();
        if (busquedaLineal(arrayCodigo(), valorBuscado) != -1) {
            System.out.println("Producto encontrado");
        } else {
            System.out.println("producto no encontrado");
        }

    }

    public static int busquedaLineal(int[] a, int clave) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] == clave) {
                return i; //posicion del elemento clave
            }
        }
        return -1;
    }
    public static int[] arrayCodigo(){
        ArrayList<String> arrayArchivo = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("codigoProducto.txt"))) {
            String lineaActual;
            while ((lineaActual = br.readLine()) != null) {
                arrayArchivo.add(lineaActual.substring(0,3));

            }
        } catch (IOException e) {
        }
        int[] ret = new int[arrayArchivo.size()];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = Integer.parseInt(arrayArchivo.get(i));
        }
        return ret;
    }
}
