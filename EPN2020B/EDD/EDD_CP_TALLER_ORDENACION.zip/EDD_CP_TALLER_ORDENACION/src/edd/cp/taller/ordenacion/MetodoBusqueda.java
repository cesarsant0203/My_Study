/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.ordenacion;

/**
 *
 * @author Cesar J. Santacruz
 */
public class MetodoBusqueda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] array1 = {5,3,7,24,26,24,67,13,54};

        System.out.println("Vector inicial: " + imprimirLista(array1));
        int valorBuscado = 17;
        System.out.println("Este es el valor buscado: " + valorBuscado);
        if (busquedaLineal(array1,valorBuscado)!= -1){
            System.out.println("Valor encontrado en el indice: " + busquedaLineal(array1,26));
        }else{
            System.out.println("Valor no encontrado");
        }
        
    }

    public static String imprimirLista(int array[]) {
        String arrayP = "";
        for (int i = 0; i < array.length; i++) {
            arrayP = arrayP + " " + array[i];
        }
        return arrayP;
    }

    public static int busquedaLineal(int[] a, int clave) {
        for (int i = 0; i<a.length;i++){
            if (a[i]==clave){
                return i; //posicion del elemento clave
        }
    }
        return -1;
    }

}
