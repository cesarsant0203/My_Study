/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.ordenacion;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class MetodoTaller2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el tamanio del vector");
        int tamanio = input.nextInt();
        int[] array1 = new int[tamanio];
        System.out.println("Ingrese los elementos del vector");
        for (int i = 0; i < array1.length; i++) {
            array1[i] = input.nextInt();
        }
        System.out.println("Vector inicial: " + imprimirLista(array1));
        metodoTaller2(array1);
        System.out.println("Vector ordenado taller 2: " + imprimirLista(array1));
    }

    public static String imprimirLista(int array[]) {
        String arrayP = "";
        for (int i = 0; i < array.length; i++) {
            arrayP = arrayP + " " + array[i];
        }
        return arrayP;
    }

    public static void metodoTaller2(int[] array) {
        int izq = 1;
        int der = array.length - 1;
        int ultimoInter = array.length - 1;
        int i;
        while (izq <= der) {
            int intercambios = 0;
            for (i = der; i >= izq; i--) {
                if (array[i - 1] > array[i]) {
                    intercambios++;
                    intercambiar(array, i - 1, i);
                    ultimoInter = i;
                }
            }
            izq = ultimoInter + 1;
            for (i = izq; i <= der; i++) {
                if (array[i - 1] > array[i]) {
                    intercambios++;
                    intercambiar(array, i - 1, i);
                    ultimoInter = i;
                }
            }
            der = ultimoInter - 1;
            if (intercambios == 0) {
                break;
            }
        }
    }

    public static void intercambiar(int vector[], int i, int j) {
        int aux;
        aux = vector[i];
        vector[i] = vector[j];
        vector[j] = aux;
    }
}
