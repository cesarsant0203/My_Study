/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capX.deber11;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Archivos {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here
		BufferedWriter newBufferW = null;
		FileWriter newFileW = null;
		System.out.println("Por favor ingrese el cateto 1");
		double cat1;
		Scanner input = new Scanner(System.in);
		cat1 = input.nextDouble();
		System.out.println("Por favor ingrese el cateto 2");
		int cat2;
		cat2 = input.nextInt();
		/////////////////////////////////////////////////////////////
		TrianguloRectangulo primerTrianguloRectangulo = new TrianguloRectangulo();		  // declaracion e inicializacion 
		primerTrianguloRectangulo.setCateto1(cat1);
		primerTrianguloRectangulo.setCateto2(cat2);
		primerTrianguloRectangulo.calcularHipotenusa();
		primerTrianguloRectangulo.calcularPerimetro();
		primerTrianguloRectangulo.calcularArea();
		System.out.println(primerTrianguloRectangulo.toString());
		////////////////////////////////////////////////////////////
		try {
			File file = new File("D:/Users/Cesar J. Santacruz/OneDrive/"
					+ "Documentos/NetBeansProjects/DEBER11_"
					+ "CESAR_SANTACRUZ/src/poo/capX/deber11/"
					+ "OutputFiles/archivoTriangulo.txt");
		// Creacion del archivo en caso de que el mismo no existiera
			if (!file.exists()) {
				file.createNewFile();
			}
			newFileW = new FileWriter(file.getAbsoluteFile(), true);
			newBufferW = new BufferedWriter(newFileW);
			newBufferW.write(primerTrianguloRectangulo.toString() + "\n");
			System.out.println("información sobre el triangulo fue agregada!");
		} catch (IOException e) {
		} finally {
			try {
				if (newBufferW != null) {
					newBufferW.close();
				}
				if (newFileW != null) {
					newFileW.close();
				}
			} catch (IOException ex) {
			}
		}

	}

}





