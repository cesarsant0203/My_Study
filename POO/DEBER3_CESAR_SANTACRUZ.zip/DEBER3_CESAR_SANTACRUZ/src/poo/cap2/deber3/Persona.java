/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap2.deber3;

/**
 *
 * @author cesar
 */
public class Persona {

    private String nombre;
    private String apellido;
    private String ci;
    private String provincia;
    private String nombreInvertido = "";

    public Persona(String nombre, String apellido, String ci) {
        this.nombre = nombre.toLowerCase();
        this.apellido = apellido.toLowerCase();

    }

    /*   public boolean cedulaValida(){
        if (this.ci.length() == 10) {
            switch (this.ci.charAt(0)) {
                case '1':
                    if(
                            this.ci.charAt(1) == '1' || this.ci.charAt(1) == '2'|| this.ci.charAt(1) == '3'||
                            this.ci.charAt(1) == '4'|| this.ci.charAt(1) == '5'|| this.ci.charAt(1) == '6'||
                            this.ci.charAt(1) == '7'|| this.ci.charAt(1) == '8'|| this.ci.charAt(1) == '9'||
                            this.ci.charAt(1) == '0'){
                        return true;
                    }   break;
                case '2':
                    if (
                            this.ci.charAt(1) == '1' || this.ci.charAt(1) == '2'|| this.ci.charAt(1) == '3'||
                            this.ci.charAt(1) == '4'|| this.ci.charAt(1) == '0'){
                        return true;
                    }           break;
                case '0':
                    if (
                            this.ci.charAt(1) == '1' || this.ci.charAt(1) == '2'|| this.ci.charAt(2) == '3'||
                            this.ci.charAt(1) == '4'|| this.ci.charAt(1) == '5'|| this.ci.charAt(2) == '6'||
                            this.ci.charAt(1) == '7'|| this.ci.charAt(1) == '8'|| this.ci.charAt(2) == '9') {
                        return true;
                    }           break;

            }
        }else if (this.ci.length() < 10 || this.ci.length() > 10){
            return false;
        }
    }
     */
    public void cedulaValida(String cedula) {
        if (cedula.length() != 10) {
            this.ci = "0000000000";
        } else {
            //this.ci = cedula;
            int numeroCi = Integer.parseInt(cedula);
            int verificador = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int noveno = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int octavo = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int septimo = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int sexto = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int quinto = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int cuarto = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int tercero = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int segundo = numeroCi % 10;
            numeroCi = numeroCi / 10;
            int primero = numeroCi % 10;

            if (noveno * 2 > 9) {
                noveno = (noveno * 2) - 9;
            } else {
                noveno = (noveno * 2);
            }
            if (septimo * 2 > 9) {
                septimo = (septimo * 2) - 9;
            } else {
                septimo = (septimo * 2);
            }
            if (quinto * 2 > 9) {
                quinto = (quinto * 2) - 9;
            } else {
                quinto = (quinto * 2);
            }
            if (tercero * 2 > 9) {
                tercero = (tercero * 2) - 9;
            } else {
                tercero = (tercero * 2);
            }
            if (primero * 2 > 9) {
                primero = (primero * 2) - 9;
            } else {
                primero = (primero * 2);
            }

            int sumImpar = primero + tercero + quinto + septimo + noveno;
            int sumPar = segundo + cuarto + sexto + octavo;
            int sumTotal = sumImpar + sumPar;
            int decenaSup = sumTotal - (sumTotal % 10) + 10;
            int restaSup = decenaSup - sumTotal;
            if (restaSup == verificador) {
                this.ci = cedula;
            } else {
                this.ci = "0000000000";
            }
        }
    }

    public String palindromo() {
        for (int x = this.nombre.length() - 1; x >= 0; x--) {
            nombreInvertido += this.nombre.charAt(x);
        }
        if (this.nombre.equals(this.nombreInvertido)) {
            return "El nombre " + this.nombre + " si es un palindromo";
        } else {
            return "El nombre " + this.nombre + " no es un palindromo";
        }
    }

    public void provinciaNatal() {
        switch (this.ci.charAt(0)) {
            case '0':
                switch (this.ci.charAt(1)) {
                    case '1':
                        this.provincia = "Azuay";
                        break;
                    case '2':
                        this.provincia = "Bolivar";
                        break;
                    case '3':
                        this.provincia = "Cañar";
                        break;
                    case '5':
                        this.provincia = "Cotopaxi";
                        break;
                    case '6':
                        this.provincia = "Chimborazo";
                        break;
                    case '7':
                        this.provincia = "El Oro";
                        break;
                    case '8':
                        this.provincia = "Esmeraldas";
                        break;
                    case '4':
                        this.provincia = "Carchi";
                        break;
                    case '9':
                        this.provincia = "Guayas";
                        break;
                    case '0':
                        this.provincia = "Pendiente";
                        break;
                }
                break;
            case '1':
                switch (this.ci.charAt(1)) {
                    case '0':
                        this.provincia = "Imbabura";
                    case '1':
                        this.provincia = "Loja";
                        break;
                    case '2':
                        this.provincia = "Los Rios";
                        break;
                    case '3':
                        this.provincia = "Manabi";
                        break;
                    case '4':
                        this.provincia = "Morona Santiago";
                        break;
                    case '5':
                        this.provincia = "Napo";
                        break;
                    case '6':
                        this.provincia = "Pastaza";
                        break;
                    case '7':
                        this.provincia = "Pichincha";
                        break;
                    case '8':
                        this.provincia = "Tungurahua";
                        break;

                    case '9':
                        this.provincia = "Zamora Chinchipe";
                        break;
                }
                break;
            case '2':
                switch (this.ci.charAt(1)) {
                    case '0':
                        this.provincia = "Galapagos";
                    case '1':
                        this.provincia = "Sucumbios";
                        break;
                    case '2':
                        this.provincia = "Orellana";
                        break;
                    case '3':
                        this.provincia = "Santo Domingo de los Tsachilas";
                        break;
                    case '4':
                        this.provincia = "Santa Elena";
                        break;
                }
                break;
        }
    }

    @Override
    public String toString() {
        return "\n======================================================================\n"
                + "\tInformacion Persona:\n"
                + "\tnombre=" + this.nombre
                + ",\n\tapellido=" + this.apellido
                + ",\n\tci=" + this.ci
                + ",\n\tprovincia=" + this.provincia
                + "\n======================================================================\n";
    }
}
/*switch (cedula.charAt(0)) {
                case '0':
                    switch (ci.charAt(1)) {
                        case '1':
                            this.ci = cedula;
                            ;
                            break;
                        case '2':
                            this.ci = cedula;
                            ;
                            break;
                        case '3':
                            this.ci = cedula;
                            ;
                            break;
                        case '5':
                            this.ci = cedula;
                            ;
                            break;
                        case '6':
                            this.ci = cedula;
                            ;
                            break;
                        case '7':
                            this.ci = cedula;
                            break;
                        case '8':
                            this.ci = cedula;
                            break;
                        case '4':
                            this.ci = cedula;
                            break;
                        case '9':
                            this.ci = cedula;
                            break;
                    }
                    break;
                case '1':
                    switch (cedula.charAt(1)) {
                        case '0':
                            this.ci = cedula;
                        case '1':
                            this.ci = cedula;
                            break;
                        case '2':
                            this.ci = cedula;
                            break;
                        case '3':
                            this.ci = cedula;
                            break;
                        case '4':
                            this.ci = cedula;
                            break;
                        case '5':
                            this.ci = cedula;
                            break;
                        case '6':
                            this.ci = cedula;
                            break;
                        case '7':
                            this.ci = cedula;
                            break;
                        case '8':
                            this.ci = cedula;
                            break;

                        case '9':
                            this.ci = cedula;
                            break;
                    }
                    break;
                case '2':
                    switch (cedula.charAt(1)) {
                        case '0':
                            this.ci = cedula;
                        case '1':
                            this.ci = cedula;
                            break;
                        case '2':
                            this.ci = cedula;
                            break;
                        case '3':
                            this.ci = cedula;
                            break;
                        case '4':
                            this.ci = cedula;
                            break;
                    }
                    break;
                default:
                    this.ci = "0000000000";
                    break;*/
