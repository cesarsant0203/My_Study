/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap2.deber3;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestRegistroCivil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("////////////////////////////  BIENVENID@  /////////"
                + "///////////////////");
        Scanner input = new Scanner(System.in);
        int opcion;
        ArrayList<Persona> personas = new ArrayList<>();

        do {
            System.out.println("Seleccione el numero de opcion que desea realiz"
                    + "ar");
            System.out.println("Por favor ingrese 1 si desea ingresar una nuev"
                    + "a persona");
            System.out.println("Por favor ingrese 2 si desea revisar la lista d"
                    + "e personas ingresadas");
            System.out.println("Por favor ingrese 0 si desea salir en este mome"
                    + "nto del programa");
            opcion = input.nextInt();

            switch (opcion) {
                case 0:
                    System.out.println("Muchas gracias por usar este programa");
                    System.exit(0);
                case 1:
                    System.out.println("///////////////////////////////////////"
                            + "///////////////////////////////");
                    System.out.println("/////////////////////// ingresar u"
                            + "na persona//////////////////////////");
                    String nombre;
                    Scanner select = new Scanner(System.in);
                    System.out.println("Ingrese el nombre");
                    nombre = select.nextLine();
                    String apellido;
                    System.out.println("Ingrese el apellido");
                    apellido = select.nextLine();
                    String ci;
                    System.out.println("Ingrese la cedula de identidad");
                    ci = select.nextLine();
                    Persona PersonaUno = new Persona(nombre, apellido, ci);
                    PersonaUno.cedulaValida(ci);
                    System.out.println(PersonaUno.palindromo());
                    PersonaUno.provinciaNatal();
                    System.out.println(PersonaUno.toString());;
                    personas.add(PersonaUno);
                    System.out.println("////////////////////////// Opcion "
                            + "1 //////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    break;
                case 2:
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("///////////// Mostrar todas las"
                            + " personas ingresadas //////////////////");
                    for (int i = 0; i < personas.size(); i++) {
                        System.out.println(personas.get(i));
                    }
                    System.out.println("////////////////////////// Opcion "
                            + "2 //////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    break;

                default:
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("Esa no es una opcion valida");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    break;
            }

        } while (opcion != 0);
    }

}
