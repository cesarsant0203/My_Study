/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.prueba1;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class EcuacionSegundoGradoTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("/////BIENVENID@/////");
        Scanner input = new Scanner(System.in);
        System.out.println("Una ecuacion cuadratica es Ax2+Bx+C=0, en donde a≠0");
        System.out.println("Escriba el coeficiente A");
        int a = input.nextInt();
        while (a == 0) {
            System.out.println("Escriba el coeficiente A");
            a = input.nextInt();
        }
        System.out.println("Escriba el coeficiente B");
        int b = input.nextInt();
        System.out.println("Escriba el coeficiente C");
        int c = input.nextInt();
        EcuacionSegundoGrado ecuacion1 = new EcuacionSegundoGrado(a,b,c);
        System.out.println(ecuacion1.toString());
        System.out.println("El tipo de solucion es " );
        ecuacion1.analizarTipoDeSolucion();
        System.out.println(ecuacion1.tipoSolucion);
        System.out.println(ecuacion1.solucionCuadratica());
    }

}
