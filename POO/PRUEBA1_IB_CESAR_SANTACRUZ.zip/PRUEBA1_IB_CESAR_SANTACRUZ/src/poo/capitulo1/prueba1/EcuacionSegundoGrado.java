/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.prueba1;

/**
 *
 * @author cesar
 */
public class EcuacionSegundoGrado {

    int coeficienteA;
    int coeficienteB;
    int coeficienteC;
    String tipoSolucion;

    public EcuacionSegundoGrado(int coeficienteA, int coeficienteB, int coeficienteC) {
        this.coeficienteA = coeficienteA;
        this.coeficienteB = coeficienteB;
        this.coeficienteC = coeficienteC;
    }

    public void analizarTipoDeSolucion() {
        int discriminante = (this.coeficienteB * this.coeficienteB) - 4 * this.coeficienteA * this.coeficienteC;
        if (discriminante > 0) {
            this.tipoSolucion = "Dos raíces reales y diferentes";
        } else if (discriminante == 0) {
            this.tipoSolucion = "Dos raíces reales e iguales";
        } else if (discriminante < 0) {
            this.tipoSolucion = "Dos raíces complejas y diferentes";
        }

    }

    public String solucionCuadratica() {
        int discriminante = (this.coeficienteB * this.coeficienteB) - 4 * this.coeficienteA * this.coeficienteC;
        double solucion1 = ((Math.sqrt(discriminante)) - this.coeficienteB) / (2 * this.coeficienteA);
        double solucion2 = (-(Math.sqrt(discriminante)) - this.coeficienteB) / (2 * this.coeficienteA);
        if (discriminante > 0) {
            return "La primera solucion  es=\n" + solucion1 + "\n" + "La segunda solucion es=\n" + solucion2   + "\n";
        } else if (discriminante == 0) {
            return "La unica solucion doble que es la siguiente: =\n" + solucion1  + "\n";
        } else {
            return "Esta ecuacion no tiene resultados reales";
        }

    }

    @Override
    public String toString() {
        return coeficienteA + "X2 + " + coeficienteB + "X + " + coeficienteC + " = 0";
    }
}
