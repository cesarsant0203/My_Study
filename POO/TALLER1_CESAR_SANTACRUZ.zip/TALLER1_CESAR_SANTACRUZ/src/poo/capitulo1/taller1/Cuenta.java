/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.taller1;

/**
 *
 * @author cesar
 */
public class Cuenta {

    private double balance;



    //constructores///////////////////////////////////////
    public Cuenta(double saldoInicial) {
        if (saldoInicial >= 0.0){
            this.balance = saldoInicial;
        }else{
            this.balance = 0.0;
        }
    }
    //metodos de instancia/////////////////////////////////////////////
    public void abonar(double monto) {
        this.balance += monto;
    }
    
    public double obtenerSaldo(){
        return this.balance ;
    }


}
