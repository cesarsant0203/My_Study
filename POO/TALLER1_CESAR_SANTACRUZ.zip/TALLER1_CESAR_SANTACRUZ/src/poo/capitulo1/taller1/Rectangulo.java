/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.taller1;

/**
 *
 * @author cesar
 */
public class Rectangulo {

    private double longitud;
    private double anchura;

    //constructores///////////////////////////////////////
    public Rectangulo() {
        this.longitud = Math.random() * 1000000000 + 1;
        this.anchura = Math.random() * 1000000000 + 1;
    }

    public Rectangulo(double longitud, double anchura) {
            this.longitud = longitud;
            this.anchura = anchura;

    }

    //metodos de instancia/////////////////////////////////////////////
    public void modificacion(double nuevaLongitud, double nuevaAnchura) {
        this.longitud = nuevaLongitud;
        this.anchura = nuevaAnchura;
    }

    public String acceso() {
            return "la longitud es: " + this.longitud + " y la anchura es: " + this.anchura;
    }

    public boolean cuadrado() {
        return longitud == anchura;
    }
    //metodos de instancia/////////////////////////////////////////////

}
