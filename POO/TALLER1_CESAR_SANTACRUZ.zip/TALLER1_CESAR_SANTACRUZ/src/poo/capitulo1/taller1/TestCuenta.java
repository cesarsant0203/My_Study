/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.taller1;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestCuenta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("/////BIENVENID@/////");
        Scanner input = new Scanner(System.in);
        System.out.println("Escriba el saldo inicial de su cuenta");
        int saldoInicial = input.nextInt();
        Cuenta cuentaUno = new Cuenta(saldoInicial);
        int opcion = 0;
        do {
            System.out.println("Seleccione el numero de opcion que desea realiz"
                    + "ar");
            System.out.println("Por favor ingrese 1 si desea ver el saldo en su"
                    + " cuenta");
            System.out.println("Por favor ingrese 2 si desea abonar a su cuenta"
                    + "");
            System.out.println("Por favor ingrese 0 si desea salir en este mome"
                    + "nto del programa");
            opcion = input.nextInt();
            switch (opcion) {
                case 0:
                    System.out.println("Muchas gracias por usar este programa");
                    System.exit(0);
                case 1:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("/////////////////////////////// ver el "
                            + "estado de cuenta/////////////////////////");
                    System.out.println(cuentaUno.obtenerSaldo());
                    System.out.println("/////////////////////////////// Opcion "
                            + "1 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
                case 2:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("/////////////////////////////// abonar "
                            + "a la cuenta //////////////////////////////");
                    System.out.println("Por favor ingrese el monto a abonar");
                    int monto = input.nextInt();
                    while (monto < 0) {
                        System.out.println("Por favor ingrese el monto a abonar");
                        monto = input.nextInt();
                    }
                    cuentaUno.abonar(monto);
                    System.out.println(cuentaUno.obtenerSaldo());

                    System.out.println("/////////////////////////////// Opcion "
                            + "2 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;

                default:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("Esa no es una opcion valida");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
            }

        } while (opcion != 0);
    }

}
