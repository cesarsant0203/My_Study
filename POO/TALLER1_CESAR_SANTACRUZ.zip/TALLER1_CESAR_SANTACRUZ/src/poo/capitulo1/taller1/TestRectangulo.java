/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.taller1;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestRectangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("/////BIENVENID@/////");
        Scanner input = new Scanner(System.in);
        int opcion = 0;
        do {
            System.out.println("Seleccione el numero de opcion que desea realiz"
                    + "ar");
            System.out.println("Por favor ingrese 1 si desea generar aleatori"
                    + "amente un rectangulo");
            System.out.println("Por favor ingrese 2 si desea crear un rectangulo");
            System.out.println("Por favor ingrese 3 si desea editar el rectang"
                    + "ulo creado");
            System.out.println("Por favor ingrese 0 si desea salir en este mome"
                    + "nto del programa");
            opcion = input.nextInt();

            switch (opcion) {
                case 0:
                    System.out.println("Muchas gracias por usar este programa");
                    System.exit(0);
                case 1:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("//////////////////////////// crear u"
                            + "n rectangulo aleatorio//////////////////////");
                    Rectangulo rectanguloUno = new Rectangulo();
                    System.out.println(rectanguloUno.acceso());
                    if (rectanguloUno.cuadrado() == true) {
                        System.out.println("Este rectangulo si es cuadrado");
                    } else {
                        System.out.println("Este rectangulo no es cuadrado");
                    }
                    System.out.println("/////////////////////////////// Opcion "
                            + "1 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
                case 2:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////// crear el rectangu"
                            + "lo //////////////////////////////////////");
                    System.out.println("Por favor ingrese la longitud");
                    int longitud = input.nextInt();
                    while (longitud < 0) {
                        System.out.println("Por favor ingrese la  longitud");
                        longitud = input.nextInt();
                    }
                    System.out.println("Por favor ingrese la anchura");
                    int anchura = input.nextInt();
                    while (anchura < 0) {
                        System.out.println("Por favor ingrese la anchura");
                        anchura = input.nextInt();
                    }
                    Rectangulo rectanguloDos = new Rectangulo(longitud, anchura);
                    rectanguloDos.modificacion(longitud, anchura);
                    System.out.println(rectanguloDos.acceso());
                    if (rectanguloDos.cuadrado() == true) {
                        System.out.println("Este rectangulo si es cuadrado");
                    } else {
                        System.out.println("Este rectangulo no es cuadrado");
                    }
                    System.out.println("/////////////////////////////// Opcion "
                            + "2 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
                case 3:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("////////////////// cambiar la longi"
                            + "tud y anchura del rectangulo ////////////////");
                    System.out.println("Por favor ingrese la nueva longitud");
                    int newLongitud = input.nextInt();
                    while (newLongitud < 0) {
                        System.out.println("Por favor ingrese la nueva longitud");
                        newLongitud = input.nextInt();
                    }
                    System.out.println("Por favor ingrese la nueva longitud");
                    int newAnchura = input.nextInt();
                    while (newAnchura < 0) {
                        System.out.println("Por favor ingrese la nueva anchura");
                        newAnchura = input.nextInt();
                    }
                    rectanguloDos = new Rectangulo(newLongitud, newAnchura);
                    rectanguloDos.modificacion(newLongitud, newAnchura);
                    System.out.println(rectanguloDos.acceso());
                    if (rectanguloDos.cuadrado() == true) {
                        System.out.println("Este rectangulo si es cuadrado");
                    } else {
                        System.out.println("Este rectangulo no es cuadrado");
                    }
                    System.out.println("/////////////////////////////// Opcion "
                            + "3 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;                 
                default:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("Esa no es una opcion valida");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
            }

        } while (opcion != 0);
    }

}
