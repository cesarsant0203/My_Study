package poo.cap2.taller5;

import java.util.ArrayList;
import java.util.Comparator;

/*
 * @author Cesar J Santacruz
 */
public class Libro implements Comparable<Libro> {

	private String titulo;
	private String edicion;
	private String tipoISBN;
	private String ISBN;
	private int numeroPaginas;
	private Fecha fechaPublicacion;
	ArrayList<Capitulo> capitulos = new ArrayList<>();

	public void agregarCapitulo(Capitulo nuevoCapitulo) {
		this.capitulos.add(nuevoCapitulo);
	}

	public void setFechaPublicacion(Fecha fechaPublicacion) {
		this.fechaPublicacion = fechaPublicacion;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public void setEdicion(String edicion) {
		this.edicion = edicion;
	}

	public void setTipoISBN(String tipoISBN) {
		this.tipoISBN = tipoISBN;
	}

	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}

	public void setNumeroPaginas(int numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}

	public int getNumeroPaginas() {
		return numeroPaginas;
	}

	@Override
	public int compareTo(Libro o) {
		return Comparators.TITULO.compare(this, o);
	}

	public static class Comparators {

		public static Comparator<Libro> TITULO = (Libro o1, Libro o2) -> o1.titulo.compareTo(o2.titulo);
	}

	@Override
	public String toString() {
		return "Titulo: " + titulo + "\nEdicion: " + edicion + "\nTipo de ISBN: "
			+ tipoISBN + "\nISBN: " + ISBN + "\nNumero de paginas: " + numeroPaginas
			+ "\nFecha: " + fechaPublicacion + "\nCapitulos" + capitulos.toString() + "\n";
	}

}






