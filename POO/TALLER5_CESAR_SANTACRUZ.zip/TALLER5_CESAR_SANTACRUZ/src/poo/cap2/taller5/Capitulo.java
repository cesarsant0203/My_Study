package poo.cap2.taller5;

/*
 * @author Cesar J Santacruz
 */
public class Capitulo {
    private String titulo;
    private int pagInicio;
    private int pagFinal;

    public Capitulo(String titulo, int pagInicio, int pagFinal) {
        this.titulo = titulo;
        this.pagInicio = pagInicio;
        this.pagFinal = pagFinal;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setPagInicio(int pagInicio) {
        this.pagInicio = pagInicio;
    }

    public void setPagFinal(int pagFinal) {
        this.pagFinal = pagFinal;
    }
    
    @Override
    public String toString() {
        return "\nTitulo: " + titulo + "\nPagina inicial: " + pagInicio + 
                "\nPagina final: " + pagFinal;
    }
}



