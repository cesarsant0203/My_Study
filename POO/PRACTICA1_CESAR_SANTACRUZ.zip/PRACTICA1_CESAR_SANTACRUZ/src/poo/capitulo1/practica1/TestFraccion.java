/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.practica1;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestFraccion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("/////BIENVENID@/////");
        Scanner input = new Scanner(System.in);
        int opcion = 0;
        do {
            System.out.println("Seleccione el numero de opcion que desea realiz"
                    + "ar");
            System.out.println("Por favor ingrese 1 si desea simplificar la fra"
                    + "ccion por defecto (9/12)");
            System.out.println("Por favor ingrese 2 si desea simplificar una fr"
                    + "accion donde el denominador sea (5)");
            System.out.println("Por favor ingrese 3 si desea ingresar una fracc"
                    + "ion y que esta sea simplificada");
            System.out.println("Por favor ingrese 0 si desea salir en este mome"
                    + "nto del programa");
            opcion = input.nextInt();
            switch (opcion) {
                case 0:
                    System.out.println("Muchas gracias por usar este simplifica"
                            + "dor de fracciones");
                    System.exit(0);
                case 1:
                    Fraccion fraccionUno = new Fraccion();
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("/////////////////////////////// Opcion "
                            + "1 ///////////////////////////////////////");
                    fraccionUno.simplificar();
                    System.out.println(fraccionUno.toString());
                    System.out.println("/////////////////////////////// Opcion "
                            + "1 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
                case 2:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("/////////////////////////////// Opcion "
                            + "2 ///////////////////////////////////////");
                    System.out.println("Por favor ingrese el numerador");
                    int numeradorDos;
                    numeradorDos = input.nextInt();
                    Fraccion fraccionDos = new Fraccion(numeradorDos);
                    fraccionDos.simplificar();
                    System.out.println(fraccionDos.toString());
                    System.out.println("/////////////////////////////// Opcion "
                            + "2 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
                case 3:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("/////////////////////////////// Opcion "
                            + "3 ///////////////////////////////////////");
                    System.out.println("Por favor ingrese el numerador");
                    int numeradorTres = input.nextInt();
                    System.out.println("Por favor ingrese el denominador");
                    int denominadorTres = input.nextInt();
                    while (denominadorTres == 0) {
                        System.out.println("Por favor ingrese el denominador");
                        denominadorTres = input.nextInt();
                    }
                    Fraccion fraccionTres = new Fraccion(numeradorTres,
                            denominadorTres);
                    fraccionTres.simplificar();
                    System.out.println(fraccionTres.toString());

                    System.out.println("/////////////////////////////// Opcion "
                            + "3 ///////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;

                default:
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("Esa no es una opcion valida, mil discul"
                            + "pas, talvez algun dia llegue a esa opcion");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    System.out.println("///////////////////////////////////////"
                            + "/////////////////////////////////////////");
                    break;
            }

        } while (opcion != 0);
    }

}
