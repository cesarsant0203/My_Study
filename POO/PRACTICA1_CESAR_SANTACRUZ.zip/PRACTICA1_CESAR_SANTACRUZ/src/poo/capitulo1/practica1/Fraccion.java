/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.capitulo1.practica1;

/**
 *
 * @author cesar
 */
public class Fraccion {

    private int numerador = 1;
    private int denominador = 1;
    private int num;
    private int den;
    private int mcd;
    //constructores///////////////////////////////////////
    public Fraccion(){
        this.numerador = 9;
        this.denominador = 12;
    }
    public Fraccion(int numerador){
        this.numerador = numerador;
        this.denominador = 5;
    }
    public Fraccion(int numerador, int denominador){
        this.numerador = numerador;
        this.denominador = denominador;
    }
    //metodos de instancia/////////////////////////////////////////////
    private int maximoComunDivisor(){
     num = Math.abs(numerador);                                                                                       
     den = Math.abs(denominador);
     if(den == 0){
          return num;
     }
     int res;
     while(den != 0){
          res = num % den;
          num = den;
          den = res;
     }
     return num;
}
    public void simplificar(){
        mcd = maximoComunDivisor();
        numerador = numerador/mcd;
        denominador = denominador/mcd;
    }
    @Override
    public String toString() {
        return "Fraccion: "  + numerador + "/" + denominador ;
    }
    
}
