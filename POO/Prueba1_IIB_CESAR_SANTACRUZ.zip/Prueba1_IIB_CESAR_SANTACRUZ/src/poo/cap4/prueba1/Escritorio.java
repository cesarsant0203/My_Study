/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.prueba1;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Escritorio extends Computador{
	private String tipoVentilacion;

	public String getTipoVentilacion() {
		return tipoVentilacion;
	}

	public void setTipoVentilacion(String tipoVentilacion) {
		this.tipoVentilacion = tipoVentilacion;
	}

	public String getProcesador() {
		return procesador;
	}

	public void setProcesador(String procesador) {
		this.procesador = procesador;
	}
	
	public boolean esNecesarioVLiquida(){
		if (this.procesador.equals("i7") && this.tipoVentilacion.equals("ventilador")){
			return true;
		} else {
			return false;
		}
	}
	@Override
	public double precioVenta() {
		if (this.procesador.equals("i7") && this.tipoVentilacion.equals("ventilador")){
			return 4000;
		} else if (this.procesador.equals("i7") && this.tipoVentilacion.equals("liquida")){
			return 5000;
		} else if (this.procesador.equals("i5") && this.tipoVentilacion.equals("ventilador")){
			return 2000;
		} else if (this.procesador.equals("i5") && this.tipoVentilacion.equals("liquida")){
			return 3000;
		} else if (this.procesador.equals("i3") && this.tipoVentilacion.equals("ventilador")){
			return 800;
		} else if (this.procesador.equals("i3") && this.tipoVentilacion.equals("liquida")){
			return 1000;
		} else {
			return 0;
		}
	}

	@Override
	public String toString() {
		return "==================================================\n"
			+"Escritorio\n" + "tipoVentilacion=" + tipoVentilacion 
			+ "\nProcesador="+ this.procesador;
	}
	
}












