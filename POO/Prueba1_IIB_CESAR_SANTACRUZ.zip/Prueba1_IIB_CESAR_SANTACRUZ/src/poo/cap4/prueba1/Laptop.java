/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap4.prueba1;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Laptop extends Computador{
	private boolean bateriaExtraible;
	private int tipoPantalla;
	public boolean isBateriaExtraible() {
		return bateriaExtraible;
	}

	public void setBateriaExtraible(boolean bateriaExtraible) {
		this.bateriaExtraible = bateriaExtraible;
	}

	public String getProcesador() {
		return procesador;
	}

	public void setProcesador(String procesador) {
		this.procesador = procesador;
	}

	public int getTipoPantalla() {
		return tipoPantalla;
	}

	public void setTipoPantalla(int tipoPantalla) {
		this.tipoPantalla = tipoPantalla;
	}

	public double duracionBateria(){
		switch (this.tipoPantalla) {
			case 1:
				return 16;
			case 2:
				return 14;
			case 3:
				return 12;
			case 4:
				return 10;
			default:
				return 0;
		}
	}
	@Override
	public double precioVenta() {
		if (this.procesador.equals("i7") && this.bateriaExtraible == false){
			return 4000;
		} else if (this.procesador.equals("i7") && this.bateriaExtraible == true){
			return 5000;
		} else if (this.procesador.equals("i5") && this.bateriaExtraible == false){
			return 2000;
		} else if (this.procesador.equals("i5") && this.bateriaExtraible == true){
			return 3000;
		} else if (this.procesador.equals("i3") && this.bateriaExtraible == false){
			return 800;
		} else if (this.procesador.equals("i3") && this.bateriaExtraible == true){
			return 1000;
		} else {
			return 0;
		}
	}

	@Override
	public String toString() {
		return "==================================================\n"
			+"Laptop\n" + "bateria Extraible=" + bateriaExtraible 
			+ "\nProcesador=" + this.procesador;
	}
}
