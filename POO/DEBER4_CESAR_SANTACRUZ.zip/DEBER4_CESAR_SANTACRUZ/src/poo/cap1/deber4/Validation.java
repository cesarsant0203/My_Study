/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap1.deber4;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Validation {

    public static boolean esNombreValido(String nombreParaValidar) {
        return nombreParaValidar.matches("[A-Z][a-z]+");
    }

    public static boolean esCorreoValido(String correoParaValidar) {
        return correoParaValidar.matches("[a-z]+[.][a-z]+[0-9]*@epn.edu.ec");
    }

    public static boolean esNombreUsuarioValido(String nombreUsuarioParaValidar) {
        return nombreUsuarioParaValidar.matches("[a-z0-9_-]{4,15}");
    }
}
