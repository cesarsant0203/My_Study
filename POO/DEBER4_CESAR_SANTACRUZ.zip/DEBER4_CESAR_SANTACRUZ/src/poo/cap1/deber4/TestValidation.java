/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap1.deber4;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Cesar J. Santacruz
 */
public class TestValidation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("////////////////////////////  BIENVENID@  /////////"
                + "///////////////////");
        Scanner input = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Seleccione el numero de opcion que desea realiz"
                    + "ar");
            System.out.println("Por favor ingrese 1 si desea verificar si el co"
                    + "rreo electronico institucional es valido");
            System.out.println("Por favor ingrese 2 si desea verificar si el no"
                    + "mbre de usuario es valido");           
            System.out.println("Por favor ingrese 0 si desea salir en este mome"
                    + "nto del programa");
            opcion = input.nextInt();

            switch (opcion) {
                case 0:
                    System.out.println("Muchas gracias por usar este programa");
                    System.exit(0);
                case 1:
                    System.out.println("///////////////////////////////////////"
                            + "///////////////////////////////");
                    System.out.println("/////////////////////// ingresar u"
                            + "na persona//////////////////////////");
                    String correo;
                    Scanner select = new Scanner(System.in);
                    System.out.println("Ingrese el correo institucional");
                    correo = select.nextLine();
                    System.out.println(Validation.esCorreoValido(correo));
                    System.out.println("////////////////////////// Opcion "
                            + "1 //////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    break;
                case 2:
                    System.out.println("///////////////////////////////////////"
                            + "///////////////////////////////");
                    System.out.println("/////////////////////// ingresar u"
                            + "na persona//////////////////////////");
                    String nombreUsuario;
                    Scanner select2 = new Scanner(System.in);
                    System.out.println("Ingrese el nombre de usuario");
                    nombreUsuario = select2.nextLine();
                    System.out.println(Validation.esNombreUsuarioValido(nombreUsuario));
                    System.out.println("////////////////////////// Opcion "
                            + "1 //////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    break;
                default:
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("Esa no es una opcion valida");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    System.out.println("//////////////////////////////////"
                            + "////////////////////////////////////");
                    break;
            }

        } while (opcion != 0);
    }

}
