/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen2.ej2;

/**
 *
 * @author Cesar J. Santacruz
 */
public interface Saludo {
	public abstract String saludar();
}


