/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen2.ej2;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Docente extends Persona implements Saludo{

	@Override
	public String responsabilidad() {
		return "\nLa responsabilidd es trabajar\n";
	}

	public Docente (String nombre,String apellido,long cedula){
		this.nombre = nombre;
		this.apellido = apellido;
		this.cedula = cedula;
	}

	@Override
	public String saludar() {
		return toString() + responsabilidad();
	}
	
}










