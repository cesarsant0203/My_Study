/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen2.ej2;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Cesar J. Santacruz
 */
public class CesarSantacruzExamenIIBEj2 {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		// TODO code application logic here
		ArrayList <Saludo> objetos = new ArrayList<>();
		Estudiante newE = new Estudiante(201825667, "cesar", "santacruz", 1723521017);
		Docente newD = new Docente("Joel", "portilla", 1727364320);
		Facultad newF = new Facultad("Sistemas", 14);
		objetos.add(newE);
		objetos.add(newD);
		objetos.add(newF);
		for (Saludo saludo : objetos){
			System.out.println(saludo.saludar());
		}
		
	}
}





