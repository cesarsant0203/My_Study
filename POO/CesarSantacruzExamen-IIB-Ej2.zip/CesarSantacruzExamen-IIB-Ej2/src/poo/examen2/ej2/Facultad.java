/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen2.ej2;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Facultad implements Saludo{
	private String nombreFacultad;
	private int numeroDepartamentos;
	public Facultad (String nombreF, int numeroD){
		this.nombreFacultad = nombreF;
		this.numeroDepartamentos = numeroD;
	}

	@Override
	public String saludar() {
		return "Soy la facultad de " + this.nombreFacultad 
			+ " y tengo " + this.numeroDepartamentos +" departamentos";
	}
}







