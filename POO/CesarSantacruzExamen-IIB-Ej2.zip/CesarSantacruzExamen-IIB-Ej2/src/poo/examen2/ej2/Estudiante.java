/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen2.ej2;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Estudiante extends Persona implements Saludo {
	private int numeroUnico;

	public Estudiante (int numeroU,String nombre,String apellido,long cedula){
		this.numeroUnico = numeroU;
		this.nombre = nombre;
		this.apellido = apellido;
		this.cedula = cedula;
	}

	/*@Override
	public String toString() {
		return "\n"+"Estudiante{" + "numeroUnico=" + numeroUnico 
			+ "Nombre" + getNombre() 
			+ "Apellido" + getApellido() 
			+ "Cedula" + getCedula()+'}' + "\n";
	}*/

	@Override
	public String responsabilidad() {
		return " \nLa responsabilidd es estudiar \n";
	}

	@Override
	public String saludar() {
		return "Codigo Unico: " + this.numeroUnico +" "+ toString() + responsabilidad();
	}
	
}

















