/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Jornada {

	private String codigo;
	private String ciclo;
	private int duracion;
	
	public Jornada(){}
	public Jornada(String codigo, String ciclo, int duracion){
		this.codigo = codigo;
		this.ciclo = ciclo;
		this.duracion = duracion;
	}
	@Override
	public String toString() {
		return "Jornada{" + "codigo=" + codigo + ", ciclo=" + ciclo + ", duracion=" + duracion + '}';
	}
	
}




