/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.examen;

import java.util.ArrayList;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Congreso {

	private String tema;
	private String ciudad;
	private String frecuencia;
	private ArrayList<String> areasInteres = new ArrayList<>();
	private Organizador organizadorCongreso;
	private Jornada[] jornada = new Jornada[3];

	public void agregarAreaInteres(String nuevoArea) {
		this.areasInteres.add(nuevoArea);
	}

	public void agregarJornada(Jornada nuevaJornada) {
		int i = 0;
		jornada[i] = nuevaJornada;
		i++;

	}

	public Organizador getOrganizadorCongreso() {
		return organizadorCongreso;
	}

	public void setOrganizadorCongreso(Organizador organizadorCongreso) {
		this.organizadorCongreso = organizadorCongreso;
	}

	public String getTema() {
		return tema;
	}

	public void setTema(String tema) {
		this.tema = tema;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getFrecuencia() {
		return frecuencia;
	}

	public void setFrecuencia(String frecuencia) {
		this.frecuencia = frecuencia;
	}

	public Jornada[] getJornada() {
		return jornada;
	}

	@Override
	public String toString() {
		return "organizadorCongreso=\n" + organizadorCongreso +  "\ntema=\n" + tema + "\nciudad=\n" + ciudad + "\nfrecuencia=\n" + frecuencia + "\nareasInteres=\n" + areasInteres + "\njornada=\n" + jornada + '}';
	}

}



