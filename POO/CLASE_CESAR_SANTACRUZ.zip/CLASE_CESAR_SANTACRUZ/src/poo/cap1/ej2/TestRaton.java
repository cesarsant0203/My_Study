/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo.cap1.ej2;

import java.util.Scanner;

/**
 *
 * @author cesar
 */
public class TestRaton {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //entrada.nextline(),
        /*
        System.out.println("Por favor ingrese la tasa de crecimiento");
        double tasa;
        Scanner input = new Scanner(System.in);
        tasa = input.nextDouble();
        System.out.println("Por favor ingrese los la cantidad de dias de crecimiento");
        int duracion;
        duracion = input.nextInt();
        //////////////////////////////////////////////////////////////
        Raton gus;//vairable de la clase raton, se toma de la clase
        gus = new Raton();//se crea una instancia con una memoria asignada para el peso, edad
        gus.setTasaCrecimientoPorcentual(tasa);
        gus.setDias(duracion);
        System.out.println("////////// Raton Gus //////////");
        gus.desplegar();
        gus.crecer(4);
        gus.desplegar();
        /////////////////////////////////////////////////////////////
        Raton alse = new Raton(); // declaracion e inicializacion 
        alse.setTasaCrecimientoPorcentual(20);
        alse.setDias(duracion);
        System.out.println("////////// Raton Alce //////////");
        alse.desplegar();
        alse.crecer();
        alse.desplegar();
        ////////////////////////////////////////////////////////////
        Raton jaq = new Raton(); // declaracion e inicializacion 
        jaq.setTasaCrecimientoPorcentual(30);
        jaq.setDias(4);
        System.out.println("////////// Raton jaq //////////");
        jaq.desplegar();
        jaq.crecer();
        jaq.desplegar();
       
        ////////////////////////Clase 09/06/2020////////////////////////////////////
        //System.out.println("Edad de jaq: " + jaq.getEdad() + jaq.toString());//
        System.out.println();
        if (jaq.esAdolecente() == true) {
            System.out.println("Jaq es un adolecente");
        }
        if (!jaq.esAdolecente()){
            System.out.print("Jaq no es un adolecente");
        }
        System.out.println(jaq.toString());
        System.out.println(Math.min(4, 2));
        ////////////////////////////////////////////////////////////
        Raton lola = new Raton (4.0,6);
        System.out.println(lola.toString());
        *//////////////////////////////////////////////////////////
        Raton jaq = new Raton (6.0,4,"jaq");
        Raton lola = new Raton (6.0,4,"lola");
        if (lola.equals(jaq))
            System.out.println("Son iguales");
        else
            System.out.println("no son iguales");
        lola.setTasaCrecimientoPorcentual(50);
        lola.crecer();
        
        System.out.println(lola.toString());
        
        Veterinario vet = new Veterinario();
        
        String ml = vet.diagnosticar(lola);
        
        System.out.println(ml);
               
    }

}
