/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica3;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class MetodoInsercion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el tamanio del arreglo");
        int tamanio = input.nextInt();
        int[] array1 = new int[tamanio];
        System.out.println("Ingrese los elementos del arreglo");
        for (int i = 0; i < array1.length; i++) {
            array1[i] = input.nextInt();
        }
        System.out.println("Lista inicial: " + imprimirLista(array1));
        ordenamientoInsercion(array1);
        System.out.println("Lista ordenada Insercion: " + imprimirLista(array1));
    }

    public static String imprimirLista(int array[]) {
        String arrayP = "";
        for (int i = 0; i < array.length; i++) {
            arrayP = arrayP + " " + array[i];
        }
        return arrayP;
    }

    public static void ordenamientoInsercion(int[] array) {
        int i, j;
        for (i = 1; i < array.length; i++) {
            for (j = i - 1; j >= 0; j--) {
                if (array[j] > array[j + 1]) {
                    intercambiar(array, j + 1, j);
                }
            }
            System.out.println(imprimirLista(array));
        }
    }

    public static void intercambiar(int vector[], int i, int j) {
        int aux;
        aux = vector[i];
        vector[i] = vector[j];
        vector[j] = aux;
    }
}
