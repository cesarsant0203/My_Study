/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica3;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class MetodoBurbuja {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el tamanio del arreglo");
        int tamanio = input.nextInt();
        int[] array1 = new int[tamanio];
        System.out.println("Ingrese los elementos del arreglo");
        for (int i = 0; i < array1.length; i++) {
            array1[i] = input.nextInt();
        }
        System.out.println("Lista inicial: " + imprimirLista(array1));
        ordenamientoBurbuja(array1);
        System.out.println("Lista ordenada Burbuja: " + imprimirLista(array1));

    }

    public static String imprimirLista(int array[]) {
        String arrayP = "";
        for (int i = 0; i < array.length; i++) {
            arrayP = arrayP + " " + array[i];
        }
        return arrayP;
    }

    public static void ordenamientoBurbuja(int vector[]) {
        int i, j;
        for (i = 0; i < vector.length - 1; i++)//bucle para controlar las pasadas(externo).
        {
            for (j = i + 1; j < vector.length; j++) {
                if (vector[i] > vector[j]) {
                    intercambiar(vector, i, j);
                    System.out.println(imprimirLista(vector));
                }
            }
        }
    }

    public static void intercambiar(int vector[], int i, int j) {
        int aux;
        aux = vector[i];
        vector[i] = vector[j];
        vector[j] = aux;
    }
}
