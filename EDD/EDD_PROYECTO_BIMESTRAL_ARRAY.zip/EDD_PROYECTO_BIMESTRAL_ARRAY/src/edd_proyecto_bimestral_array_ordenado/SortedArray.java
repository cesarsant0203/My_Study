/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd_proyecto_bimestral_array_ordenado;

import java.util.ArrayList;

/**
 *
 * @author Cesar J. Santacruz
 */
public class SortedArray {
    
/////Metodos de busqueda de suma/////////////////////////////
    /////Metodo de suma para estatico////////////////////////
    public static ArrayList<String> busquedaSumaEstatico(int[] array, int x) {
        int i, j;
        boolean flag = false;
        ArrayList<String> st = new ArrayList<>();
        for (i = 0; i < array.length; i++) {
            for (j = i + 1; j < array.length; j++) {
                if ((array[i] + array[j]) == x) {
                    flag = true;
                    st.add("Los numeros en los indices " + i + "("+array[i]+")"+" y " + j + "("+array[j]+")"+ " suman " + x);
                }
            }
        }
        if (!flag) {
            st.add("No hay elementos que sumen " + x);
        }
        return st;
    }

    /////Metodo de suma para dinamico////////////////////////
    public static ArrayList<String> busquedaSumaDinamico(ArrayList<Integer> array, int x) {
        int i, j;
        boolean flag = false;
        ArrayList<String> st = new ArrayList<>();
        for (i = 0; i < array.size(); i++) {
            for (j = i + 1; j < array.size(); j++) {
                if ((array.get(i) + array.get(j)) == x) {
                    flag = true;
                    st.add("Los numeros en los indices " + i + "("+array.get(i)+")"+" y " + j + "("+array.get(j)+")"+ " suman " + x);
                }
            }
        }
        if (!flag) {
            st.add("No hay elementos que sumen " + x);
        }
        return st;
    }
    
/////Metodos de busqueda en array/////////////////////////////////
    /////Metodo de busqueda para estatico y primera iteracion/////
    public static int binarySearchEstaticOne(int[] array, int bajo, int alto, int searchValue) {
        if (alto >= bajo) {
            int midIndex = bajo + (alto - bajo) / 2;
            if (array[midIndex] == searchValue) {
                return midIndex;
            } else if (array[midIndex] > searchValue) {
                return binarySearchEstaticOne(array, bajo, midIndex - 1, searchValue);
            } else {
                return binarySearchEstaticOne(array, midIndex + 1, alto, searchValue);
            }
        }
        return -1;
    }

    /////Metodo de busqueda para estatico y todas iteraciones/////
    public static ArrayList<Integer> linearSearchEstaticMany(int[] array, int value) {
        ArrayList<Integer> a = new ArrayList<>();
        boolean flag = false;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                flag = true;
                a.add(i);
            }
        }
        if (!flag) {
            a.add(-1);
        }
        return a;
    }

    /////Metodo de busqueda para dinamico y primera iteracion/////
    public static int binarySearchDynamicOne(ArrayList<Integer> array, int bajo, int alto, int searchValue) {
        if (alto >= bajo) {
            int midIndex = bajo + (alto - bajo) / 2;
            if (array.get(midIndex) == searchValue) {
                return midIndex;
            } else if (array.get(midIndex) > searchValue) {
                return binarySearchDynamicOne(array, bajo, midIndex - 1, searchValue);
            } else {
                return binarySearchDynamicOne(array, midIndex + 1, alto, searchValue);
            }
        }
        return -1;
    }

    /////Metodo de busqueda para dinamico y todas iteraciones/////
    public static ArrayList<Integer> linearSearchDynamicMany(ArrayList<Integer> array, int value) {
        ArrayList<Integer> a = new ArrayList<>();
        boolean flag = false;
        for (int i = 0; i < array.size(); i++) {
            if (array.get(i) == value) {
                flag = true;
                a.add(i);
            }
        }
        if (!flag) {
            a.add(-1);
        }
        return a;
    }
    
/////Metodos de insercion en el array////////////////////////////
    ////Insertar para estatico///////////////////////////////////
    public static int[] estaticInsert(int[] array, int x) {
        if(x >= array[array.length-1]){
        int i;
        int oSize = array.length;
        int newArray[] = new int[oSize + 1];
        for (i = 0; i < oSize; i++) {
            newArray[i] = array[i];
        }
        newArray[oSize] = x;
        return newArray;
        }else{
            return array;
        }
    }

    ////Insertar para dinamico///////////////////////////////////
    public static void dynamicInsert(ArrayList<Integer> array, int x) {
        if(x >= array.get(array.size()-1)){
        array.add(x);
        }else{}
    }

/////Metodos de eliminar en el array////////////////////////////
    ////Eliminar para estatico primera//////////////////////////
    public static int[] estaticDeleteOne(int[] array, int x) {
        int i;
        int cont = 0;
        int oSize = array.length;
        int searchIndex = binarySearchEstaticOne(array, 0, array.length-1, x);
        System.out.println(searchIndex);
        if(searchIndex!=-1){
        array[searchIndex] = -1;
        int newArray[] = new int[oSize - 1];
        for (i = 0; i < oSize; i++) {
            if (array[i] != -1) {
                newArray[cont] = array[i];
                cont++;
            }
        }
        return newArray;
        }else{
            return array;
        }
    }

    ////Eliminar para estatico todas/////////////////////////////
    public static int[] estaticDeleteMany(int[] array, int x) {
        int i;
        int cont = 0;
        int oSize = array.length;
        ArrayList<Integer> indexes = linearSearchEstaticMany(array, x);
        if(indexes.get(0)!=-1){
        int newArray[] = new int[oSize - indexes.size()];
        indexes.forEach(search -> {
            array[search] = -1;
        });
        for (i = 0; i < oSize; i++) {
            if (array[i] != -1) {
                newArray[cont] = array[i];
                cont++;
            }
        }
        return newArray;
        }else{
            return array;
        }
    }

    ////Eliminar para dinamico primera/////////////////////////////
    public static void dynamicDeleteOne(ArrayList<Integer> array, int x) {
        int searchIndex = binarySearchDynamicOne(array, 0, array.size()-1, x);
        if (searchIndex != -1) {
            array.remove(searchIndex);
        } else {
        }
    }

    ////Eliminar para dinamico todas/////////////////////////////
    public static void dynamicDeleteMany(ArrayList<Integer> array, int x) {
        int i;
        ArrayList<Integer> indexes = linearSearchDynamicMany(array, x);
        if (indexes.get(0) != -1) {
            for (i = indexes.size() - 1; i >= 0; i--) {
                int y = indexes.get(i);
                array.remove(y);
            }
        } else {
        }
    }
}
