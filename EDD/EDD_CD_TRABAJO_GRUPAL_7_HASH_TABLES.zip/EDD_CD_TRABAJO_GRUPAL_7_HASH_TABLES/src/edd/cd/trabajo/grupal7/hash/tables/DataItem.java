package edd.cd.trabajo.grupal7.hash.tables;

public class DataItem {
	private int iData; // data item (key)
	//--------------------------------------------------------------
	public DataItem(int ii) // constructor
	{ iData = ii; }
	//--------------------------------------------------------------
	public int getKey()
	{ return iData; }
	//--------------------------------------------------------------
	} // end class DataItem
