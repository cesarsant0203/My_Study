/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica4;

import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class MetodoMergeSort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el tamanio del vector");
        int tamanio = input.nextInt();
        int[] array1 = new int[tamanio];
        System.out.println("Ingrese los elementos del vector");
        for (int i = 0; i < array1.length; i++) {
            array1[i] = input.nextInt();
        }
        System.out.println("Vector inicial: " + imprimirLista(array1));
        int menor = 0;
        int mayor = array1.length - 1;
        ordenarMezclaDirecta(array1, menor, mayor);
        System.out.println("Vector ordenado mezcla directa: " + imprimirLista(array1));
    }

    public static void intercambiar(int arr[], int l, int m, int r) {
        int n1 = m - l + 1;
        int n2 = r - m;
        int L[] = new int[n1];
        int R[] = new int[n2];
        for (int i = 0; i < n1; ++i) {
            L[i] = arr[l + i];
        }
        for (int j = 0; j < n2; ++j) {
            R[j] = arr[m + 1 + j];
        }
        int i = 0, j = 0;
        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }
        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

    public static void ordenarMezclaDirecta(int arr[], int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            ordenarMezclaDirecta(arr, l, m);
            ordenarMezclaDirecta(arr, m + 1, r);
            intercambiar(arr, l, m, r);
        }
    }

    public static String imprimirLista(int array[]) {
        String arrayP = "";
        for (int i = 0; i < array.length; i++) {
            arrayP = arrayP + " " + array[i];
        }
        return arrayP;
    }
}
