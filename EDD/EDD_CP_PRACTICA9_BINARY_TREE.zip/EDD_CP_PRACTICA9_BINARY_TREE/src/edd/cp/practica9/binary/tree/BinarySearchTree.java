/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica9.binary.tree;

/**
 *
 * @author Cesar J. Santacruz
 */
public class BinarySearchTree {

    TreeNode root;
    // Space to print cool
    static int count = 10;

    // Constructor
    public BinarySearchTree() {
        this.root = null;
    }

    // This method insert tree node
    public TreeNode insertTreeNode(TreeNode root, int key) {
        if (root == null) {
            root = new TreeNode(key);
            return root;
        }
        if (key < root.key) {
            root.left = insertTreeNode(root.left, key);
        } else if (key > root.key) {
            root.right = insertTreeNode(root.right, key);
        } else if (key == root.key) {
            System.out.println("Nodes with the same value can not be added");
        }
        return root;
    }

    static void printKeys(TreeNode root, int space) {
        if (root == null) {
            return;
        }
        space += count;
        printKeys(root.right, space);
        System.out.print("\n");
        for (int i = count; i < space; i++) {
            System.out.print(" ");
        }
        System.out.print(root.key + "\n");
        printKeys(root.left, space);
    }

    static void printPreorder(TreeNode nodePointer) {
        if (nodePointer == null) {
        } else {
            // Print nodePointer
            System.out.print(nodePointer.key + " ");

            // left subtree
            printPreorder(nodePointer.left);

            // right subtree
            printPreorder(nodePointer.right);
        }
    }

    static void printPostorder(TreeNode nodePointer) {
        if (nodePointer == null) {
        } else {
            // left subtree
            printPostorder(nodePointer.left);

            // right subtree
            printPostorder(nodePointer.right);

            // Print nodePointer
            System.out.print(nodePointer.key + " ");
        }
    }

    static void printInorder(TreeNode nodePointer) {
        if (nodePointer == null) {
        } else {
            // left subtree
            printInorder(nodePointer.left);

            // Print nodePointer
            System.out.print(nodePointer.key + " ");

            // right subtree
            printInorder(nodePointer.right);
        }
    }
    
    //wrappers for all methods in class
    public void printBinarySearchTree(TreeNode root) {
        // Pass initial space count as 0  
        printKeys(root, 0);
        System.out.println();
    }

    public void insert(int key) {
        root = insertTreeNode(root, key);
    }

    void printPostorder() {
        printPostorder(root);
        System.out.println();
    }

    void printInorder() {
        printInorder(root);
        System.out.println();
    }

    void printPreorder() {
        printPreorder(root);
        System.out.println();
    }
}
