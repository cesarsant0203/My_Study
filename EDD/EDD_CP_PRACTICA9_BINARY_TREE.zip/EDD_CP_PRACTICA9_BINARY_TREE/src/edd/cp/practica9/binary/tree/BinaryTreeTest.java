/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica9.binary.tree;

/**
 *
 * @author Cesar J. Santacruz
 */
public class BinaryTreeTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BinarySearchTree tree = new BinarySearchTree();
        /*tree.insert(8);
        tree.insert(3);
        tree.insert(1);
        tree.insert(6);
        tree.insert(4);
        tree.insert(7);
        tree.insert(10);
        tree.insert(14);
        tree.insert(13);
        */
        tree.insert(78);
        tree.insert(32);
        tree.insert(60);
        tree.insert(89);
        tree.insert(46);
        tree.insert(98);
        tree.insert(28);
        tree.insert(53);
        tree.printBinarySearchTree(tree.root);

        System.out.println("Preorder: ");
        tree.printPreorder();

        System.out.println("Inorder: ");
        tree.printInorder();

        System.out.println("Postorder: ");
        tree.printPostorder();
    }
}
