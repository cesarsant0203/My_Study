/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.practica9.binary.tree;

/**
 *
 * @author Cesar J. Santacruz
 */
public class TreeNode {

    int key;
    TreeNode left, right;

    public TreeNode(int item) {
        key = item;
        left = null;
        right = null;
    }
}
