package arrays.grupo3;

import java.util.Random;

/*
 * @author Cesar
 */
public class TestArrays2 {

    public static void main(String[] args) {
        long startTimeR = System.nanoTime();
        Random rnd = new Random(System.nanoTime());
        int randomArray[];
        randomArray  = new int[10];

        System.out.print("Arreglo aleatorio: {");
        for (int i = 0; i < 10; i++) {
            randomArray[i] = (int) (rnd.nextDouble() * 20 + 7);
            System.out.print(" " + randomArray[i]);

        }
        System.out.println(" }");
        long totalTimeR = System.nanoTime() - startTimeR;
        System.out.println("\nTiempo total: " + totalTimeR + " ns");

        long startTimeM = System.nanoTime();
        int manualArray[];
        manualArray = new int[10];
        System.out.println("\n");
        System.out.print("Arreglo manual: {");
        manualArray[0] = (int) 23;
        System.out.print(" " + manualArray[0]);
        manualArray[1] = 34;
        System.out.print(" " + manualArray[1]);
        manualArray[2] = 12;
        System.out.print(" " + manualArray[2]);
        manualArray[3] = 10;
        System.out.print(" " + manualArray[3]);
        manualArray[4] = 20;
        System.out.print(" " + manualArray[4]);
        manualArray[5] = 45;
        System.out.print(" " + manualArray[5]);
        manualArray[6] = 99;
        System.out.print(" " + manualArray[6]);
        manualArray[7] = 32;
        System.out.print(" " + manualArray[7]);
        manualArray[8] = 23;
        System.out.print(" " + manualArray[8]);
        manualArray[9] = 76;
        System.out.print(" " + manualArray[9]);
        System.out.println(" }");
        long totalTimeM = System.nanoTime() - startTimeM;
        System.out.println("\nTiempo total: " + totalTimeM + " ns");

    }

}
