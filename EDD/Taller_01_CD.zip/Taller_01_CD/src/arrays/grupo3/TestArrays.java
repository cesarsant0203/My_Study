package arrays.grupo3;

import java.util.Random;

/*
 * @author Cesar
 */
public class TestArrays {

    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        Random rnd = new Random(System.nanoTime());
        int[] numeros = new int[10];
        int[] numerosSinRepeticion = new int[10];

        System.out.print("Primer arreglo: {");
        for (int i = 0; i < 10; i++) {
            numeros[i] = (int) (rnd.nextDouble() * 20 + 5);
            System.out.print(" " + numeros[i]);

        }
        System.out.println(" }");

        System.out.print("Segundo arreglo: {");
        for (int i = 0; i < 10; i++) {
            numerosSinRepeticion[i] = (int) (rnd.nextDouble() * 20 + 5);
            if (i > 0) {
                boolean existeRepeticion = revisarArray(i, numerosSinRepeticion);
                while (existeRepeticion) {
                    numerosSinRepeticion[i] = (int) (rnd.nextDouble() * 20 + 5);
                    existeRepeticion = revisarArray(i, numerosSinRepeticion);
                }
            }
            System.out.print(" " + numerosSinRepeticion[i]);
        }
        System.out.println(" }");
        long totalTime = System.currentTimeMillis() - startTime;
        System.out.println("\nTiempo total: " + totalTime + " ms");
    }

    private static boolean revisarArray(int i, int[] arreglo) {
        for (int j = 0; j < i; j++) {
            if (arreglo[j] == arreglo[i]) {
                return true;
            }
        }
        return false;
    }

}
