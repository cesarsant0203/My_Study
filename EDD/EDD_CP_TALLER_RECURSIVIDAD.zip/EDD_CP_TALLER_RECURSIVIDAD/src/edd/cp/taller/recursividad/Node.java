/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.recursividad;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Node {
    public int dData; // data item
    public Node next; // next node in list
    // --------------------------------------------------

    public Node(int dd) // constructor
    {
        dData = dd; //
        next = null;
    }
    // --------------------------------------------------

    public void displayData() // display ourself
    {
        String dLink = String.format("%-3s", dData + " -> ");
        System.out.print(dLink);
    }  
}
