/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.recursividad;

import static edd.cp.taller.recursividad.BinarySearch.binarySearch;
import static edd.cp.taller.recursividad.Factorial.factorial;
import static edd.cp.taller.recursividad.Fibonacci.fibonacci;
import java.util.Arrays;

/**
 *
 * @author Cesar J. Santacruz
 */
public class RecursividadTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Factorial
        System.out.println("Factorial of 5 is: " + factorial(5));
        //Fibonacci
        System.out.println("Fibonacci of 5 is: " + fibonacci(5));
        //Linked List
        LinkList theList = new LinkList();
        for (int i = 1; i <= 10; i++) {
            theList.insertFirst(i);
        }
        System.out.println("Linked List:");
        LinkList.displayListRecursive(theList.first);
        //Binary Search
        int[] array = {11, 22, 33, 44, 55, 66, 77, 88, 99};
        int size = array.length;
        int searchKey = 77;
        int returnValue = binarySearch(array, 0, size - 1, searchKey);
        System.out.println("Binary Search:");
        System.out.println(Arrays.toString(array));
        if (returnValue != -1) {
            System.out.println("The index of the element "
                    + searchKey + " is: " + returnValue);
        } else {
            System.out.println("ERROR: Element not found");
        }
    }
}
