/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.recursividad;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Fibonacci {

    public static long fibonacci(long N) {
        //fibonacci only for positive numbers
        if (N >= 0) {
            if (N <= 1) {
                return N;
            } else {
                //recursive case
                return fibonacci(N - 1)
                        + fibonacci(N - 2);
            }
        } else {
            return -1;
        }
    }
}
