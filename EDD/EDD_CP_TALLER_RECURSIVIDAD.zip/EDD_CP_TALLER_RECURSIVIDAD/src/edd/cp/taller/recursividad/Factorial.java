/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.recursividad;

/**
 *
 * @author Cesar J. Santacruz
 */
public class Factorial {

    //recursive method
    public static long factorial(long N) {
        //0! is 1
        if (N == 0) {
            return 1;
        } else {
            //recursiva case
            return N * factorial(N - 1);
        }
    }
}
