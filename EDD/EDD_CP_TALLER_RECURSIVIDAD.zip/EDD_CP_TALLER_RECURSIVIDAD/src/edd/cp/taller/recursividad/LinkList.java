/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.recursividad;

/**
 *
 * @author Cesar J. Santacruz
 */
public class LinkList {

    public Node first; // reference to first link in list
    // ----------------------------------------------

    public LinkList() // constructor
    {
        first = null; // no items on list yet
    }
    // ----------------------------------------------

    // insert at start of list
    public void insertFirst(int dd) {
        Node newNode = new Node(dd);
        newNode.next = first; // newNode --> old first
        first = newNode; // first --> newNode
    }
    // ----------------------------------------------

    //display the list recursive
    public static void displayListRecursive(Node current) {
        //last node or empty list
        if (current == null) {
            //format for printing
            String dNull = String.format("%-3s", null + " ");
            System.out.print(dNull);
            System.out.println("");
        } else {
            //recursive LinkList
            current.displayData();// print data
            displayListRecursive(current.next);
        }
    }
    // ----------------------------------------------

}
