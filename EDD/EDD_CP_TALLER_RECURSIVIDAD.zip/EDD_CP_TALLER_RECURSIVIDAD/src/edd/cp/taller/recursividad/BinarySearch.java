/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cp.taller.recursividad;

/**
 *
 * @author Cesar J. Santacruz
 */
public class BinarySearch {
    //binary search method
    public static int binarySearch(int[] a, int low, int high, int searchValue) {
        if (high >= low) {
            int midIndex = low + (high - low) / 2;
            if (a[midIndex] == searchValue) {
                return midIndex;
            } else if (a[midIndex] > searchValue) {
                return binarySearch(a, low, midIndex - 1, searchValue);
            } else {
                return binarySearch(a, midIndex + 1, high, searchValue);
            }
        }
        return -1;
    }
}
