/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cd.autoevaluacion;

/**
 *
 * @author cesar
 */
public class AutoEvaluacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] array1 = {34,2,155,62,342,6,26,24,14,15,136,3,7,26,27};
        int menor = 0;
        int mayor = array1.length - 1;
        ordenamientoQuickSort(array1, menor, mayor);
        System.out.println("El valor minimo es "+array1[0]);
        System.out.println("El valor maximo es "+array1[array1.length - 1]);
    }

    public static String imprimirLista(int array[]) {
        String arrayP = "";
        for (int i = 0; i < array.length; i++) {
            arrayP = arrayP + " " + array[i];
        }
        return arrayP;
    }

    public static void ordenamientoQuickSort(int[] array, int menor, int mayor) {

        int posicionCentro = menor + (mayor - menor) / 2;
        int pivote = array[posicionCentro];

        int i = menor, j = mayor;
        while (i <= j) {
            while (array[i] < pivote) {
                i++;
            }

            while (array[j] > pivote) {
                j--;
            }

            if (i <= j) {
                intercambiar(array, i, j);
                i++;
                j--;
            }
        }
        if (menor < j) {
            ordenamientoQuickSort(array, menor, j);
        }

        if (mayor > i) {
            ordenamientoQuickSort(array, i, mayor);
        }
    }

    public static void intercambiar(int vector[], int i, int j) {
        int aux;
        aux = vector[i];
        vector[i] = vector[j];
        vector[j] = aux;
    }
}
