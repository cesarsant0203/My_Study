/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.proyecto.bimestral.stacks;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Cesar J. Santacruz
 */
public class ArrayStack {

    @Override
    public String toString() {
        return "Stack [elements=" + elements + "]";
    }
    private final List<String> elements = new ArrayList<>();

    public String peek() {
        if (elements.isEmpty()) {
            return null;
        }
        return elements.get(elements.size() - 1);
    }

    public String pop() {
        if (elements.isEmpty()) {
            return null;
        }
        String top = elements.get(elements.size() - 1);
        elements.remove(elements.size() - 1);
        return top;
    }

    public void push(String element) {
        elements.add(element);
    }

    public int size() {
        return elements.size();
    }

    public boolean isEmpty() {
        return elements.isEmpty();
    }
}
