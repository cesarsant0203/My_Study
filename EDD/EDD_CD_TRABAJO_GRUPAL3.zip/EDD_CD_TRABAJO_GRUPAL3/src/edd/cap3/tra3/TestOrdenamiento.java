/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.cap3.tra3;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Cesar J. Santacruz
 */
public class TestOrdenamiento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        welcome();
        Scanner input = new Scanner(System.in);
        System.out.println("Ingrese el tamanio del arreglo");
        System.out.println("1. 10000 elementos aleatorios");
        System.out.println("2. 5000 elementos aleatorios");
        System.out.println("3. 10 elementos aleatorios");
        System.out.println("Otro numero para salir del programa");
        int[] array1 = null;
        int election = input.nextInt();
        switch (election) {
            case 1 -> {
                array1 = fillArray(10000);
            }
            case 2 -> {
                array1 = fillArray(5000);
            }
            case 3 -> {
                array1 = fillArray(10);
            }
            default -> {
                System.out.println("Muchas gracias por usar este programa");
                System.exit(0);
            }
        }
        divider();
        int option = 0;
        try {
            do {
                options();
                option = input.nextInt();
                switch (option) {
                    case 0:
                        System.out.println("Muchas gracias por usar este programa");
                        System.exit(0);
                    case 1:
                        divider();
                        System.out.println("\t\tMetodo de la burbuja");
                        System.out.println("Arreglo antes de ordenar");
                        int[] array2 = array1.clone();
                        System.out.println(Arrays.toString(array2));
                        long startTimeA = System.nanoTime();
                        bubbleSort(array2);
                        long totalTimeA = System.nanoTime() - startTimeA;
                        System.out.println("Arreglo ordenado");
                        System.out.println(Arrays.toString(array2));
                        System.out.println("tiempo de ordenamiento");
                        System.out.println(totalTimeA + " ns");
                        divider();
                        break;
                    case 2:
                        divider();
                        System.out.println("\t\tMetodo de seleccion");
                        System.out.println("Arreglo antes de ordenar");
                        int[] array3 = array1.clone();
                        System.out.println(Arrays.toString(array3));
                        long startTimeB = System.nanoTime();
                        ordenamientoSeleccion(array3);
                        long totalTimeB = System.nanoTime() - startTimeB;
                        System.out.println("Arreglo ordenado");
                        System.out.println(Arrays.toString(array3));
                        System.out.println("tiempo de ordenamiento");
                        System.out.println(totalTimeB  + " ns");
                        divider();
                        break;
                    case 3:
                        divider();
                        System.out.println("\t\tMetodo de inserccion");
                        System.out.println("Arreglo antes de ordenar");
                        int[] array4 = array1.clone();
                        System.out.println(Arrays.toString(array1));
                        long startTimeC = System.nanoTime();
                        ordenamientoPorInsercion(array4);
                        long totalTimeC = System.nanoTime() - startTimeC;
                        System.out.println("Arreglo ordenado");
                        System.out.println(Arrays.toString(array4));
                        System.out.println("tiempo de ordenamiento");
                        System.out.println(totalTimeC + " ns");
                        divider();
                        break;
                    default:
                        divider();
                        divider();
                        System.out.println("Esa no es una opcion valida");
                        divider();
                        divider();
                        break;
                }

            } while (option != 0);
        } catch (Exception e) {
            System.out.println("Ese no es un valor numerico valido");
        }

    }

    public static void welcome() {
        System.out.println("///////////////////////////////////////"
                + "/////////////////////////////////////////");
        System.out.println("\t\t\tBIENVENID@");
        System.out.println("///////////////////////////////////////"
                + "/////////////////////////////////////////");
    }

    public static void options() {
        System.out.println("Seleccione el numero de opcion que desea realiz"
                + "ar");
        System.out.println("Por favor ingrese 1 si desea ordenar con el metodo "
                + "de la burbuja ");
        System.out.println("Por favor ingrese 2 si desea aordenar con el metodo "
                + "de seleccion");
        System.out.println("Por favor ingrese 3 si desea aordenar con el metodo "
                + "de inserccion");
        System.out.println("Por favor ingrese 0 si desea salir en este mome"
                + "nto del programa");
    }

    public static void divider() {
        System.out.println("///////////////////////////////////////"
                + "/////////////////////////////////////////");
    }

    static void bubbleSort(int[] array) {
        int size = array.length;
        int provState;
        for (int i = 0; i < size; i++) {
            for (int j = 1; j < (size - i); j++) {
                if (array[j - 1] > array[j]) {
                    //swap elements  
                    provState = array[j - 1];
                    array[j - 1] = array[j];
                    array[j] = provState;
                }

            }
        }
    }

    public static int[] fillArray(int size) {
        Random rnd = new Random(System.currentTimeMillis());
        int[] array = new int[size];

        for (int i = 0; i < size; i++) {
            array[i] = rnd.nextInt(100);
        }

        return array;
    }

    public static int[] ordenamientoSeleccion(int arreglo[]) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            int aux;
            for (int j = i + 1; j < arreglo.length; j++) {
                if (arreglo[i] > arreglo[j] && i != j) {
                    aux = arreglo[i];
                    arreglo[i] = arreglo[j];
                    arreglo[j] = aux;
                }

            }
        }
        return arreglo;
    }

    public static int[] ordenamientoPorInsercion(int[] array) {
        int auxUno, auxDos;

        for (int i = 1; i < array.length; i++) {
            for (int j = 0; j < i; j++) {
                if (array[i] < array[j]) {
                    auxUno = array[j];
                    array[j] = array[i];
                    for (int k = j + 1; k < i + 1; k++) {
                        auxDos = array[k];
                        array[k] = auxUno;
                        auxUno = auxDos;
                    }
                }
            }
        }

        return array;
    }
}
