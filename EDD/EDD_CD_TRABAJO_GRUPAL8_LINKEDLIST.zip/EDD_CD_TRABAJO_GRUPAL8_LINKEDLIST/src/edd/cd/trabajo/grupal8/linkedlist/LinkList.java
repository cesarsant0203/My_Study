package edd.cd.trabajo.grupal8.linkedlist;

public class LinkList {

    private Link first; // ref. to first link on list
    // -------------------------------------------------------------

    public LinkList() // constructor
    {
        first = null; // no items on list yet
    }
    // -------------------------------------------------------------

    public boolean isEmpty() // true if list is empty
    {
        return (first == null);
    }
    // -------------------------------------------------------------
    // insert at start of list

    public void insertFirst(int id, double dd) { // make new link
        Link newLink = new Link(id, dd);
        newLink.next = first; // newLink --> old first
        first = newLink; // first --> newLink
    }
    // -------------------------------------------------------------

    public Link deleteFirst() // delete first item
    { // (assumes list not empty)
        Link temp = first; // save reference to link
        first = first.next; // delete it: first-->old next
        return temp; // return deleted link
    }
    // -------------------------------------------------------------

    public void displayList() {
        System.out.print("List (first-->last): ");
        Link current = first; // start at beginning of list
        while (current != null) // until end of list,
        {
            current.displayLink(); // print data
            current = current.next; // move to next link
        }
        System.out.println("");
    }

    public void displayList2() {
        System.out.print("List (last-->first): ");
        Link current = first; // start at beginning of list
        while (current != null) // until end of list,
        {
            current.displayLink(); // print data
            current = current.next; // move to next link
        }
        System.out.println("");
    }
    // -------------------------------------------------------------
    // insert at end of list

    public void insertLast(int id, double dd) { // make new link
        Link newLink = new Link(id, dd);
        if (first == null) {
            first = newLink;
        } else {
            Link last = first;
            while (last.next != null) {
                last = last.next;
            }
            last.next = newLink;
        }
    }
    // -------------------------------------------------------------

    public Link deleteLast() // delete last item
    { // (assumes list not empty)
        Link temp = null; // save reference to link
        if (first.next == null) // List has 1 Node
        {
            temp = first;
            first = null;
        } else {
            Link temp1 = first; //one before temp2
            Link temp2 = first.next; //points to the second one at the beggining
            while (temp2.next != null) {
                temp1 = temp2;
                temp2 = temp2.next;
            }
            temp = temp2;
            temp1.next = null;
        }
        return temp; // return deleted link
    }
    // -------------------------------------------------------------
} // end class LinkList

